package com.ac.cloud.net;

import com.ac.cloud.core.Json;

import org.json.JSONObject;

/**
 * Small async facade over the AIDL service. All callbacks are delivered on the main thread.
 */
public final class Calls {

    public interface Callback {
        void onResult(JSONObject json);
    }

    private Calls() {
    }

    public static void get(String path, Callback callback) {
        Api.ready(() -> Io.run(() -> {
            String raw;
            try {
                raw = Api.get().get(path);
            } catch (Exception e) {
                raw = "{\"code\":0,\"message\":\"服务连接失败\"}";
            }
            final JSONObject json = Json.parse(raw);
            Io.main(() -> callback.onResult(json));
        }));
    }

    public static void post(String path, String body, Callback callback) {
        Api.ready(() -> Io.run(() -> {
            String raw;
            try {
                raw = Api.get().post(path, body);
            } catch (Exception e) {
                raw = "{\"code\":0,\"message\":\"服务连接失败\"}";
            }
            final JSONObject json = Json.parse(raw);
            Io.main(() -> callback.onResult(json));
        }));
    }

    public static void delete(String path, String body, Callback callback) {
        Api.ready(() -> Io.run(() -> {
            String raw;
            try {
                raw = Api.get().delete(path, body);
            } catch (Exception e) {
                raw = "{\"code\":0,\"message\":\"服务连接失败\"}";
            }
            final JSONObject json = Json.parse(raw);
            Io.main(() -> callback.onResult(json));
        }));
    }

    public interface TextCallback {
        void onText(String text);
    }

    public static void formRaw(String path, String formBody, TextCallback callback) {
        Api.ready(() -> Io.run(() -> {
            String raw;
            try {
                raw = Api.get().postForm(path, formBody);
            } catch (Exception e) {
                raw = "";
            }
            final String text = raw;
            Io.main(() -> callback.onText(text));
        }));
    }

    public static void form(String path, String formBody, Callback callback) {
        Api.ready(() -> Io.run(() -> {
            String raw;
            try {
                raw = Api.get().postForm(path, formBody);
            } catch (Exception e) {
                raw = "{\"code\":0,\"message\":\"服务连接失败\"}";
            }
            final JSONObject json = Json.parse(raw);
            Io.main(() -> callback.onResult(json));
        }));
    }

    public static void upload(String path, String fieldsJson, String filePath, String fileField,
                              String fileName, String mimeType, Callback callback) {
        Api.ready(() -> Io.run(() -> {
            String raw;
            try {
                raw = Api.get().upload(path, fieldsJson, filePath, fileField, fileName, mimeType);
            } catch (Exception e) {
                raw = "{\"code\":0,\"message\":\"上传失败\"}";
            }
            final JSONObject json = Json.parse(raw);
            Io.main(() -> callback.onResult(json));
        }));
    }
}
