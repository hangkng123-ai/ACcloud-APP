package com.ac.cloud.ui;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ac.cloud.R;
import com.ac.cloud.core.Json;
import com.ac.cloud.databinding.ActivityHelpBinding;
import com.ac.cloud.net.Calls;
import com.ac.cloud.ui.adapters.TicketAdapter;
import com.ac.cloud.util.UiUtils;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class HelpActivity extends AppCompatActivity {

    private static final long MAX_ATTACHMENT = 15L * 1024 * 1024;

    private ActivityHelpBinding b;
    private TicketAdapter adapter;

    private AlertDialog createDialog;
    private TextView tvAttachment;
    private File attachmentFile;
    private String attachmentName = "";
    private String attachmentMime = "application/octet-stream";

    private final ActivityResultLauncher<Intent> picker = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null) return;
                java.util.ArrayList<String> paths = result.getData()
                        .getStringArrayListExtra(FileManagerActivity.RESULT_PATHS);
                if (paths != null && !paths.isEmpty()) importAttachment(Uri.fromFile(
                        new File(paths.get(0))));
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiUtils.edgeToEdge(this);
        b = ActivityHelpBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        UiUtils.applyInsets(b.getRoot());

        b.header.tvTitle.setText("帮助工单");
        b.header.tvSubtitle.setText("提交问题并查看管理员回复");
        b.header.btnBack.setOnClickListener(v -> finish());
        b.header.btnAction.setVisibility(View.VISIBLE);
        b.header.ivAction.setImageResource(R.drawable.ic_add);
        b.header.btnAction.setOnClickListener(v -> showCreateDialog());

        adapter = new TicketAdapter(this::showDetail);
        b.recycler.setLayoutManager(new LinearLayoutManager(this));
        b.recycler.setAdapter(adapter);
        b.swipe.setOnRefreshListener(this::loadTickets);

        loadTickets();
    }

    private void loadTickets() {
        Calls.get("/api/help/tickets", json -> {
            b.swipe.setRefreshing(false);
            if (json.optInt("code") != 1) {
                UiUtils.toast(Json.message(json));
                return;
            }
            JSONArray tickets = Json.array(json, "tickets");
            adapter.submit(tickets);
            boolean empty = tickets.length() == 0;
            b.emptyView.setVisibility(empty ? View.VISIBLE : View.GONE);
            b.recycler.setVisibility(empty ? View.GONE : View.VISIBLE);
        });
    }

    private void showDetail(JSONObject ticket) {
        String status = ticket.optString("status", "pending");
        String description = ticket.optString("description", "");
        String note = ticket.optString("admin_note", "");
        String replyFile = ticket.optString("reply_file_name", "");
        String fileName = ticket.optString("file_name", "");
        String create = ticket.optString("create_time", "--");
        String update = ticket.optString("update_time", "");

        StringBuilder message = new StringBuilder();
        message.append("状态：").append(TicketAdapter.statusLabel(status)).append('\n');
        message.append("提交时间：").append(create.isEmpty() ? "--" : create).append('\n');
        if (!update.isEmpty()) {
            message.append("更新时间：").append(update).append('\n');
        }
        message.append("\n问题描述\n").append(description.isEmpty() ? "（无描述）" : description);
        message.append("\n\n管理员回复\n").append(note.isEmpty() ? "暂未回复" : note);
        if (!replyFile.isEmpty()) {
            message.append("\n\n回复附件：").append(replyFile);
        }
        if (!fileName.isEmpty()) {
            message.append("\n我的附件：").append(fileName);
        }

        new MaterialAlertDialogBuilder(this)
                .setTitle(ticket.optString("title", "工单详情"))
                .setMessage(message.toString())
                .setPositiveButton("关闭", null)
                .show();
    }

    private void showCreateDialog() {
        attachmentFile = null;
        attachmentName = "";
        attachmentMime = "application/octet-stream";

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = UiUtils.dp(this, 20);
        box.setPadding(pad, UiUtils.dp(this, 4), pad, 0);

        EditText etTitle = dialogInput("工单标题", false);
        EditText etDesc = dialogInput("请详细描述你遇到的问题", true);
        box.addView(etTitle);
        box.addView(etDesc);

        LinearLayout attachRow = new LinearLayout(this);
        attachRow.setOrientation(LinearLayout.HORIZONTAL);
        attachRow.setGravity(Gravity.CENTER_VERTICAL);
        attachRow.setBackgroundResource(R.drawable.bg_input);
        int rowPad = UiUtils.dp(this, 14);
        attachRow.setPadding(rowPad, rowPad, rowPad, rowPad);
        attachRow.setClickable(true);
        attachRow.setFocusable(true);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowLp.topMargin = UiUtils.dp(this, 10);
        attachRow.setLayoutParams(rowLp);

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ic_file);
        Drawable iconDrawable = ContextCompat.getDrawable(this, R.drawable.ic_file);
        if (iconDrawable != null) {
            iconDrawable.setTint(getColor(R.color.primary));
            icon.setImageDrawable(iconDrawable);
        }
        icon.setLayoutParams(new LinearLayout.LayoutParams(UiUtils.dp(this, 20), UiUtils.dp(this, 20)));
        attachRow.addView(icon);

        tvAttachment = new TextView(this);
        tvAttachment.setText("选择附件（可选，最大 15MB）");
        tvAttachment.setTextSize(13);
        tvAttachment.setTextColor(getColor(R.color.on_surface_variant));
        tvAttachment.setPadding(UiUtils.dp(this, 10), 0, 0, 0);
        tvAttachment.setLayoutParams(new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        attachRow.addView(tvAttachment);

        attachRow.setOnClickListener(v -> openPicker());
        box.addView(attachRow);

        createDialog = new MaterialAlertDialogBuilder(this)
                .setTitle("新建工单")
                .setView(box)
                .setNegativeButton("取消", null)
                .setPositiveButton("提交", null)
                .create();
        createDialog.setOnShowListener(d -> {
            Button submit = createDialog.getButton(DialogInterface.BUTTON_POSITIVE);
            submit.setOnClickListener(v -> submitTicket(etTitle, etDesc));
        });
        createDialog.setOnDismissListener(d -> {
            tvAttachment = null;
            attachmentFile = null;
        });
        createDialog.show();
    }

    private void openPicker() {
        picker.launch(new Intent(this, FileManagerActivity.class));
    }

    private void submitTicket(EditText etTitle, EditText etDesc) {
        String title = etTitle.getText() == null ? "" : etTitle.getText().toString().trim();
        String desc = etDesc.getText() == null ? "" : etDesc.getText().toString().trim();
        if (title.isEmpty()) {
            UiUtils.toast("请输入工单标题");
            return;
        }
        if (desc.isEmpty()) {
            UiUtils.toast("请输入问题描述");
            return;
        }

        Button submit = createDialog == null ? null
                : createDialog.getButton(DialogInterface.BUTTON_POSITIVE);
        if (submit != null) submit.setEnabled(false);

        if (attachmentFile == null) {
            createTicket(title, desc, "", "");
            return;
        }

        Calls.upload("/api/help/tickets/upload", "{}",
                attachmentFile.getAbsolutePath(), "file",
                attachmentName, attachmentMime, json -> {
                    if (json.optInt("code") != 1) {
                        if (submit != null) submit.setEnabled(true);
                        UiUtils.toast(Json.message(json));
                        return;
                    }
                    createTicket(title, desc,
                            json.optString("file_key", ""),
                            json.optString("file_name", attachmentName));
                });
    }

    private void createTicket(String title, String desc, String fileKey, String fileName) {
        JSONObject body = new JSONObject();
        try {
            body.put("title", title);
            body.put("description", desc);
            body.put("file_key", fileKey);
            body.put("file_name", fileName);
        } catch (Exception ignored) {
        }
        Calls.post("/api/help/tickets/create", body.toString(), json -> {
            if (json.optInt("code") != 1) {
                Button submit = createDialog != null && createDialog.isShowing()
                        ? createDialog.getButton(DialogInterface.BUTTON_POSITIVE) : null;
                if (submit != null) submit.setEnabled(true);
                UiUtils.toast(Json.message(json));
                return;
            }
            UiUtils.toast("工单已提交");
            if (createDialog != null && createDialog.isShowing()) createDialog.dismiss();
            attachmentFile = null;
            loadTickets();
        });
    }

    private void importAttachment(Uri uri) {
        String name = queryDisplayName(uri);
        String mime = getContentResolver().getType(uri);
        if (mime == null || mime.isEmpty()) mime = "application/octet-stream";

        File target = null;
        InputStream in = null;
        FileOutputStream out = null;
        try {
            in = "file".equals(uri.getScheme())
                    ? new java.io.FileInputStream(new File(uri.getPath()))
                    : getContentResolver().openInputStream(uri);
            if (in == null) throw new IOException("无法读取附件");
            target = new File(getCacheDir(), System.currentTimeMillis() + "_" + name);
            out = new FileOutputStream(target);
            byte[] buffer = new byte[8192];
            long total = 0;
            int read;
            while ((read = in.read(buffer)) != -1) {
                total += read;
                if (total > MAX_ATTACHMENT) throw new IOException("附件不能超过 15MB");
                out.write(buffer, 0, read);
            }
            attachmentFile = target;
            attachmentName = name;
            attachmentMime = mime;
            if (tvAttachment != null && createDialog != null && createDialog.isShowing()) {
                tvAttachment.setText("已选择：" + name);
                tvAttachment.setTextColor(getColor(R.color.primary));
            }
            UiUtils.toast("附件已就绪");
        } catch (Exception e) {
            attachmentFile = null;
            if (target != null) target.delete();
            UiUtils.toast(e.getMessage() == null ? "附件读取失败" : e.getMessage());
        } finally {
            try {
                if (in != null) in.close();
            } catch (Exception ignored) {
            }
            try {
                if (out != null) out.close();
            } catch (Exception ignored) {
            }
        }
    }

    private String queryDisplayName(Uri uri) {
        String name = "";
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri,
                    new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) name = cursor.getString(index);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        if (name == null || name.trim().isEmpty()) {
            name = "file".equals(uri.getScheme()) && uri.getPath() != null
                    ? new File(uri.getPath()).getName() : "attachment";
        }
        return name.replace("/", "_").replace("\\", "_");
    }

    private EditText dialogInput(String hint, boolean multiline) {
        EditText et = new EditText(this);
        et.setHint(hint);
        et.setHintTextColor(getColor(R.color.on_surface_variant));
        et.setTextColor(getColor(R.color.on_surface));
        et.setTextSize(14);
        et.setBackgroundResource(R.drawable.bg_input);
        int padH = UiUtils.dp(this, 14);
        int padV = UiUtils.dp(this, 12);
        et.setPadding(padH, padV, padH, padV);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = UiUtils.dp(this, 10);
        et.setLayoutParams(lp);
        if (multiline) {
            et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            et.setMinLines(4);
            et.setGravity(Gravity.TOP | Gravity.START);
            et.setMaxLines(8);
        } else {
            et.setInputType(InputType.TYPE_CLASS_TEXT);
            et.setSingleLine(true);
        }
        return et;
    }
}
