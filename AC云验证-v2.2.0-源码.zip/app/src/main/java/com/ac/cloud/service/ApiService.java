package com.ac.cloud.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import com.ac.cloud.BuildConfig;
import com.ac.cloud.IApiService;
import com.ac.cloud.core.Prefs;

import org.json.JSONObject;

import java.io.File;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.ConnectionPool;
import okhttp3.Dispatcher;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * AIDL backend service built on OkHttp.
 *
 * Transport: HTTP/2 multiplexing + TLS 1.3 (platform) + persistent connection
 * pool + transparent gzip. One TCP/TLS connection is shared by every page, so
 * only the very first request pays the handshake cost.
 */
public class ApiService extends Service {

    /** 上传进度回调（同进程 UI 层可直接监听）。 */
    public interface UploadProgress {
        void onProgress(long written, long total);
    }

    public static volatile UploadProgress uploadProgress;

    /** 当前节点基址（欧洲 / 主服务器可在应用内切换）。 */
    public static String base() {
        return com.ac.cloud.core.Servers.base();
    }
    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

    private OkHttpClient client;

    @Override
    public void onCreate() {
        super.onCreate();
        Dispatcher dispatcher = new Dispatcher();
        dispatcher.setMaxRequests(64);
        dispatcher.setMaxRequestsPerHost(16);
        client = new OkHttpClient.Builder()
                .connectionPool(new ConnectionPool(8, 15, TimeUnit.MINUTES))
                .dispatcher(dispatcher)
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(25, TimeUnit.SECONDS)
                .writeTimeout(90, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .followRedirects(false)
                .followSslRedirects(false)
                .protocols(Arrays.asList(Protocol.HTTP_2, Protocol.HTTP_1_1))
                .build();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    private final IApiService.Stub binder = new IApiService.Stub() {
        @Override
        public String login(String account, String password) {
            try {
                RequestBody body = new FormBody.Builder()
                        .add("username", account == null ? "" : account)
                        .add("password", password == null ? "" : password)
                        .build();
                Request request = builder("/login")
                        .post(body)
                        .header("Content-Type", "application/x-www-form-urlencoded")
                        .build();
                try (Response response = client.newCall(request).execute()) {
                    captureCookies(response);
                    if (Prefs.getString("cookie", null) == null) {
                        return error("账号或密码错误");
                    }
                }
                String user = execute(builder("/api/user/info").get().build());
                JSONObject json = new JSONObject(user);
                if (json.optInt("code") != 1) {
                    Prefs.clearSession();
                    return user;
                }
                Prefs.putString("user_json", user);
                Prefs.putString("api_key", json.optString("api_key"));
                Prefs.putString("last_account", account == null ? "" : account);
                Prefs.putBool("logged_in", true);
                return user;
            } catch (Exception e) {
                return error(friendly(e));
            }
        }

        @Override
        public String register(String acId, String displayName, String email, String emailCode, String password) {
            try {
                JSONObject body = new JSONObject();
                body.put("ac_id", acId);
                body.put("display_name", displayName);
                body.put("email", email);
                body.put("email_code", emailCode);
                body.put("password", password);
                return postNow("/api/app/register", body.toString());
            } catch (Exception e) {
                return error(friendly(e));
            }
        }

        @Override
        public String sendEmailCode(String email, String scene) {
            try {
                JSONObject body = new JSONObject();
                body.put("email", email);
                body.put("scene", scene);
                return postNow("/api/email/send_code", body.toString());
            } catch (Exception e) {
                return error(friendly(e));
            }
        }

        @Override
        public String get(String path) {
            try {
                return execute(builder(path).get().build());
            } catch (Exception e) {
                return error(friendly(e));
            }
        }

        @Override
        public String post(String path, String jsonBody) {
            try {
                return postNow(path, jsonBody);
            } catch (Exception e) {
                return error(friendly(e));
            }
        }

        @Override
        public String delete(String path, String jsonBody) {
            try {
                return execute(builder(path)
                        .delete(RequestBody.create(JSON, jsonBody == null ? "{}" : jsonBody))
                        .build());
            } catch (Exception e) {
                return error(friendly(e));
            }
        }

        @Override
        public String postForm(String path, String formBody) {
            try {
                Request request = builder(path)
                        .post(RequestBody.create(MediaType.parse("application/x-www-form-urlencoded; charset=utf-8"),
                                formBody == null ? "" : formBody))
                        .build();
                return execute(request);
            } catch (Exception e) {
                return error(friendly(e));
            }
        }

        @Override
        public boolean isLoggedIn() {
            return Prefs.getBool("logged_in", false) && Prefs.getString("cookie", null) != null;
        }

        @Override
        public String getSessionCookie() {
            return Prefs.getString("cookie", "");
        }

        @Override
        public String getUserJson() {
            return Prefs.getString("user_json", "{}");
        }

        @Override
        public String getApiKey() {
            return Prefs.getString("api_key", "");
        }

        @Override
        public String ping() {
            long start = System.currentTimeMillis();
            try {
                Request request = new Request.Builder()
                        .url(base() + "/")
                        .header("User-Agent", "ACCloudApp/2.0")
                        .get()
                        .build();
                try (Response response = client.newCall(request).execute()) {
                    long cost = System.currentTimeMillis() - start;
                    return "{\"code\":" + (response.isSuccessful() ? 1 : 0)
                            + ",\"latency\":" + cost + "}";
                }
            } catch (Exception e) {
                return error(friendly(e));
            }
        }

        @Override
        public String warmup() {
            // C++ 层先完成 DNS + TCP 握手预热，再由 OkHttp 建立 TLS + HTTP/2。
            int tcp = -1;
            try {
                tcp = com.ac.cloud.core.NativeCore.tcpWarm(
                        com.ac.cloud.core.Servers.host(), 443);
            } catch (Throwable ignored) {
            }
            long start = System.currentTimeMillis();
            try {
                Request request = builder("/").get().build();
                try (Response response = client.newCall(request).execute()) {
                    return "{\"code\":1,\"latency\":" + (System.currentTimeMillis() - start)
                            + ",\"tcp\":" + tcp + "}";
                }
            } catch (Exception e) {
                return error(friendly(e));
            }
        }

        @Override
        public String appTokenLogin(String token) {
            try {
                JSONObject body = new JSONObject();
                body.put("token", token == null ? "" : token);
                String result = postNow("/api/app/token_login", body.toString());
                JSONObject json = new JSONObject(result);
                if (json.optInt("code") != 1) return result;
                String user = execute(builder("/api/user/info").get().build());
                JSONObject info = new JSONObject(user);
                if (info.optInt("code") != 1) {
                    Prefs.clearSession();
                    return user;
                }
                Prefs.putString("user_json", user);
                Prefs.putString("api_key", info.optString("api_key"));
                Prefs.putBool("logged_in", true);
                return user;
            } catch (Exception e) {
                return error(friendly(e));
            }
        }

        @Override
        public String appGoogleUrl() {
            try {
                return execute(builder("/api/app/google_url").get().build());
            } catch (Exception e) {
                return error(friendly(e));
            }
        }

        @Override
        public String upload(String path, String fieldsJson, String filePath, String fileField,
                             String fileName, String mimeType) {
            try {
                File file = new File(filePath);
                if (!file.exists()) return error("文件不存在");
                MediaType type = MediaType.parse(mimeType == null || mimeType.isEmpty()
                        ? "application/octet-stream" : mimeType);
                MultipartBody.Builder multipart = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM);
                JSONObject fields = new JSONObject(fieldsJson == null ? "{}" : fieldsJson);
                Iterator<String> keys = fields.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    multipart.addFormDataPart(key, fields.optString(key, ""));
                }
                multipart.addFormDataPart(fileField == null || fileField.isEmpty() ? "file" : fileField,
                        fileName == null || fileName.isEmpty() ? file.getName() : fileName,
                        new RequestBody() {
                            @Override
                            public MediaType contentType() {
                                return type;
                            }

                            @Override
                            public long contentLength() {
                                return file.length();
                            }

                            @Override
                            public void writeTo(okio.BufferedSink sink) throws java.io.IOException {
                                try (java.io.InputStream in = new java.io.FileInputStream(file)) {
                                    byte[] buffer = new byte[8192];
                                    long written = 0;
                                    int read;
                                    while ((read = in.read(buffer)) != -1) {
                                        sink.write(buffer, 0, read);
                                        written += read;
                                        UploadProgress cb = uploadProgress;
                                        if (cb != null) cb.onProgress(written, file.length());
                                    }
                                }
                            }
                        });
                Request request = builder(path).post(multipart.build()).build();
                return execute(request);
            } catch (Exception e) {
                return error(friendly(e));
            }
        }

        @Override
        public void logout() {
            try {
                execute(builder("/logout").get().build());
            } catch (Exception ignored) {
            }
            Prefs.clearSession();
        }
    };

    private Request.Builder builder(String path) {
        Request.Builder builder = new Request.Builder()
                .url(base() + path)
                .header("Accept", "application/json")
                .header("User-Agent", "ACCloudApp/2.0 (Android)");
        String cookie = Prefs.getString("cookie", null);
        if (cookie != null) builder.header("Cookie", cookie);
        return builder;
    }

    private String postNow(String path, String json) throws Exception {
        return execute(builder(path)
                .post(RequestBody.create(JSON, json == null ? "{}" : json))
                .build());
    }

    private String execute(Request request) throws Exception {
        try (Response response = client.newCall(request).execute()) {
            captureCookies(response);
            String body = response.body() == null ? "" : response.body().string();
            if (body.isEmpty()) {
                return "{\"code\":0,\"message\":\"HTTP " + response.code()
                        + "\",\"_http\":" + response.code() + "}";
            }
            return body;
        }
    }

    private void captureCookies(Response response) {
        List<String> cookies = response.headers("Set-Cookie");
        for (String value : cookies) {
            for (String part : value.split(";")) {
                String p = part.trim();
                if (p.startsWith("session=")) {
                    Prefs.putString("cookie", p);
                    return;
                }
            }
        }
    }

    private static String friendly(Exception e) {
        String msg = e.getMessage();
        if (msg == null) msg = e.getClass().getSimpleName();
        if (msg.contains("Unable to resolve host")) return "无法解析服务器域名，请检查网络";
        if (msg.contains("timeout") || msg.contains("timed out")) return "连接超时，请稍后重试";
        if (msg.contains("SSL") || msg.contains("Certificate")) return "安全连接失败，请检查系统时间";
        return msg;
    }

    private static String error(String msg) {
        try {
            JSONObject json = new JSONObject();
            json.put("code", 0);
            json.put("message", msg);
            return json.toString();
        } catch (Exception e) {
            return "{\"code\":0,\"message\":\"未知错误\"}";
        }
    }
}
