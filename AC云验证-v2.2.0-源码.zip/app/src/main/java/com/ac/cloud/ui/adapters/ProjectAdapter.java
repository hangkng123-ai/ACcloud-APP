package com.ac.cloud.ui.adapters;

import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ac.cloud.R;
import com.ac.cloud.databinding.ItemProjectBinding;

import org.json.JSONArray;
import org.json.JSONObject;

public class ProjectAdapter extends RecyclerView.Adapter<ProjectAdapter.VH> {

    public interface Listener {
        void onManage(JSONObject project);

        void onMore(JSONObject project);

        void onLogs(JSONObject project);
    }

    private final boolean server;
    private final Listener listener;
    private JSONArray items = new JSONArray();

    public ProjectAdapter(boolean server, Listener listener) {
        this.server = server;
        this.listener = listener;
    }

    public void submit(JSONArray array) {
        items = array == null ? new JSONArray() : array;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(ItemProjectBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        JSONObject p = items.optJSONObject(position);
        if (p == null) return;
        android.content.Context ctx = h.b.getRoot().getContext();

        h.b.tvName.setText(p.optString("name", "项目"));
        h.b.tvSub.setText(p.optString("subdomain", p.optString("project_id", "")));
        h.b.ivIcon.setImageResource(server ? R.drawable.ic_rocket : R.drawable.ic_language);

        String domain = p.optString("full_domain", "");
        String url = domain.isEmpty() ? "" : "https://" + domain + "/";
        h.b.tvDomain.setText(url.isEmpty() ? "等待分配域名" : url);
        h.b.rowDomain.setOnClickListener(v -> {
            if (!url.isEmpty()) {
                try {
                    ctx.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) {
                }
            }
        });
        h.b.btnOpen.setVisibility(url.isEmpty() ? View.GONE : View.VISIBLE);

        boolean https = p.optBoolean("https_enabled", true);
        h.b.tvHttps.setText(https ? "HTTPS 开" : "HTTPS 关");
        h.b.tvHttps.setBackgroundResource(https
                ? R.drawable.bg_chip_success : R.drawable.bg_chip_warn);
        h.b.tvHttps.setTextColor(ctx.getColor(https
                ? R.color.chip_success_fg : R.color.chip_warn_fg));

        if (server) {
            String status = p.optString("status", "pending");
            String label = "pending".equals(status) ? "待审批"
                    : "approved".equals(status) ? "已批准"
                    : "rejected".equals(status) ? "已拒绝" : status;
            h.b.tvStatus.setText(label);
            h.b.tvStatus.setBackgroundResource("approved".equals(status)
                    ? R.drawable.bg_chip_success
                    : "rejected".equals(status) ? R.drawable.bg_chip_danger : R.drawable.bg_chip_warn);
            h.b.tvStatus.setTextColor(ctx.getColor("approved".equals(status)
                    ? R.color.chip_success_fg
                    : "rejected".equals(status) ? R.color.chip_danger_fg : R.color.chip_warn_fg));

            boolean guard = p.optBoolean("sensitive_guard", true);
            h.b.tvGuard.setVisibility(View.VISIBLE);
            h.b.tvGuard.setText(guard ? "防护开" : "防护关");
            h.b.tvGuard.setBackgroundResource(guard
                    ? R.drawable.bg_chip_info : R.drawable.bg_chip_warn);
            h.b.tvGuard.setTextColor(ctx.getColor(guard
                    ? R.color.chip_info_fg : R.color.chip_warn_fg));

            String crash = p.optString("crash_status", "healthy");
            if ("healthy".equals(crash)) {
                h.b.tvCrash.setVisibility(View.GONE);
            } else {
                h.b.tvCrash.setVisibility(View.VISIBLE);
                h.b.tvCrash.setText("异常 " + p.optInt("crash_errors", 0));
            }
            h.b.btnLogs.setVisibility(View.VISIBLE);
            h.b.tvMeta.setText(p.optInt("file_count", 0) + " 文件 · "
                    + p.optDouble("total_size_kb", 0) + " KB · 访问 "
                    + p.optInt("visit_count", 0));
        } else {
            h.b.tvStatus.setText("静态站点");
            h.b.tvStatus.setBackgroundResource(R.drawable.bg_chip_purple);
            h.b.tvStatus.setTextColor(ctx.getColor(R.color.chip_purple_fg));
            h.b.tvGuard.setVisibility(View.GONE);
            h.b.tvCrash.setVisibility(View.GONE);
            h.b.btnLogs.setVisibility(View.GONE);
            h.b.tvMeta.setText(p.optInt("file_count", 0) + " 文件 · "
                    + p.optString("total_size_str", "0 KB") + " · 访问 "
                    + p.optInt("visit_count", 0));
        }

        h.b.btnManage.setOnClickListener(v -> listener.onManage(p));
        h.b.btnMore.setOnClickListener(v -> listener.onMore(p));
        h.b.btnLogs.setOnClickListener(v -> listener.onLogs(p));
        h.b.getRoot().setOnClickListener(v -> listener.onManage(p));
    }

    @Override
    public int getItemCount() {
        return items.length();
    }

    static class VH extends RecyclerView.ViewHolder {
        final ItemProjectBinding b;

        VH(ItemProjectBinding binding) {
            super(binding.getRoot());
            b = binding;
        }
    }
}
