package com.ac.cloud.ui.adapters;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.CompoundButton;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ac.cloud.databinding.ItemVariableBinding;

import org.json.JSONArray;
import org.json.JSONObject;

public class VariableAdapter extends RecyclerView.Adapter<VariableAdapter.VH> {

    public interface Listener {
        void onToggle(JSONObject variable, boolean value);

        void onLongPress(JSONObject variable);
    }

    private JSONArray items = new JSONArray();
    private final Listener listener;

    public VariableAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submit(JSONArray array) {
        items = array == null ? new JSONArray() : array;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(ItemVariableBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        JSONObject item = items.optJSONObject(position);
        if (item == null) return;
        holder.b.tvName.setText(item.optString("name", "变量"));
        holder.b.tvVarId.setText(item.optString("id", ""));
        boolean value = item.optBoolean("value");
        holder.b.switchValue.setOnCheckedChangeListener(null);
        holder.b.switchValue.setChecked(value);
        holder.b.switchValue.setOnCheckedChangeListener((CompoundButton button, boolean checked) -> {
            if (checked != value) listener.onToggle(item, checked);
        });
        holder.b.getRoot().setOnLongClickListener(v -> {
            listener.onLongPress(item);
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return items.length();
    }

    static class VH extends RecyclerView.ViewHolder {
        final ItemVariableBinding b;

        VH(ItemVariableBinding binding) {
            super(binding.getRoot());
            b = binding;
        }
    }
}
