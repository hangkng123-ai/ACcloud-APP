package com.ac.cloud.ui.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ac.cloud.databinding.ItemDocumentBinding;

import org.json.JSONArray;
import org.json.JSONObject;

public class DocumentAdapter extends RecyclerView.Adapter<DocumentAdapter.VH> {

    public interface OnDocumentAction {
        void onDownload(JSONObject document);

        void onCopyLink(JSONObject document);
    }

    private JSONArray items = new JSONArray();
    private final OnDocumentAction listener;

    public DocumentAdapter(OnDocumentAction listener) {
        this.listener = listener;
    }

    public void submit(JSONArray array) {
        items = array == null ? new JSONArray() : array;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(ItemDocumentBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        JSONObject item = items.optJSONObject(position);
        if (item == null) return;

        holder.b.tvTitle.setText(item.optString("title", "未命名文档"));

        String version = item.optString("version", "");
        if (version.isEmpty()) version = "1.0";
        holder.b.tvVersion.setText(version.startsWith("v") ? version : "v" + version);

        String size = item.optString("file_size_mb", "");
        holder.b.tvSize.setText(size.isEmpty() ? "大小 --" : size + " MB");

        String desc = item.optString("description", "");
        holder.b.tvDescription.setVisibility(desc.isEmpty() ? View.GONE : View.VISIBLE);
        holder.b.tvDescription.setText(desc);

        String fileName = item.optString("file_name", "");
        holder.b.tvFileName.setText(fileName.isEmpty() ? "未命名文件" : fileName);

        String upload = item.optString("upload_time", "");
        holder.b.tvUploadTime.setText("上传于 " + (upload.isEmpty() ? "--" : upload));

        holder.b.btnDownload.setOnClickListener(v -> {
            if (listener != null) listener.onDownload(item);
        });
        holder.b.btnCopy.setOnClickListener(v -> {
            if (listener != null) listener.onCopyLink(item);
        });
    }

    @Override
    public int getItemCount() {
        return items.length();
    }

    public static class VH extends RecyclerView.ViewHolder {
        final ItemDocumentBinding b;

        VH(ItemDocumentBinding binding) {
            super(binding.getRoot());
            b = binding;
        }
    }
}
