package com.ac.cloud.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.ac.cloud.R;
import com.ac.cloud.core.Json;
import com.ac.cloud.core.NativeCore;
import com.ac.cloud.core.Prefs;
import com.ac.cloud.core.Servers;
import com.ac.cloud.databinding.ActivityLoginBinding;
import com.ac.cloud.net.Api;
import com.ac.cloud.net.Io;
import com.ac.cloud.util.UiUtils;
import com.ac.cloud.IApiService;

import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity {

    private ActivityLoginBinding b;
    private boolean loading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiUtils.edgeToEdge(this);
        b = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        UiUtils.applyInsets(b.getRoot());

        String saved = Prefs.getString("last_account", "");
        if (!saved.isEmpty()) b.etAccount.setText(saved);

        b.btnLogin.setOnClickListener(v -> doLogin());
        b.tvRegister.setOnClickListener(v ->
                startActivity(new Intent(this, RegisterActivity.class)));
        b.tvForgot.setOnClickListener(v ->
                startActivity(new Intent(this, ResetPasswordActivity.class)));
        b.btnWebLogin.setOnClickListener(v -> webLogin());
        b.tvServerStatus.setOnClickListener(v -> checkServer());
        b.btnSettings.setOnClickListener(v -> Servers.show(this, false, () -> {
            b.tvServerName.setText(Servers.name());
            checkServer();
        }));
        b.tvServerName.setText(Servers.name());

        Servers.ensure(this, this::checkServer);
        handleAuthIntent(getIntent());

        if (Prefs.getBool("logged_in", false) && !Prefs.getString("cookie", "").isEmpty()) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        }
    }

    private void checkServer() {
        b.tvServerStatus.setText(R.string.server_checking);
        Api.ready(() -> Io.run(() -> {
            String raw;
            try {
                raw = Api.get().ping();
            } catch (Exception e) {
                raw = "{}";
            }
            JSONObject json = Json.parse(raw);
            boolean ok = json.optInt("code") == 1;
            int latency = json.optInt("latency", 0);
            int tcp = -1;
            try {
                tcp = NativeCore.tcpProbe(Servers.host(), 443);
            } catch (Throwable ignored) {
            }
            final int tcpMs = tcp;
            Io.main(() -> {
                if (ok) {
                    b.tvServerStatus.setText("服务运行中 · " + latency + " ms"
                            + (tcpMs >= 0 ? " · C++ " + tcpMs + " ms" : ""));
                } else {
                    b.tvServerStatus.setText(R.string.server_fail);
                }
            });
        }));
    }

    private void doLogin() {
        if (loading) return;
        String account = text(b.etAccount);
        String password = text(b.etPassword);
        if (account.isEmpty() || password.isEmpty()) {
            UiUtils.toast("请输入账号和密码");
            return;
        }
        setLoading(true);
        Api.ready(() -> Io.run(() -> {
            String raw;
            try {
                raw = Api.get().login(account, password);
            } catch (Exception e) {
                raw = "{\"code\":0,\"message\":\"服务连接失败\"}";
            }
            JSONObject json = Json.parse(raw);
            if (Json.ok(json)) {
                Prefs.putBool("remember", b.switchRemember.isChecked());
                if (b.switchRemember.isChecked()) Prefs.putString("last_account", account);
                Io.main(() -> {
                    startActivity(new Intent(this, MainActivity.class));
                    finish();
                });
            } else {
                final String[] message = {Json.message(json)};
                Io.run(() -> {
                    try {
                        JSONObject body = new JSONObject();
                        body.put("user_id", account);
                        body.put("password", password);
                        String detail = Api.get().post("/api/app/login", body.toString());
                        JSONObject dj = Json.parse(detail);
                        String dm = Json.message(dj);
                        if (!dm.isEmpty() && !"操作失败，请稍后重试".equals(dm)) message[0] = dm;
                    } catch (Exception ignored) {
                    }
                    final String finalMsg = message[0];
                    Io.main(() -> {
                        setLoading(false);
                        UiUtils.toast(finalMsg);
                    });
                });
            }
        }));
    }

    private void setLoading(boolean value) {
        loading = value;
        b.btnLogin.setEnabled(!value);
        b.btnLogin.setText(value ? R.string.logging_in : R.string.login);
    }

    private void webLogin() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    android.net.Uri.parse(Servers.base() + "/app/login")));
        } catch (Exception e) {
            UiUtils.toast("未找到可用浏览器");
        }
    }

    /** 浏览器授权完成后通过 accloud://auth?token=xxx 返回应用。 */
    private void handleAuthIntent(Intent intent) {
        if (intent == null || intent.getData() == null) return;
        android.net.Uri uri = intent.getData();
        if (!"accloud".equals(uri.getScheme()) || !"auth".equals(uri.getHost())) return;
        String token = uri.getQueryParameter("token");
        if (token == null || token.isEmpty()) return;
        setLoading(true);
        Api.ready(() -> Io.run(() -> {
            String raw;
            try {
                raw = Api.get().appTokenLogin(token);
            } catch (Exception e) {
                raw = "{\"code\":0,\"message\":\"登录失败\"}";
            }
            JSONObject json = Json.parse(raw);
            Io.main(() -> {
                setLoading(false);
                if (Json.ok(json)) {
                    startActivity(new Intent(this, MainActivity.class));
                    finish();
                } else {
                    UiUtils.toast(Json.message(json));
                }
            });
        }));
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleAuthIntent(intent);
    }


    private static String text(android.widget.TextView view) {
        return view.getText() == null ? "" : view.getText().toString().trim();
    }
}
