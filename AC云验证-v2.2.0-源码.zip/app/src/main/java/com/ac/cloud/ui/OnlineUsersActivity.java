package com.ac.cloud.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ac.cloud.core.Json;
import com.ac.cloud.core.Prefs;
import com.ac.cloud.databinding.ActivityOnlineUsersBinding;
import com.ac.cloud.net.Calls;
import com.ac.cloud.ui.adapters.OnlineUserAdapter;
import com.ac.cloud.util.UiUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class OnlineUsersActivity extends AppCompatActivity {

    private ActivityOnlineUsersBinding b;
    private OnlineUserAdapter adapter;
    private final List<String> ids = new ArrayList<>();
    private final List<String> labels = new ArrayList<>();
    private String selectedId = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiUtils.edgeToEdge(this);
        b = ActivityOnlineUsersBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        UiUtils.applyInsets(b.getRoot());
        b.btnBack.setOnClickListener(v -> finish());
        b.btnRefresh.setOnClickListener(v -> loadStatus());

        adapter = new OnlineUserAdapter();
        b.recycler.setLayoutManager(new LinearLayoutManager(this));
        b.recycler.setAdapter(adapter);
        b.swipe.setOnRefreshListener(this::loadStatus);

        b.dropdownInstance.setOnItemClickListener((parent, view, position, id) -> {
            if (position < ids.size()) {
                selectedId = ids.get(position);
                loadStatus();
            }
        });
        loadInstances();
    }

    private void loadInstances() {
        Calls.get("/api/instances", json -> {
            JSONArray arr = Json.array(json, "instances");
            ids.clear();
            labels.clear();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject item = arr.optJSONObject(i);
                if (item == null) continue;
                ids.add(item.optString("instance_id"));
                labels.add(item.optString("name", "") + "  ·  " + item.optString("instance_id"));
            }
            b.dropdownInstance.setAdapter(new ArrayAdapter<>(this,
                    android.R.layout.simple_list_item_1, labels));
            if (ids.isEmpty()) {
                b.dropdownInstance.setText("", false);
                b.emptyView.setVisibility(View.VISIBLE);
                b.recycler.setVisibility(View.GONE);
                UiUtils.toast("请先创建应用实例");
                return;
            }
            String preferred = Prefs.getString("selected_instance", "");
            int index = ids.indexOf(preferred);
            if (index < 0) index = 0;
            selectedId = ids.get(index);
            b.dropdownInstance.setText(labels.get(index), false);
            loadStatus();
        });
    }

    private void loadStatus() {
        if (selectedId.isEmpty()) return;
        String apiKey = Prefs.getString("api_key", "");
        try {
            JSONObject body = new JSONObject();
            body.put("instance_id", selectedId);
            body.put("api_key", apiKey);
            Calls.post("/api/online/status", body.toString(), json -> {
                b.swipe.setRefreshing(false);
                if (json.optInt("code") != 1) {
                    UiUtils.toast(Json.message(json));
                    return;
                }
                JSONArray users = Json.array(json, "users");
                adapter.submit(users);
                b.tvOnlineCount.setText(String.valueOf(json.optInt("online_count", 0)));
                b.tvOfflineCount.setText(String.valueOf(json.optInt("offline_count", 0)));
                b.tvTotalCount.setText(String.valueOf(json.optInt("total_users", users.length())));
                b.emptyView.setVisibility(users.length() == 0 ? View.VISIBLE : View.GONE);
                b.recycler.setVisibility(users.length() == 0 ? View.GONE : View.VISIBLE);
            });
        } catch (Exception ignored) {
        }
    }
}
