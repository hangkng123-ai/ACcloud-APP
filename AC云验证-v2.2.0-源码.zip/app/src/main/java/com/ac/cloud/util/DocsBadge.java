package com.ac.cloud.util;

import android.content.Context;

import com.ac.cloud.R;
import com.ac.cloud.core.Prefs;

import org.json.JSONArray;
import org.json.JSONObject;

/** Tracks whether the document list contains a newer file than the last seen one. */
public final class DocsBadge {

    private DocsBadge() {
    }

    public static String latestToken(JSONObject json) {
        JSONArray docs = json == null ? null : json.optJSONArray("documents");
        if (docs == null || docs.length() == 0) return "";
        JSONObject first = docs.optJSONObject(0);
        if (first == null) return "";
        return first.optString("doc_id", "") + "|" + first.optString("upload_time", "");
    }

    public static boolean hasNew(JSONObject json) {
        String token = latestToken(json);
        if (token.isEmpty()) return false;
        String seen = Prefs.getString("docs_seen", "");
        return !token.equals(seen);
    }

    public static void markSeen(Context context, JSONObject json) {
        Prefs.putString("docs_seen", latestToken(json));
    }
}
