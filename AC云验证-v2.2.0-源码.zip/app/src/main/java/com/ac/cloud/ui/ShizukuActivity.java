package com.ac.cloud.ui;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.ac.cloud.R;
import com.ac.cloud.core.NativeCore;
import com.ac.cloud.core.Servers;
import com.ac.cloud.core.ShizukuManager;
import com.ac.cloud.net.Io;
import com.ac.cloud.util.UiUtils;

public class ShizukuActivity extends AppCompatActivity {

    private TextView tvStatus;
    private TextView tvOutput;
    private Button btnGrant;
    private final Handler main = new Handler(Looper.getMainLooper());

    private final rikka.shizuku.Shizuku.OnRequestPermissionResultListener permissionListener =
            (requestCode, grantResult) -> renderStatus();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiUtils.edgeToEdge(this);
        setContentView(R.layout.activity_shizuku);
        UiUtils.applyInsets(findViewById(R.id.rootShizuku));

        TextView title = findViewById(R.id.tvTitle);
        TextView subtitle = findViewById(R.id.tvSubtitle);
        title.setText("Shizuku 系统增强");
        subtitle.setText("系统级权限 · 网络加速 · C++ 连接优化");
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        tvStatus = findViewById(R.id.tvShizukuStatus);
        tvOutput = findViewById(R.id.tvShizukuOutput);
        btnGrant = findViewById(R.id.btnShizukuGrant);

        btnGrant.setOnClickListener(v -> {
            if (!ShizukuManager.available()) {
                UiUtils.toast("未检测到 Shizuku，请先安装并启动 Shizuku");
                return;
            }
            ShizukuManager.request(this);
            main.postDelayed(this::renderStatus, 600);
        });

        findViewById(R.id.actPing).setOnClickListener(v -> run(
                "ping -c 4 -W 2 " + Servers.host()));
        findViewById(R.id.actOptimize).setOnClickListener(v -> run(
                ShizukuManager.optimizeNetwork()));
        findViewById(R.id.actDns).setOnClickListener(v -> run(
                "ndc resolver flushdefaultif; echo DNS 缓存已刷新"));
        findViewById(R.id.actInfo).setOnClickListener(v -> run(
                "ip addr show wlan0; echo ---; getprop net.dns1"));

        try {
            rikka.shizuku.Shizuku.addRequestPermissionResultListener(permissionListener);
        } catch (Throwable ignored) {
        }
        renderStatus();
    }

    private void renderStatus() {
        boolean available = ShizukuManager.available();
        boolean granted = ShizukuManager.granted();
        if (!available) {
            tvStatus.setText("Shizuku 未运行");
            btnGrant.setText("安装并启动 Shizuku");
            btnGrant.setEnabled(true);
        } else if (granted) {
            tvStatus.setText("Shizuku 已授权");
            btnGrant.setText("已获得系统级权限");
            btnGrant.setEnabled(false);
        } else {
            tvStatus.setText("等待授权");
            btnGrant.setText("授权 Shizuku");
            btnGrant.setEnabled(true);
        }
    }

    private void run(String command) {
        if (!ShizukuManager.granted()) {
            UiUtils.toast("请先授权 Shizuku");
            renderStatus();
            return;
        }
        tvOutput.setText("执行中…");
        Io.run(() -> {
            String out = ShizukuManager.exec(command);
            int tcp = -1;
            try {
                tcp = NativeCore.tcpProbe(Servers.host(), 443);
            } catch (Throwable ignored) {
            }
            final String text = out + "\n\n[C++] TCP 握手 "
                    + (tcp >= 0 ? tcp + " ms" : "失败");
            Io.main(() -> tvOutput.setText(text));
        });
    }

    @Override
    protected void onDestroy() {
        try {
            rikka.shizuku.Shizuku.removeRequestPermissionResultListener(permissionListener);
        } catch (Throwable ignored) {
        }
        super.onDestroy();
    }
}
