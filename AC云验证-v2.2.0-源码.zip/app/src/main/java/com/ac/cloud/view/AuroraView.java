package com.ac.cloud.view;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

import androidx.annotation.Nullable;

/**
 * Animated aurora backdrop used behind hero areas. Three soft light blobs
 * drift slowly, giving the glass surfaces a living glow.
 */
public class AuroraView extends View {

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float phase = 0f;
    private final Paint basePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private boolean night;

    public AuroraView(Context context) {
        this(context, null);
    }

    public AuroraView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        setLayerType(LAYER_TYPE_HARDWARE, null);
        night = (getResources().getConfiguration().uiMode & 0x30) == 0x20;
        ValueAnimator animator = ValueAnimator.ofFloat(0f, (float) (Math.PI * 2));
        animator.setDuration(18000);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(a -> {
            phase = (float) a.getAnimatedValue();
            invalidate();
        });
        animator.start();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w == 0 || h == 0) return;

        int top = night ? Color.parseColor("#101216") : Color.parseColor("#F8FAFF");
        int bottom = night ? Color.parseColor("#0A0B0E") : Color.parseColor("#EDF2FB");
        basePaint.setShader(new LinearGradient(0, 0, 0, h, top, bottom, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, basePaint);

        drawBlob(canvas, w * (0.22f + 0.06f * (float) Math.sin(phase)),
                h * (0.18f + 0.05f * (float) Math.cos(phase * 0.8)),
                Math.max(w, h) * 0.55f,
                night ? 0x558AB4F8 : 0x552E86F0);

        drawBlob(canvas, w * (0.85f + 0.05f * (float) Math.cos(phase * 0.7)),
                h * (0.10f + 0.08f * (float) Math.sin(phase * 0.6)),
                Math.max(w, h) * 0.5f,
                night ? 0x44C58AF9 : 0x3FA142F4);

        drawBlob(canvas, w * (0.55f + 0.08f * (float) Math.sin(phase * 0.5)),
                h * (0.85f + 0.04f * (float) Math.cos(phase * 0.9)),
                Math.max(w, h) * 0.6f,
                night ? 0x334DD8FF : 0x2E00D4FF);

        // Glowing cores layered on top of the soft blobs.
        float pulse = 0.9f + 0.1f * (float) Math.sin(phase * 1.6);
        drawBlob(canvas, w * (0.22f + 0.06f * (float) Math.sin(phase)),
                h * (0.18f + 0.05f * (float) Math.cos(phase * 0.8)),
                Math.max(w, h) * 0.14f * pulse,
                night ? 0x668AB4F8 : 0x552E86F0);
        drawBlob(canvas, w * (0.85f + 0.05f * (float) Math.cos(phase * 0.7)),
                h * (0.10f + 0.08f * (float) Math.sin(phase * 0.6)),
                Math.max(w, h) * 0.12f * pulse,
                night ? 0x55C58AF9 : 0x44A142F4);

        paint.setShader(null);
    }

    private void drawBlob(Canvas canvas, float cx, float cy, float radius, int color) {
        paint.setShader(new RadialGradient(cx, cy, radius, color, Color.TRANSPARENT,
                Shader.TileMode.CLAMP));
        canvas.drawCircle(cx, cy, radius, paint);
    }
}
