package com.ac.cloud.ui;

import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ac.cloud.R;
import com.ac.cloud.core.Json;
import com.ac.cloud.databinding.ActivityDocumentsBinding;
import com.ac.cloud.net.Calls;
import com.ac.cloud.service.ApiService;
import com.ac.cloud.ui.adapters.DocumentAdapter;
import com.ac.cloud.util.UiUtils;

import org.json.JSONArray;
import org.json.JSONObject;

public class DocumentsActivity extends AppCompatActivity {

    private ActivityDocumentsBinding b;
    private DocumentAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiUtils.edgeToEdge(this);
        b = ActivityDocumentsBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        UiUtils.applyInsets(b.getRoot());

        b.header.tvTitle.setText("对接下载");
        b.header.tvSubtitle.setText("SDK 与接入资源");
        b.header.btnBack.setOnClickListener(v -> finish());
        b.header.btnAction.setVisibility(View.VISIBLE);
        b.header.ivAction.setImageResource(R.drawable.ic_refresh);
        b.header.btnAction.setOnClickListener(v -> loadDocuments());

        adapter = new DocumentAdapter(new DocumentAdapter.OnDocumentAction() {
            @Override
            public void onDownload(JSONObject document) {
                download(document);
            }

            @Override
            public void onCopyLink(JSONObject document) {
                String url = absoluteUrl(document.optString("file_url", ""));
                if (url.isEmpty()) {
                    UiUtils.toast("下载地址为空");
                    return;
                }
                UiUtils.copy("下载链接", url);
            }
        });
        b.recycler.setLayoutManager(new LinearLayoutManager(this));
        b.recycler.setAdapter(adapter);
        b.swipe.setOnRefreshListener(this::loadDocuments);

        loadDocuments();
    }

    private void loadDocuments() {
        Calls.get("/api/documents", json -> {
            b.swipe.setRefreshing(false);
            if (json.optInt("code") != 1) {
                UiUtils.toast(Json.message(json));
                return;
            }
            JSONArray documents = Json.array(json, "documents");
            adapter.submit(documents);
            boolean empty = documents.length() == 0;
            b.emptyView.setVisibility(empty ? View.VISIBLE : View.GONE);
            b.recycler.setVisibility(empty ? View.GONE : View.VISIBLE);
        });
    }

    private void download(JSONObject document) {
        String url = absoluteUrl(document.optString("file_url", ""));
        if (url.isEmpty()) {
            UiUtils.toast("下载地址为空");
            return;
        }
        String fileName = document.optString("file_name", "");
        if (fileName.isEmpty()) fileName = document.optString("title", "document");
        fileName = fileName.replaceAll("[\\\\/:*?\"<>|]", "_");
        if (fileName.isEmpty()) fileName = "document.bin";

        try {
            DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            if (manager == null) {
                UiUtils.toast("下载服务不可用");
                return;
            }
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setTitle(document.optString("title", "文档下载"));
            request.setDescription("AC 云验证 · 对接资源");
            request.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(true);
            long id = manager.enqueue(request);
            if (id == -1) {
                UiUtils.toast("下载任务创建失败");
            } else {
                UiUtils.toast("已加入下载：" + fileName);
            }
        } catch (Exception e) {
            UiUtils.toast("下载失败：" + (e.getMessage() == null ? "未知错误" : e.getMessage()));
        }
    }

    private String absoluteUrl(String url) {
        if (url == null) return "";
        if (url.startsWith("http://") || url.startsWith("https://")) return url;
        if (url.isEmpty()) return "";
        return ApiService.base() + (url.startsWith("/") ? url : "/" + url);
    }
}
