package com.ac.cloud.ui;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.ac.cloud.R;
import com.ac.cloud.core.Json;
import com.ac.cloud.databinding.SheetInstanceDetailBinding;
import com.ac.cloud.net.Calls;
import com.ac.cloud.util.UiUtils;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.json.JSONArray;
import org.json.JSONObject;

public class InstanceDetailSheet extends BottomSheetDialogFragment {

    private JSONObject instance = new JSONObject();
    private Runnable onChanged;
    private SheetInstanceDetailBinding b;
    private String iid;
    private String apiKey = "";
    private String aesKey = "";
    private String secretKey = "";

    /** Fragment 重建时必须存在无参构造。 */
    public InstanceDetailSheet() {
    }

    public InstanceDetailSheet(JSONObject instance, Runnable onChanged) {
        this.instance = instance == null ? new JSONObject() : instance;
        this.onChanged = onChanged;
        Bundle args = new Bundle();
        args.putString("instance_json", this.instance.toString());
        setArguments(args);
    }

    private void restoreInstance() {
        Bundle args = getArguments();
        if (args != null && args.getString("instance_json") != null) {
            instance = Json.parse(args.getString("instance_json"));
        }
        if (instance == null) instance = new JSONObject();
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        BottomSheetDialog dialog = new BottomSheetDialog(requireContext(), R.style.Theme_AC_BottomSheet);
        return dialog;
    }

    @Override
    public void onStart() {
        super.onStart();
        UiUtils.applyGlassBlur(getDialog());
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        b = SheetInstanceDetailBinding.inflate(inflater, container, false);
        return b.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        UiUtils.applyBottomInset(view);
        restoreInstance();
        iid = instance.optString("instance_id");
        JSONObject config = instance.optJSONObject("config");
        if (config == null) config = new JSONObject();

        b.tvName.setText(instance.optString("name", "应用"));
        b.tvId.setText(iid);
        boolean running = "running".equals(instance.optString("status"));
        b.tvStatus.setText(running ? "运行中" : "已停止");
        b.tvStatus.setBackgroundResource(running ? R.drawable.bg_chip_success : R.drawable.bg_chip_warn);
        b.tvStatus.setTextColor(requireContext().getColor(running
                ? R.color.chip_success_fg : R.color.chip_warn_fg));
        b.btnToggle.setText(running ? "停止运行" : "启动运行");

        aesKey = config.optString("aes_key", "");
        secretKey = config.optString("secret_key", "");
        b.tvAesKey.setText(UiUtils.mask(aesKey, 10));
        b.tvSecret.setText(UiUtils.mask(secretKey, 4));
        b.tvApiKey.setText("加载中…");

        b.btnCopyApi.setOnClickListener(v -> UiUtils.copy("API 对接码", apiKey));
        b.btnCopyAes.setOnClickListener(v -> UiUtils.copy("AES 密钥", aesKey));
        b.btnCopySecret.setOnClickListener(v -> UiUtils.copy("签名密钥", secretKey));

        String announcement = config.optString("announcement_zh", "");
        if (announcement.isEmpty()) announcement = config.optString("announcement", "");
        b.etAnnouncement.setText(announcement);

        b.btnSaveAnnouncement.setOnClickListener(v -> saveAnnouncement());
        b.btnToggle.setOnClickListener(v -> toggle());
        b.btnRegen.setOnClickListener(v -> confirmRegenerate());
        b.btnDelete.setOnClickListener(v -> confirmDelete());

        loadKeys();
        loadVersions();
    }

    private void loadKeys() {
        Calls.get("/api/instances/" + iid + "/keys", json -> {
            if (!isAdded() || json.optInt("code") != 1) return;
            apiKey = json.optString("api_key", "");
            aesKey = json.optString("aes_key", aesKey);
            secretKey = json.optString("secret_key", secretKey);
            b.tvApiKey.setText(UiUtils.mask(apiKey, 6));
            b.tvAesKey.setText(UiUtils.mask(aesKey, 10));
            b.tvSecret.setText(UiUtils.mask(secretKey, 4));
        });
    }

    private void loadVersions() {
        Calls.get("/api/update/files/" + iid, json -> {
            if (!isAdded()) return;
            b.containerVersions.removeAllViews();
            JSONArray files = Json.array(json, "files");
            if (files.length() == 0) {
                b.containerVersions.addView(simpleText("暂无云更新版本，前往网页端上传。"));
                return;
            }
            String current = json.optString("current_version", "");
            for (int i = 0; i < files.length(); i++) {
                JSONObject f = files.optJSONObject(i);
                if (f == null) continue;
                String version = f.optString("version", "");
                String filename = f.optString("filename", "");
                String url = f.optString("proxy_url", "");
                if (url.isEmpty()) url = f.optString("url", "");
                if (!url.isEmpty() && url.startsWith("/")) {
                    url = com.ac.cloud.service.ApiService.base() + url;
                }
                b.containerVersions.addView(versionRow(version, filename, url, current.equals(version)));
            }
        });
    }

    private View versionRow(String version, String filename, String url, boolean current) {
        LinearLayout row = new LinearLayout(requireContext());
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setBackgroundResource(R.drawable.bg_code);
        row.setPadding(UiUtils.dp(requireContext(), 12), UiUtils.dp(requireContext(), 10),
                UiUtils.dp(requireContext(), 12), UiUtils.dp(requireContext(), 10));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.bottomMargin = UiUtils.dp(requireContext(), 8);
        row.setLayoutParams(params);

        LinearLayout col = new LinearLayout(requireContext());
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams colParams = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        col.setLayoutParams(colParams);

        TextView title = new TextView(requireContext());
        title.setText("v" + version + (current ? " · 当前" : ""));
        title.setTextSize(12);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        title.setTextColor(requireContext().getColor(R.color.on_surface));
        col.addView(title);

        TextView sub = new TextView(requireContext());
        sub.setText(filename);
        sub.setTextSize(10);
        sub.setTextColor(requireContext().getColor(R.color.on_surface_variant));
        col.addView(sub);
        row.addView(col);

        TextView action = new TextView(requireContext());
        action.setText("下载");
        action.setTextSize(11);
        action.setTextColor(requireContext().getColor(R.color.primary));
        action.setPadding(UiUtils.dp(requireContext(), 8), 0, UiUtils.dp(requireContext(), 4), 0);
        action.setOnClickListener(v -> {
            if (url == null || url.isEmpty()) {
                UiUtils.toast("该版本没有下载地址");
                return;
            }
            com.ac.cloud.util.DownloadUtil.download(requireContext(), url, filename);
        });
        row.addView(action);
        return row;
    }

    private TextView simpleText(String text) {
        TextView tv = new TextView(requireContext());
        tv.setText(text);
        tv.setTextSize(12);
        tv.setTextColor(requireContext().getColor(R.color.on_surface_variant));
        tv.setPadding(0, UiUtils.dp(requireContext(), 6), 0, 0);
        return tv;
    }

    private void saveAnnouncement() {
        String text = b.etAnnouncement.getText() == null ? ""
                : b.etAnnouncement.getText().toString().trim();
        try {
            JSONObject body = new JSONObject();
            body.put("announcement", text);
            body.put("announcement_zh", text);
            Calls.post("/api/instances/" + iid + "/announcement", body.toString(), json -> {
                if (!isAdded()) return;
                if (json.optInt("code") == 1) {
                    UiUtils.toast("公告已保存");
                    if (onChanged != null) onChanged.run();
                } else {
                    UiUtils.toast(Json.message(json));
                }
            });
        } catch (Exception ignored) {
        }
    }

    private void toggle() {
        Calls.post("/api/instances/" + iid + "/toggle", "{}", json -> {
            if (!isAdded()) return;
            if (json.optInt("code") == 1) {
                if (onChanged != null) onChanged.run();
                dismiss();
            } else {
                UiUtils.toast(Json.message(json));
            }
        });
    }

    private void confirmRegenerate() {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("重置密钥")
                .setMessage("重置后旧密钥立即失效，已接入的客户端需要更新配置。确定继续？")
                .setNegativeButton("取消", null)
                .setPositiveButton("重置", (d, w) -> Calls.post(
                        "/api/instances/" + iid + "/regenerate_keys", "{}", json -> {
                            if (!isAdded()) return;
                            if (json.optInt("code") != 1) {
                                UiUtils.toast(Json.message(json));
                                return;
                            }
                            apiKey = json.optString("api_key", apiKey);
                            aesKey = json.optString("aes_key", "");
                            secretKey = json.optString("secret_key", "");
                            b.tvApiKey.setText(UiUtils.mask(apiKey, 6));
                            b.tvAesKey.setText(UiUtils.mask(aesKey, 10));
                            b.tvSecret.setText(UiUtils.mask(secretKey, 4));
                            UiUtils.toast("密钥已重置");
                            if (onChanged != null) onChanged.run();
                        }))
                .show();
    }

    private void confirmDelete() {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("删除应用")
                .setMessage("将删除实例 " + iid + "，保留密钥 30 天。此操作不可撤销。")
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", (d, w) -> {
                    try {
                        JSONObject body = new JSONObject();
                        body.put("keep_keys", true);
                        Calls.delete("/api/instances/" + iid, body.toString(), json -> {
                            if (!isAdded()) return;
                            if (json.optInt("code") == 1) {
                                UiUtils.toast("应用已删除");
                                if (onChanged != null) onChanged.run();
                                dismiss();
                            } else {
                                UiUtils.toast(Json.message(json));
                            }
                        });
                    } catch (Exception ignored) {
                    }
                })
                .show();
    }
}
