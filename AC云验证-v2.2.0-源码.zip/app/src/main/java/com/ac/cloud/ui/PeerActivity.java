package com.ac.cloud.ui;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ac.cloud.R;
import com.ac.cloud.core.Json;
import com.ac.cloud.databinding.ActivityPeerBinding;
import com.ac.cloud.net.Calls;
import com.ac.cloud.ui.adapters.PeerAdapter;
import com.ac.cloud.util.UiUtils;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.json.JSONArray;
import org.json.JSONObject;

public class PeerActivity extends AppCompatActivity {

    private ActivityPeerBinding b;
    private PeerAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiUtils.edgeToEdge(this);
        b = ActivityPeerBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        UiUtils.applyInsets(b.getRoot());

        b.header.tvTitle.setText("同行识别");
        b.header.tvSubtitle.setText("UID 记录与同行检测");
        b.header.btnBack.setOnClickListener(v -> finish());
        b.header.btnAction.setVisibility(View.VISIBLE);
        b.header.ivAction.setImageResource(R.drawable.ic_add);
        b.header.btnAction.setOnClickListener(v -> showAddDialog());

        adapter = new PeerAdapter(this::confirmDelete);
        b.recycler.setLayoutManager(new LinearLayoutManager(this));
        b.recycler.setAdapter(adapter);
        b.swipe.setOnRefreshListener(this::loadPeers);

        loadPeers();
    }

    private void loadPeers() {
        Calls.get("/api/peer/list", json -> {
            b.swipe.setRefreshing(false);
            if (json.optInt("code") != 1) {
                UiUtils.toast(Json.message(json));
                return;
            }
            JSONArray peers = Json.array(json, "peers");
            adapter.submit(peers);
            boolean empty = peers.length() == 0;
            b.emptyView.setVisibility(empty ? View.VISIBLE : View.GONE);
            b.recycler.setVisibility(empty ? View.GONE : View.VISIBLE);
        });
    }

    private void showAddDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = UiUtils.dp(this, 20);
        box.setPadding(pad, UiUtils.dp(this, 4), pad, 0);

        EditText input = new EditText(this);
        input.setHint("请输入要识别的 UID");
        input.setHintTextColor(getColor(R.color.on_surface_variant));
        input.setTextColor(getColor(R.color.on_surface));
        input.setTextSize(14);
        input.setBackgroundResource(R.drawable.bg_input);
        int padH = UiUtils.dp(this, 14);
        int padV = UiUtils.dp(this, 12);
        input.setPadding(padH, padV, padH, padV);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setSingleLine(true);
        box.addView(input, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        AlertDialog dialog = new MaterialAlertDialogBuilder(this)
                .setTitle("添加 UID")
                .setMessage("添加后该 UID 会加入同行识别列表。")
                .setView(box)
                .setNegativeButton("取消", null)
                .setPositiveButton("添加", null)
                .create();
        dialog.setOnShowListener(d -> {
            Button add = dialog.getButton(DialogInterface.BUTTON_POSITIVE);
            add.setOnClickListener(v -> {
                String uid = input.getText() == null ? "" : input.getText().toString().trim();
                if (uid.isEmpty()) {
                    UiUtils.toast("请输入 UID");
                    return;
                }
                add.setEnabled(false);
                JSONObject body = new JSONObject();
                try {
                    body.put("uid", uid);
                } catch (Exception ignored) {
                }
                Calls.post("/api/peer/add", body.toString(), json -> {
                    add.setEnabled(true);
                    if (json.optInt("code") != 1) {
                        UiUtils.toast(Json.message(json));
                        return;
                    }
                    UiUtils.toast("已添加");
                    dialog.dismiss();
                    loadPeers();
                });
            });
        });
        dialog.show();
    }

    private void confirmDelete(JSONObject peer) {
        String uid = peer.optString("uid", "");
        new MaterialAlertDialogBuilder(this)
                .setTitle("删除 UID")
                .setMessage("确定删除 " + uid + " ？删除后该记录不再参与同行识别。")
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", (d, w) -> {
                    JSONObject body = new JSONObject();
                    try {
                        body.put("uid", uid);
                    } catch (Exception ignored) {
                    }
                    Calls.post("/api/peer/delete", body.toString(), json -> {
                        if (json.optInt("code") != 1) {
                            UiUtils.toast(Json.message(json));
                            return;
                        }
                        UiUtils.toast("已删除");
                        loadPeers();
                    });
                })
                .show();
    }
}
