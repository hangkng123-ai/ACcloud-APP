package com.ac.cloud.ui.adapters;

import android.text.format.Formatter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ac.cloud.R;

import java.io.File;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** 内置文件管理器列表适配器（自写，不依赖系统文件选择器）。 */
public class FileAdapter extends RecyclerView.Adapter<FileAdapter.Holder> {

    public interface Listener {
        void onFile(File file);
    }

    private final List<File> items;
    private final Listener listener;
    private final boolean multi;
    private final Set<String> selected = new HashSet<>();

    public FileAdapter(List<File> items, boolean multi, Listener listener) {
        this.items = items;
        this.multi = multi;
        this.listener = listener;
    }

    public Set<String> selected() {
        return selected;
    }

    public int selectedCount() {
        return selected.size();
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_file_row, parent, false);
        return new Holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        File file = items.get(position);
        holder.title.setText(file.getName());
        if (file.isDirectory()) {
            holder.icon.setImageResource(R.drawable.ic_folder);
            holder.icon.setColorFilter(holder.icon.getContext().getColor(R.color.warning));
            holder.desc.setText("文件夹");
            holder.check.setVisibility(View.GONE);
        } else {
            holder.icon.setImageResource(R.drawable.ic_file);
            holder.icon.setColorFilter(holder.icon.getContext().getColor(R.color.primary));
            holder.desc.setText(Formatter.formatShortFileSize(holder.itemView.getContext(),
                    file.length()) + " · " + ext(file.getName()));
            holder.check.setVisibility(multi && selected.contains(file.getAbsolutePath())
                    ? View.VISIBLE : View.GONE);
        }
        holder.itemView.setOnClickListener(v -> listener.onFile(file));
    }

    private static String ext(String name) {
        int dot = name.lastIndexOf('.');
        if (dot < 0 || dot == name.length() - 1) return "文件";
        return name.substring(dot + 1).toUpperCase(Locale.ROOT);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class Holder extends RecyclerView.ViewHolder {
        final ImageView icon;
        final ImageView check;
        final TextView title;
        final TextView desc;

        Holder(View view) {
            super(view);
            icon = view.findViewById(R.id.ivFileIcon);
            check = view.findViewById(R.id.ivFileCheck);
            title = view.findViewById(R.id.tvFileTitle);
            desc = view.findViewById(R.id.tvFileDesc);
        }
    }
}
