package com.ac.cloud.ui.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ac.cloud.R;
import com.ac.cloud.databinding.ItemTicketBinding;

import org.json.JSONArray;
import org.json.JSONObject;

public class TicketAdapter extends RecyclerView.Adapter<TicketAdapter.VH> {

    public interface OnTicketClick {
        void onTicketClick(JSONObject ticket);
    }

    private JSONArray items = new JSONArray();
    private final OnTicketClick listener;

    public TicketAdapter(OnTicketClick listener) {
        this.listener = listener;
    }

    public void submit(JSONArray array) {
        items = array == null ? new JSONArray() : array;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(ItemTicketBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        JSONObject item = items.optJSONObject(position);
        if (item == null) return;
        Context ctx = holder.b.getRoot().getContext();

        String status = item.optString("status", "pending");
        holder.b.tvTitle.setText(item.optString("title", "未命名工单"));
        holder.b.tvStatus.setText(statusLabel(status));
        holder.b.tvStatus.setBackgroundResource(statusBg(status));
        holder.b.tvStatus.setTextColor(ctx.getColor(statusFg(status)));

        String create = item.optString("create_time", "");
        String update = item.optString("update_time", "");
        if (!update.isEmpty()) {
            holder.b.tvTime.setText("更新于 " + update);
        } else {
            holder.b.tvTime.setText("提交于 " + (create.isEmpty() ? "--" : create));
        }

        String desc = item.optString("description", "");
        holder.b.tvDescription.setText(desc.isEmpty() ? "（无描述）" : desc);

        String note = item.optString("admin_note", "");
        if (note.isEmpty()) {
            holder.b.tvAdminNote.setVisibility(android.view.View.GONE);
        } else {
            holder.b.tvAdminNote.setVisibility(android.view.View.VISIBLE);
            holder.b.tvAdminNote.setText("管理员回复：" + note);
        }

        String file = item.optString("file_name", "");
        String replyFile = item.optString("reply_file_name", "");
        if (file.isEmpty() && replyFile.isEmpty()) {
            holder.b.fileRow.setVisibility(android.view.View.GONE);
        } else {
            holder.b.fileRow.setVisibility(android.view.View.VISIBLE);
            StringBuilder sb = new StringBuilder();
            if (!file.isEmpty()) sb.append("我的附件：").append(file);
            if (!replyFile.isEmpty()) {
                if (sb.length() > 0) sb.append("  ·  ");
                sb.append("回复附件：").append(replyFile);
            }
            holder.b.tvFile.setText(sb.toString());
        }

        holder.b.getRoot().setOnClickListener(v -> {
            if (listener != null) listener.onTicketClick(item);
        });
    }

    @Override
    public int getItemCount() {
        return items.length();
    }

    public static String statusLabel(String status) {
        if ("processing".equals(status)) return "处理中";
        if ("completed".equals(status)) return "已完成";
        if ("rejected".equals(status)) return "已拒绝";
        return "待处理";
    }

    public static int statusBg(String status) {
        if ("processing".equals(status)) return R.drawable.bg_chip_info;
        if ("completed".equals(status)) return R.drawable.bg_chip_success;
        if ("rejected".equals(status)) return R.drawable.bg_chip_danger;
        return R.drawable.bg_chip_warn;
    }

    public static int statusFg(String status) {
        if ("processing".equals(status)) return R.color.chip_info_fg;
        if ("completed".equals(status)) return R.color.chip_success_fg;
        if ("rejected".equals(status)) return R.color.chip_danger_fg;
        return R.color.chip_warn_fg;
    }

    static class VH extends RecyclerView.ViewHolder {
        final ItemTicketBinding b;

        VH(ItemTicketBinding binding) {
            super(binding.getRoot());
            b = binding;
        }
    }
}
