package com.ac.cloud.ui.adapters;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ac.cloud.R;
import com.ac.cloud.databinding.ItemOnlineUserBinding;

import org.json.JSONArray;
import org.json.JSONObject;

public class OnlineUserAdapter extends RecyclerView.Adapter<OnlineUserAdapter.VH> {

    private JSONArray items = new JSONArray();

    public void submit(JSONArray array) {
        items = array == null ? new JSONArray() : array;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(ItemOnlineUserBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        JSONObject item = items.optJSONObject(position);
        if (item == null) return;
        String device = item.optString("device_id", "");
        holder.b.tvDevice.setText(device.isEmpty() ? "未绑定设备" : device);
        holder.b.tvCard.setText("卡密 " + item.optString("card_password", "--"));

        boolean online = "online".equals(item.optString("status"));
        holder.b.tvStatus.setText(online ? "在线" : "离线");
        holder.b.tvStatus.setBackgroundResource(online
                ? R.drawable.bg_chip_success : R.drawable.bg_chip_warn);
        holder.b.tvStatus.setTextColor(holder.b.getRoot().getContext().getColor(online
                ? R.color.chip_success_fg : R.color.chip_warn_fg));

        holder.b.tvMeta.setText(online
                ? "在线时长 " + item.optString("duration_str", "--")
                : "离线时长 " + item.optString("duration_str", "--"));
    }

    @Override
    public int getItemCount() {
        return items.length();
    }

    static class VH extends RecyclerView.ViewHolder {
        final ItemOnlineUserBinding b;

        VH(ItemOnlineUserBinding binding) {
            super(binding.getRoot());
            b = binding;
        }
    }
}
