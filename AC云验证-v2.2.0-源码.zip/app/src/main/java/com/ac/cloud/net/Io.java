package com.ac.cloud.net;

import android.os.Handler;
import android.os.Looper;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class Io {

    private static final ExecutorService POOL = Executors.newFixedThreadPool(4);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private Io() {
    }

    public static void run(Runnable task) {
        POOL.execute(task);
    }

    public static void main(Runnable task) {
        MAIN.post(task);
    }
}
