package com.ac.cloud.util;

import android.app.Activity;
import android.content.Context;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.ac.cloud.R;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/**
 * 应用内下载器：流式下载 + 实时进度，统一保存到内部存储 AC云验证-cloud/。
 */
public final class DownloadUtil {

    public static final String FOLDER = "AC云验证-cloud";

    private DownloadUtil() {
    }

    public static File targetDir() {
        File dir = new File(Environment.getExternalStorageDirectory(), FOLDER);
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    public static void download(Context context, String url, String fileName) {
        if (context == null || url == null || url.isEmpty()) return;
        Context app = context.getApplicationContext();
        String name = fileName == null || fileName.trim().isEmpty() ? "download.bin" : fileName.trim();

        ProgressBar bar = new ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setProgress(0);
        LinearLayout box = new LinearLayout(context);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = UiUtils.dp(context, 20);
        box.setPadding(pad, pad / 2, pad, 0);
        TextView label = new TextView(context);
        label.setText("正在下载 " + name);
        label.setTextColor(context.getResources().getColor(R.color.on_surface_variant));
        label.setTextSize(12);
        box.addView(label);
        box.addView(bar);

        androidx.appcompat.app.AlertDialog dialog = new MaterialAlertDialogBuilder(context)
                .setTitle("下载文件")
                .setView(box)
                .setNegativeButton("取消", null)
                .create();
        dialog.show();

        Handler main = new Handler(Looper.getMainLooper());
        final boolean[] cancelled = {false};
        dialog.setOnDismissListener(d -> cancelled[0] = true);

        new Thread(() -> {
            File dir = targetDir();
            File out = new File(dir, name);
            int index = 1;
            while (out.exists()) {
                String base = name;
                String ext = "";
                int dot = name.lastIndexOf('.');
                if (dot > 0) {
                    base = name.substring(0, dot);
                    ext = name.substring(dot);
                }
                out = new File(dir, base + "(" + (index++) + ")" + ext);
            }
            try {
                OkHttpClient client = new OkHttpClient.Builder()
                        .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
                        .readTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
                        .build();
                Request.Builder request = new Request.Builder().url(url)
                        .header("User-Agent", "ACCloudApp/2.0");
                String cookie = com.ac.cloud.core.Prefs.getString("cookie", null);
                if (cookie != null) request.header("Cookie", cookie);
                Response response = client.newCall(request.build()).execute();
                if (!response.isSuccessful() || response.body() == null) {
                    throw new Exception("HTTP " + response.code());
                }
                long total = response.body().contentLength();
                try (InputStream in = response.body().byteStream();
                     FileOutputStream os = new FileOutputStream(out)) {
                    byte[] buffer = new byte[8192];
                    long done = 0;
                    int read;
                    long last = 0;
                    while ((read = in.read(buffer)) != -1) {
                        if (cancelled[0]) throw new Exception("已取消");
                        os.write(buffer, 0, read);
                        done += read;
                        if (total > 0 && System.currentTimeMillis() - last > 120) {
                            last = System.currentTimeMillis();
                            int pct = (int) (done * 100 / total);
                            main.post(() -> {
                                bar.setProgress(pct);
                                label.setText("正在下载 " + name + " · " + pct + "%");
                            });
                        }
                    }
                }
                final String path = out.getAbsolutePath();
                main.post(() -> {
                    bar.setProgress(100);
                    if (dialog.isShowing()) dialog.dismiss();
                    UiUtils.toast("已保存到 " + path);
                });
            } catch (Exception e) {
                out.delete();
                main.post(() -> {
                    if (dialog.isShowing()) dialog.dismiss();
                    UiUtils.toast("下载失败：" + e.getMessage());
                });
            }
        }, "ac-download").start();
    }
}
