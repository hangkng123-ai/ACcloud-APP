package com.ac.cloud.core;

import org.json.JSONArray;
import org.json.JSONObject;

public final class Json {

    private Json() {
    }

    public static JSONObject parse(String raw) {
        try {
            return new JSONObject(raw == null ? "{}" : raw);
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    public static JSONArray array(JSONObject obj, String key) {
        JSONArray arr = obj.optJSONArray(key);
        return arr == null ? new JSONArray() : arr;
    }

    public static boolean ok(JSONObject obj) {
        return obj.optInt("code") == 1;
    }

    public static String message(JSONObject obj) {
        String msg = obj.optString("message", "");
        if (msg.isEmpty()) msg = "操作失败，请稍后重试";
        return msg;
    }

    public static String text(JSONObject obj, String key, String def) {
        String v = obj.optString(key, def);
        return v == null || v.isEmpty() ? def : v;
    }
}
