package com.ac.cloud;

import android.app.Application;
import android.content.Context;

import androidx.appcompat.app.AppCompatDelegate;

import com.ac.cloud.core.Prefs;
import com.ac.cloud.net.Api;

public class App extends Application {

    private static App instance;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        installCrashLogger();
        Prefs.init(this);
        int mode = Prefs.getInt("night_mode", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
        AppCompatDelegate.setDefaultNightMode(mode);
        Api.init(this);
    }

    /** 崩溃日志落盘，便于定位线上闪退。 */
    private void installCrashLogger() {
        final Thread.UncaughtExceptionHandler previous =
                Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                java.io.File dir = getExternalFilesDir("crash");
                if (dir != null) {
                    if (!dir.exists()) dir.mkdirs();
                    java.io.File out = new java.io.File(dir, "crash-last.txt");
                    java.io.PrintWriter writer = new java.io.PrintWriter(
                            new java.io.FileWriter(out, false));
                    writer.println("time: " + new java.util.Date());
                    throwable.printStackTrace(writer);
                    writer.flush();
                    writer.close();
                }
            } catch (Throwable ignored) {
            }
            if (previous != null) previous.uncaughtException(thread, throwable);
        });
    }

    public static App get() {
        return instance;
    }

    public static Context ctx() {
        return instance.getApplicationContext();
    }
}
