package com.ac.cloud.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.Fragment;

import com.ac.cloud.R;
import com.ac.cloud.core.Json;
import com.ac.cloud.core.NativeCore;
import com.ac.cloud.core.Prefs;
import com.ac.cloud.databinding.FragmentProfileBinding;
import com.ac.cloud.databinding.ItemMenuRowBinding;
import com.ac.cloud.net.Calls;
import com.ac.cloud.util.UiUtils;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.json.JSONObject;

public class ProfileFragment extends Fragment {

    private FragmentProfileBinding b;
    private JSONObject user = new JSONObject();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        b = FragmentProfileBinding.inflate(inflater, container, false);
        return b.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        UiUtils.bindMenu(view, this);
        buildRows();
        b.btnLogout.setOnClickListener(v -> confirmLogout());
        b.rowTheme.setOnClickListener(v -> toggleTheme());
        b.switchTheme.setOnCheckedChangeListener((button, checked) -> {
            int mode = checked ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO;
            Prefs.putInt("night_mode", mode);
            AppCompatDelegate.setDefaultNightMode(mode);
        });
        b.switchTheme.setChecked(isNight());
        b.tvVersion.setText("AC 云验证 v2.2.0 · " + NativeCore.version());
        bindUser(Json.parse(Prefs.getString("user_json", "{}")));
        refreshUser();
    }

    private boolean isNight() {
        return (getResources().getConfiguration().uiMode & 0x30) == 0x20;
    }

    private void toggleTheme() {
        b.switchTheme.setChecked(!b.switchTheme.isChecked());
    }

    private void bindUser(JSONObject json) {
        user = json;
        String name = json.optString("display_name", "AC");
        b.tvName.setText(name);
        b.tvUserId.setText(json.optString("user_id", ""));
        b.tvAvatar.setText(UiUtils.initial(name));
        b.tvEmail.setText("邮箱 · " + json.optString("email", "未绑定"));
        b.tvRegisterTime.setText("注册于 " + json.optString("register_time", "--"));
        boolean google = json.optBoolean("google_bound");
        b.tvGoogle.setVisibility(google ? View.VISIBLE : View.GONE);
        if (google) {
            b.tvGoogle.setText("Google 已绑定");
        }
    }

    private void refreshUser() {
        Calls.get("/api/user/info", json -> {
            if (!isAdded() || json.optInt("code") != 1) return;
            Prefs.putString("user_json", json.toString());
            Prefs.putString("api_key", json.optString("api_key", ""));
            bindUser(json);
        });
    }

    private void buildRows() {
        addRow(b.rowsAccount, R.drawable.ic_edit, "修改昵称", "更新你的显示名称", this::changeName);
        addRow(b.rowsAccount, R.drawable.ic_lock, "修改密码", "定期更换密码更安全", this::changePassword);
        addRow(b.rowsAccount, R.drawable.ic_key, "API 对接码", "查看、复制或重置", this::showApiKey);
        addRow(b.rowsAccount, R.drawable.ic_security, "Google 账号", "绑定后解锁无限邮箱",
                this::bindGoogle);

        addRow(b.rowsTools, R.drawable.ic_shield, "卡密验证测试", "C++ 原生 AES / MD5 验证", () ->
                startActivity(new Intent(requireContext(), VerifyToolActivity.class)));
        addRow(b.rowsTools, R.drawable.ic_group, "在线用户", "实时心跳与设备列表", () ->
                startActivity(new Intent(requireContext(), OnlineUsersActivity.class)));
        addRow(b.rowsTools, R.drawable.ic_dns, "服务器部署", "Python 项目与运行日志", () ->
                startActivity(new Intent(requireContext(), DeployActivity.class)));
        addRow(b.rowsTools, R.drawable.ic_rocket, "网站部署", "静态站点全原生管理", () -> {
            Intent intent = new Intent(requireContext(), DeployActivity.class);
            intent.putExtra("tab", 1);
            startActivity(intent);
        });
        addRow(b.rowsTools, R.drawable.ic_rocket, "福利中心", "全站福利与限时奖励", () ->
                startActivity(new Intent(requireContext(), WelfareActivity.class)));
        addRow(b.rowsTools, R.drawable.ic_code, "API 文档", "签名、加密与完整接口", () ->
                startActivity(new Intent(requireContext(), ApiDocsActivity.class)));
        addRow(b.rowsTools, R.drawable.ic_terminal, "Shizuku 系统增强", "系统级权限 · 网络加速与稳定连接", () ->
                startActivity(new Intent(requireContext(), ShizukuActivity.class)));
        addRow(b.rowsTools, R.drawable.ic_folder, "内置文件管理", "浏览本地文件并直接上传", () ->
                startActivity(new Intent(requireContext(), FileManagerActivity.class)));

        addRow(b.rowsMore, R.drawable.ic_support, "帮助工单", "提交问题与查看回复", () ->
                startActivity(new Intent(requireContext(), HelpActivity.class)));
        addRow(b.rowsMore, R.drawable.ic_mail, "无限邮箱", "需绑定 Google 账号", () ->
                startActivity(new Intent(requireContext(), UnlimitedEmailActivity.class)));
        addRow(b.rowsMore, R.drawable.ic_visibility, "同行识别", "检测同行与异常 UID", () ->
                startActivity(new Intent(requireContext(), PeerActivity.class)));
        addRow(b.rowsMore, R.drawable.ic_description, "对接下载", "SDK 与接入资源", () ->
                startActivity(new Intent(requireContext(), DocumentsActivity.class)));
    }

    private void bindGoogle() {
        if (user.optBoolean("google_bound")) {
            UiUtils.toast("Google 已绑定：" + user.optString("google_email", ""));
            return;
        }
        // 先用当前网页会话换取一次性绑定令牌，确保绑定到现有账号而不是新建账号
        Calls.get("/api/app/google_url", json -> {
            if (!isAdded()) return;
            if (json.optInt("code") != 1) {
                UiUtils.toast(Json.message(json));
                return;
            }
            String path = json.optString("url", "");
            try {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        android.net.Uri.parse(com.ac.cloud.service.ApiService.base() + path)));
            } catch (Exception e) {
                UiUtils.toast("未找到可用浏览器");
            }
        });
    }

    private void addRow(LinearLayout container, int icon, String title, String subtitle, Runnable action) {
        ItemMenuRowBinding row = ItemMenuRowBinding.inflate(getLayoutInflater(), container, false);
        row.rowIcon.setImageResource(icon);
        row.rowTitle.setText(title);
        row.rowSubtitle.setText(subtitle);
        row.getRoot().setOnClickListener(v -> action.run());
        container.addView(row.getRoot());
        View divider = new View(requireContext());
        divider.setBackgroundResource(R.drawable.divider);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, UiUtils.dp(requireContext(), 1));
        params.leftMargin = UiUtils.dp(requireContext(), 62);
        divider.setLayoutParams(params);
        container.addView(divider);
    }

    private void changeName() {
        EditText input = input("新的昵称", user.optString("display_name", ""));
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("修改昵称")
                .setView(wrap(input))
                .setNegativeButton("取消", null)
                .setPositiveButton("保存", (d, w) -> {
                    try {
                        JSONObject body = new JSONObject();
                        body.put("display_name", input.getText().toString().trim());
                        Calls.post("/api/user/update_name", body.toString(), json -> {
                            if (!isAdded()) return;
                            if (json.optInt("code") == 1) {
                                UiUtils.toast("昵称已更新");
                                refreshUser();
                            } else {
                                UiUtils.toast(Json.message(json));
                            }
                        });
                    } catch (Exception ignored) {
                    }
                }).show();
    }

    private void changePassword() {
        LinearLayout box = new LinearLayout(requireContext());
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = UiUtils.dp(requireContext(), 20);
        box.setPadding(pad, UiUtils.dp(requireContext(), 4), pad, 0);
        EditText oldPw = input("当前密码", "");
        oldPw.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        EditText newPw = input("新密码（至少 6 位）", "");
        newPw.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        box.addView(oldPw);
        box.addView(newPw);

        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("修改密码")
                .setView(box)
                .setNegativeButton("取消", null)
                .setPositiveButton("保存", (d, w) -> {
                    try {
                        JSONObject body = new JSONObject();
                        body.put("old_password", oldPw.getText().toString());
                        body.put("new_password", newPw.getText().toString());
                        Calls.post("/api/user/change_password", body.toString(), json -> {
                            if (!isAdded()) return;
                            if (json.optInt("code") == 1) {
                                UiUtils.toast("密码已修改");
                            } else {
                                UiUtils.toast(Json.message(json));
                            }
                        });
                    } catch (Exception ignored) {
                    }
                }).show();
    }

    private void showApiKey() {
        String key = user.optString("api_key", Prefs.getString("api_key", ""));
        String masked = UiUtils.mask(key, 6);
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("API 对接码")
                .setMessage(masked + "\n\n用于客户端签名与在线状态接口，请勿泄露。")
                .setNeutralButton("重置", (d, w) -> confirmRegenerateKey())
                .setNegativeButton("关闭", null)
                .setPositiveButton("复制", (d, w) -> UiUtils.copy("API 对接码", key))
                .show();
    }

    private void confirmRegenerateKey() {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("重置 API 对接码")
                .setMessage("重置后旧对接码立即失效，所有客户端需更新。确定继续？")
                .setNegativeButton("取消", null)
                .setPositiveButton("重置", (d, w) ->
                        Calls.post("/api/user/regenerate_api_key", "{}", json -> {
                            if (!isAdded()) return;
                            if (json.optInt("code") == 1) {
                                Prefs.putString("api_key", json.optString("api_key", ""));
                                UiUtils.toast("对接码已重置");
                                refreshUser();
                            } else {
                                UiUtils.toast(Json.message(json));
                            }
                        })).show();
    }

    private void confirmLogout() {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("退出登录")
                .setMessage("退出后需要重新输入账号密码。")
                .setNegativeButton("取消", null)
                .setPositiveButton("退出", (d, w) -> {
                    Calls.get("/logout", json -> {
                    });
                    Prefs.clearSession();
                    Intent intent = new Intent(requireContext(), LoginActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    requireActivity().finish();
                }).show();
    }

    private EditText input(String hint, String value) {
        EditText et = new EditText(requireContext());
        et.setHint(hint);
        et.setText(value);
        et.setTextSize(14);
        et.setPadding(UiUtils.dp(requireContext(), 4), UiUtils.dp(requireContext(), 12),
                UiUtils.dp(requireContext(), 4), UiUtils.dp(requireContext(), 12));
        return et;
    }

    private View wrap(EditText input) {
        LinearLayout box = new LinearLayout(requireContext());
        int pad = UiUtils.dp(requireContext(), 20);
        box.setPadding(pad, UiUtils.dp(requireContext(), 4), pad, 0);
        box.addView(input);
        return box;
    }
}
