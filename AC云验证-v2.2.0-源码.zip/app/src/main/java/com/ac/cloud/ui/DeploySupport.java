package com.ac.cloud.ui;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import com.ac.cloud.R;
import com.ac.cloud.core.Json;
import com.ac.cloud.util.UiUtils;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;

/**
 * 部署页面共用的轻量 UI / 数据辅助方法。
 */
final class DeploySupport {

    private DeploySupport() {
    }

    static String enc(String value) {
        try {
            return URLEncoder.encode(value == null ? "" : value, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    static String cleanPath(String value) {
        if (value == null) return "";
        String path = value.trim().replace('\\', '/');
        while (path.startsWith("/")) path = path.substring(1);
        while (path.endsWith("/")) path = path.substring(0, path.length() - 1);
        return path;
    }

    static String fileName(String path) {
        if (path == null) return "";
        String value = path.trim();
        int index = value.lastIndexOf('/');
        return index >= 0 ? value.substring(index + 1) : value;
    }

    static EditText input(Context ctx, String hint, String value, boolean multiline) {
        EditText et = new EditText(ctx);
        et.setHint(hint);
        et.setText(value == null ? "" : value);
        et.setTextSize(14);
        et.setTextColor(ctx.getColor(R.color.on_surface));
        et.setHintTextColor(ctx.getColor(R.color.on_surface_variant));
        et.setBackgroundResource(R.drawable.bg_input);
        int pad = UiUtils.dp(ctx, 12);
        et.setPadding(pad, pad, pad, pad);
        if (multiline) {
            et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            et.setGravity(Gravity.TOP | Gravity.START);
            et.setMinLines(6);
            et.setHorizontallyScrolling(false);
        }
        return et;
    }

    static LinearLayout form(Context ctx) {
        LinearLayout box = new LinearLayout(ctx);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = UiUtils.dp(ctx, 20);
        box.setPadding(pad, UiUtils.dp(ctx, 4), pad, 0);
        return box;
    }

    static void addField(Context ctx, LinearLayout box, String label, EditText input) {
        TextView tv = new TextView(ctx);
        tv.setText(label);
        tv.setTextSize(12);
        tv.setTextColor(ctx.getColor(R.color.on_surface_variant));
        tv.setPadding(UiUtils.dp(ctx, 4), UiUtils.dp(ctx, 10), UiUtils.dp(ctx, 4), UiUtils.dp(ctx, 4));
        box.addView(tv);
        box.addView(input, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    }

    static AlertDialog progress(Context ctx, String message) {
        AlertDialog dialog = new MaterialAlertDialogBuilder(ctx)
                .setTitle("请稍候")
                .setMessage(message)
                .setCancelable(false)
                .create();
        dialog.show();
        return dialog;
    }

    static String logs(JSONObject json) {
        if (json == null) return "";
        if (!Json.ok(json)) return Json.message(json);
        JSONArray arr = json.optJSONArray("logs");
        if (arr == null) arr = json.optJSONArray("lines");
        if (arr != null) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < arr.length(); i++) {
                Object item = arr.opt(i);
                if (item instanceof JSONObject) {
                    JSONObject line = (JSONObject) item;
                    sb.append(line.optString("line", line.optString("message", line.toString())));
                } else {
                    sb.append(item == null ? "" : item.toString());
                }
                sb.append('\n');
            }
            return sb.toString().trim();
        }
        String text = json.optString("logs", "");
        if (text.isEmpty()) text = json.optString("log", "");
        if (text.isEmpty()) text = json.optString("content", "");
        if (text.isEmpty()) text = json.optString("message", "");
        return text.isEmpty() ? json.toString() : text;
    }

    static String domainUrl(String domain, boolean https) {
        if (domain == null || domain.trim().isEmpty()) return "";
        return (https ? "https://" : "http://") + domain.trim() + "/";
    }

    static void open(Context ctx, String url) {
        if (url == null || url.isEmpty()) {
            UiUtils.toast("暂无可用域名");
            return;
        }
        try {
            ctx.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            UiUtils.toast("无法打开链接");
        }
    }
}
