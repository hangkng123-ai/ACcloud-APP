package com.ac.cloud.ui.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ac.cloud.R;
import com.ac.cloud.databinding.ItemEmailBinding;

import org.json.JSONArray;
import org.json.JSONObject;

public class EmailAdapter extends RecyclerView.Adapter<EmailAdapter.VH> {

    public interface Listener {
        void onCopy(JSONObject item);

        void onEditForward(JSONObject item);

        void onToggle(JSONObject item);

        void onDelete(JSONObject item);
    }

    private JSONArray items = new JSONArray();
    private final Listener listener;

    public EmailAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submit(JSONArray array) {
        items = array == null ? new JSONArray() : array;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(ItemEmailBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        JSONObject item = items.optJSONObject(position);
        if (item == null) return;
        Context ctx = holder.itemView.getContext();
        ItemEmailBinding b = holder.b;

        b.tvEmail.setText(item.optString("email", "--"));
        String forward = item.optString("forward_to", "");
        b.tvForward.setText(forward.isEmpty() ? "未设置转发邮箱" : "转发到 " + forward);
        b.tvDomain.setText(item.optString("domain", "域名"));
        b.tvReceived.setText("累计收件 " + item.optInt("received_count", 0) + " 封");

        boolean enabled = item.optBoolean("enabled", true);
        b.tvStatus.setText(enabled ? "启用中" : "已停用");
        b.tvStatus.setBackgroundResource(enabled
                ? R.drawable.bg_chip_success : R.drawable.bg_chip_warn);
        b.tvStatus.setTextColor(ctx.getColor(enabled
                ? R.color.chip_success_fg : R.color.chip_warn_fg));
        b.btnToggle.setText(enabled ? "停用" : "启用");
        b.btnToggle.setIconResource(enabled ? R.drawable.ic_pause : R.drawable.ic_play);

        b.tvRecent.setText(recentSummary(item));

        b.btnCopy.setOnClickListener(v -> listener.onCopy(item));
        b.btnForward.setOnClickListener(v -> listener.onEditForward(item));
        b.btnToggle.setOnClickListener(v -> listener.onToggle(item));
        b.btnDelete.setOnClickListener(v -> listener.onDelete(item));
    }

    private static String recentSummary(JSONObject item) {
        StringBuilder sb = new StringBuilder();
        int count = item.optInt("received_count", 0);
        String lastTime = item.optString("last_received_time", "");
        sb.append("累计收件 ").append(count).append(" 封");
        if (!lastTime.isEmpty()) sb.append(" · 最近 ").append(lastTime);

        String from = item.optString("last_from", "");
        String subject = item.optString("last_subject", "");
        JSONArray recent = item.optJSONArray("recent_mails");
        if ((from.isEmpty() || subject.isEmpty()) && recent != null && recent.length() > 0) {
            JSONObject last = recent.optJSONObject(0);
            if (last != null) {
                if (from.isEmpty()) from = last.optString("from", "");
                if (subject.isEmpty()) subject = last.optString("subject", "");
            }
        }
        if (!from.isEmpty()) sb.append("\n来自 · ").append(from);
        if (!subject.isEmpty()) sb.append("\n主题 · ").append(subject);
        return sb.toString();
    }

    @Override
    public int getItemCount() {
        return items.length();
    }

    static class VH extends RecyclerView.ViewHolder {
        final ItemEmailBinding b;

        VH(ItemEmailBinding binding) {
            super(binding.getRoot());
            b = binding;
        }
    }
}
