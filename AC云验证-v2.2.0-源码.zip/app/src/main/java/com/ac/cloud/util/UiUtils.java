package com.ac.cloud.util;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import com.ac.cloud.App;
import com.google.android.material.snackbar.Snackbar;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class UiUtils {

    private UiUtils() {
    }

    public static int dp(Context ctx, float value) {
        return Math.round(value * ctx.getResources().getDisplayMetrics().density);
    }

    public static void toast(String message) {
        if (message == null || message.isEmpty()) return;
        Toast.makeText(App.ctx(), message, Toast.LENGTH_SHORT).show();
    }

    public static void snack(View view, String message) {
        Snackbar.make(view, message, Snackbar.LENGTH_SHORT).show();
    }

    public static void copy(String label, String text) {
        ClipboardManager cm = (ClipboardManager) App.ctx().getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm == null) return;
        cm.setPrimaryClip(ClipData.newPlainText(label, text));
        toast("已复制" + (label.isEmpty() ? "" : "：" + label));
    }

    public static String mask(String value, int keep) {
        if (value == null) return "";
        if (value.length() <= keep * 2) return value;
        return value.substring(0, keep) + "••••••" + value.substring(value.length() - keep);
    }

    public static String formatNumber(long number) {
        if (number < 1000) return String.valueOf(number);
        if (number < 1000000) return String.format(Locale.US, "%.1fK", number / 1000f);
        return String.format(Locale.US, "%.1fM", number / 1000000f);
    }

    public static String now() {
        return new SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(new Date());
    }

    public static String initial(String name) {
        if (name == null || name.trim().isEmpty()) return "A";
        return name.trim().substring(0, 1).toUpperCase(Locale.ROOT);
    }

    public static void hideKeyboard(View view) {
        InputMethodManager imm = (InputMethodManager) view.getContext()
                .getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public static void edgeToEdge(android.app.Activity activity) {
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(activity.getWindow(), false);
    }

    public static void applyInsets(View root) {
        final int startLeft = root.getPaddingLeft();
        final int startTop = root.getPaddingTop();
        final int startRight = root.getPaddingRight();
        final int startBottom = root.getPaddingBottom();
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            androidx.core.graphics.Insets bars = insets.getInsets(
                    androidx.core.view.WindowInsetsCompat.Type.systemBars());
            v.setPadding(startLeft, startTop + bars.top, startRight, startBottom + bars.bottom);
            return insets;
        });
    }

    public static void bindMenu(View root, androidx.fragment.app.Fragment fragment) {
        View menu = root.findViewById(com.ac.cloud.R.id.btnMenu);
        if (menu != null) {
            menu.setOnClickListener(v -> {
                if (fragment.getActivity() instanceof com.ac.cloud.ui.MainActivity) {
                    ((com.ac.cloud.ui.MainActivity) fragment.getActivity()).openDrawer();
                }
            });
        }
    }

    public static void applyBottomInset(View root) {
        final int startBottom = root.getPaddingBottom();
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            int bottom = insets.getInsets(
                    androidx.core.view.WindowInsetsCompat.Type.systemBars()).bottom;
            v.setPadding(v.getPaddingLeft(), v.getPaddingTop(), v.getPaddingRight(),
                    startBottom + bottom);
            return insets;
        });
    }

    /**
     * Real gaussian backdrop blur on Android 12+, graceful glass fallback below.
     */
    public static void applyGlassBlur(android.app.Dialog dialog) {
        if (dialog == null || dialog.getWindow() == null) return;
        try {
            androidx.core.view.WindowCompat.setDecorFitsSystemWindows(dialog.getWindow(), true);
        } catch (Throwable ignored) {
        }
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            // Decorative blur must be applied after the window has a DecorView,
            // otherwise PhoneWindow.setBackgroundBlurRadius throws NPE.
            applyBlurSafely(dialog);
        }
    }

    private static void applyBlurSafely(android.app.Dialog dialog) {
        if (dialog == null || dialog.getWindow() == null) return;
        try {
            android.view.Window window = dialog.getWindow();
            if (window.peekDecorView() == null) return;
            window.setBackgroundBlurRadius(56);
            window.setDimAmount(0.18f);
            window.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        } catch (Throwable ignored) {
        }
    }

    public static int color(String hex) {
        return Color.parseColor(hex);
    }
}
