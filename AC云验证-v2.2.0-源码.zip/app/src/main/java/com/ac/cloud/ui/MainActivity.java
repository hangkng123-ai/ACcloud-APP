package com.ac.cloud.ui;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.ac.cloud.R;
import com.ac.cloud.core.DataCache;
import com.ac.cloud.core.Json;
import com.ac.cloud.core.Prefs;
import com.ac.cloud.core.Servers;
import com.ac.cloud.databinding.ActivityMainBinding;
import com.ac.cloud.net.Api;
import com.ac.cloud.net.Io;
import com.ac.cloud.util.DocsBadge;
import com.ac.cloud.util.UiUtils;

import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding b;
    private final Fragment[] fragments = new Fragment[5];
    private int currentId = R.id.nav_dashboard;
    private boolean drawerOpen;
    private boolean switching;
    private boolean bootDone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiUtils.edgeToEdge(this);
        if (!Prefs.getBool("logged_in", false)) {
            exitToLogin();
            return;
        }
        b = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        UiUtils.applyInsets(b.getRoot());

        fragments[0] = restoreOrCreate(savedInstanceState, 0, DashboardFragment::new);
        fragments[1] = restoreOrCreate(savedInstanceState, 1, InstancesFragment::new);
        fragments[2] = restoreOrCreate(savedInstanceState, 2, CardsFragment::new);
        fragments[3] = restoreOrCreate(savedInstanceState, 3, CloudFragment::new);
        fragments[4] = restoreOrCreate(savedInstanceState, 4, ProfileFragment::new);

        setupDrawer();
        showTab(R.id.nav_dashboard, false);

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (drawerOpen) {
                    closeDrawer();
                } else if (currentId != R.id.nav_dashboard) {
                    showTab(R.id.nav_dashboard);
                } else {
                    finish();
                }
            }
        });

        validateSession();
        startBootRefresh();
    }

    private Fragment restoreOrCreate(Bundle state, int index,
                                     java.util.function.Supplier<Fragment> factory) {
        if (state != null) {
            Fragment existing = getSupportFragmentManager().findFragmentByTag("tab_" + index);
            if (existing != null) return existing;
        }
        return factory.get();
    }

    private void setupDrawer() {
        b.drawerScrim.setOnClickListener(v -> closeDrawer());
        b.rowDashboard.setOnClickListener(v -> selectPage(R.id.nav_dashboard));
        b.rowInstances.setOnClickListener(v -> selectPage(R.id.nav_instances));
        b.rowCards.setOnClickListener(v -> selectPage(R.id.nav_cards));
        b.rowCloud.setOnClickListener(v -> selectPage(R.id.nav_cloud));
        b.rowProfile.setOnClickListener(v -> selectPage(R.id.nav_profile));
        b.rowUpdates.setOnClickListener(v -> openPage(CloudUpdateActivity.class));
        b.rowDeploy.setOnClickListener(v -> openPage(DeployActivity.class));
        b.rowOnline.setOnClickListener(v -> openPage(OnlineUsersActivity.class));
        b.rowEmail.setOnClickListener(v -> openPage(UnlimitedEmailActivity.class));
        b.rowPeer.setOnClickListener(v -> openPage(PeerActivity.class));
        b.rowHelp.setOnClickListener(v -> openPage(HelpActivity.class));
        b.rowDocs.setOnClickListener(v -> {
            startActivity(new Intent(this, DocumentsActivity.class));
            closeDrawer();
        });
        b.rowApi.setOnClickListener(v -> openPage(ApiDocsActivity.class));
        b.rowServer.setOnClickListener(v -> {
            closeDrawer();
            Servers.show(this, false, () -> {
                // 切换节点后必须重新登录
                Prefs.clearSession();
                UiUtils.toast("节点已切换，请重新登录");
                startActivity(new Intent(this, LoginActivity.class));
                finish();
            });
        });
        b.tvLogout.setOnClickListener(v -> logout());
        b.tvDrawerServer.setText(Servers.name());
        markDrawer(currentId);
    }

    private void openPage(Class<?> target) {
        closeDrawer();
        b.getRoot().postDelayed(() -> startActivity(new Intent(this, target)), 160);
    }

    private void selectPage(int id) {
        showTab(id);
        closeDrawer();
    }

    public void openDrawer() {
        if (drawerOpen) return;
        drawerOpen = true;
        applyContentBlur(22f);
        b.drawerPanel.setTranslationX(-UiUtils.dp(this, 304));
        b.drawerPanel.setVisibility(View.VISIBLE);
        b.drawerScrim.setVisibility(View.VISIBLE);
        b.drawerScrim.setAlpha(0f);
        b.drawerPanel.animate()
                .translationX(0f)
                .setDuration(300)
                .setInterpolator(new DecelerateInterpolator(1.6f))
                .start();
        b.drawerScrim.animate().alpha(1f).setDuration(260).start();
        markDrawer(currentId);
        updateDocsDot();
    }

    /** 真实高斯模糊：抽屉打开时对页面内容加 RenderEffect（Android 12+）。 */
    private void applyContentBlur(float radius) {
        if (android.os.Build.VERSION.SDK_INT < 31) return;
        try {
            if (radius <= 0f) {
                b.fragmentContainer.setRenderEffect(null);
            } else {
                b.fragmentContainer.setRenderEffect(
                        android.graphics.RenderEffect.createBlurEffect(
                                radius, radius, android.graphics.Shader.TileMode.CLAMP));
            }
        } catch (Throwable ignored) {
        }
    }

    public void closeDrawer() {
        if (!drawerOpen) return;
        drawerOpen = false;
        applyContentBlur(0f);
        b.drawerPanel.animate()
                .translationX(-UiUtils.dp(this, 304))
                .setDuration(240)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> b.drawerPanel.setVisibility(View.GONE))
                .start();
        b.drawerScrim.animate().alpha(0f).setDuration(200)
                .withEndAction(() -> b.drawerScrim.setVisibility(View.GONE))
                .start();
    }

    private void markDrawer(int id) {
        b.rowDashboard.setBackgroundResource(0);
        b.rowInstances.setBackgroundResource(0);
        b.rowCards.setBackgroundResource(0);
        b.rowCloud.setBackgroundResource(0);
        b.rowProfile.setBackgroundResource(0);
        View target = id == R.id.nav_instances ? b.rowInstances
                : id == R.id.nav_cards ? b.rowCards
                : id == R.id.nav_cloud ? b.rowCloud
                : id == R.id.nav_profile ? b.rowProfile : b.rowDashboard;
        target.setBackgroundResource(R.drawable.bg_nav_selected);
    }

    private void updateDocsDot() {
        boolean hasNew = DocsBadge.hasNew(DataCache.documents);
        b.dotDocs.setVisibility(hasNew ? View.VISIBLE : View.GONE);
    }

    public void showTab(int itemId) {
        showTab(itemId, true);
    }

    public void showTab(int itemId, boolean animate) {
        if (switching) return;
        switching = true;
        try {
            int index = 0;
            if (itemId == R.id.nav_instances) index = 1;
            else if (itemId == R.id.nav_cards) index = 2;
            else if (itemId == R.id.nav_cloud) index = 3;
            else if (itemId == R.id.nav_profile) index = 4;
            currentId = itemId;
            markDrawer(itemId);

            FragmentTransaction tx = getSupportFragmentManager().beginTransaction();
            for (int i = 0; i < fragments.length; i++) {
                if (i == index) {
                    if (!fragments[i].isAdded()) {
                        tx.add(R.id.fragmentContainer, fragments[i], "tab_" + i);
                    } else {
                        tx.show(fragments[i]);
                    }
                } else if (fragments[i].isAdded()) {
                    tx.hide(fragments[i]);
                }
            }
            tx.commitAllowingStateLoss();
            final int pageIndex = index;
            if (animate) {
                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                    View v = fragments[pageIndex].getView();
                    if (v != null) {
                        v.setAlpha(0f);
                        v.setTranslationY(UiUtils.dp(this, 18));
                        v.animate().alpha(1f).translationY(0f)
                                .setDuration(280)
                                .setInterpolator(new DecelerateInterpolator(1.5f))
                                .start();
                    }
                }, 20);
            }
        } finally {
            switching = false;
        }
    }

    private void startBootRefresh() {
        b.bootLogo.animate().scaleX(1.08f).scaleY(1.08f).setDuration(900)
                .setInterpolator(new DecelerateInterpolator()).withEndAction(() ->
                        b.bootLogo.animate().scaleX(0.92f).scaleY(0.92f)
                                .setDuration(900).start()).start();
        ObjectAnimator pulse = ObjectAnimator.ofFloat(b.bootLogo, "alpha", 0.65f, 1f);
        pulse.setDuration(1100);
        pulse.setRepeatMode(ValueAnimator.REVERSE);
        pulse.setRepeatCount(ValueAnimator.INFINITE);

        long start = System.currentTimeMillis();
        DataCache.preload(() -> {
            bootDone = true;
            fillDrawerHeader();
            updateDocsDot();
            for (Fragment fragment : fragments) {
                if (fragment instanceof CacheAware && fragment.isAdded()
                        && fragment.getView() != null) {
                    ((CacheAware) fragment).onCacheReady();
                }
            }
            long elapsed = System.currentTimeMillis() - start;
            long delay = Math.max(0, 720 - elapsed);
            new Handler(Looper.getMainLooper()).postDelayed(this::hideBootOverlay, delay);
        });
    }

    private void hideBootOverlay() {
        if (isFinishing()) return;
        b.bootOverlay.animate().alpha(0f).scaleX(1.03f).scaleY(1.03f)
                .setDuration(380)
                .withEndAction(() -> b.bootOverlay.setVisibility(View.GONE))
                .start();
        revealContent();
    }

    private void revealContent() {
        View v = fragments[0] == null ? null : fragments[0].getView();
        if (v != null) {
            v.setAlpha(0f);
            v.setTranslationY(UiUtils.dp(this, 24));
            v.animate().alpha(1f).translationY(0f).setDuration(420)
                    .setInterpolator(new DecelerateInterpolator(1.4f)).start();
        }
    }

    private void fillDrawerHeader() {
        JSONObject user = DataCache.user;
        if (user == null || user.optInt("code") != 1) {
            user = Json.parse(Prefs.getString("user_json", "{}"));
        }
        String name = user.optString("display_name", user.optString("ac_id", "AC"));
        String uid = user.optString("user_id", user.optString("uid", user.optString("ac_id", "")));
        b.tvDrawerName.setText(name);
        b.tvDrawerUid.setText("UID " + uid);
    }

    private void validateSession() {
        Api.ready(() -> Io.run(() -> {
            String raw;
            try {
                raw = Api.get().get("/api/user/info");
            } catch (Exception e) {
                return;
            }
            JSONObject json = Json.parse(raw);
            int http = json.optInt("_http", 0);
            if (http == 401 || (json.optInt("code") == 0
                    && json.optString("message", "").contains("请先登录"))) {
                Prefs.clearSession();
                Io.main(this::exitToLogin);
            }
        }));
    }

    private void logout() {
        new Thread(() -> {
            try {
                Api.get().logout();
            } catch (Exception ignored) {
            }
            Prefs.clearSession();
            Io.main(this::exitToLogin);
        }).start();
    }

    private void exitToLogin() {
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }
}
