package com.ac.cloud.ui;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import com.ac.cloud.R;
import com.ac.cloud.core.Json;
import com.ac.cloud.core.Prefs;
import com.ac.cloud.databinding.ActivityRegisterBinding;
import com.ac.cloud.net.Calls;
import com.ac.cloud.util.UiUtils;

import org.json.JSONObject;

public class RegisterActivity extends AppCompatActivity {

    private ActivityRegisterBinding b;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int countdown = 0;
    private boolean submitting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiUtils.edgeToEdge(this);
        b = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        UiUtils.applyInsets(b.getRoot());

        b.header.tvTitle.setText("注册账号");
        b.header.tvSubtitle.setText("全部流程在应用内完成");
        b.header.btnBack.setOnClickListener(v -> finish());
        b.btnSendCode.setOnClickListener(v -> sendCode());
        b.btnRegister.setOnClickListener(v -> register());
        b.tvBackLogin.setOnClickListener(v -> finish());
    }

    private void sendCode() {
        String email = text(b.etEmail);
        if (email.isEmpty() || !email.contains("@")) {
            UiUtils.toast("请输入正确的邮箱");
            return;
        }
        b.btnSendCode.setEnabled(false);
        Calls.post("/api/email/send_code", body("email", email, "scene", "register"), json -> {
            if (json.optInt("code") == 1) {
                UiUtils.toast("验证码已发送");
                startCountdown();
            } else {
                UiUtils.toast(Json.message(json));
                b.btnSendCode.setEnabled(true);
            }
        });
    }

    private void startCountdown() {
        countdown = 60;
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (countdown <= 0) {
                    b.btnSendCode.setEnabled(true);
                    b.btnSendCode.setText("获取验证码");
                    return;
                }
                b.btnSendCode.setText(countdown + " s");
                countdown--;
                handler.postDelayed(this, 1000);
            }
        });
    }

    private void register() {
        if (submitting) return;
        final String acId = text(b.etAcId);
        String name = text(b.etDisplayName);
        String email = text(b.etEmail);
        String code = text(b.etCode);
        String pw = text(b.etPassword);
        String confirm = text(b.etConfirm);

        if (acId.isEmpty() || name.isEmpty() || email.isEmpty() || code.isEmpty() || pw.isEmpty()) {
            UiUtils.toast("请填写完整");
            return;
        }
        if (!acId.matches("^[a-zA-Z0-9_]{4,20}$")) {
            UiUtils.toast("AC ID 需为 4-20 位字母数字下划线");
            return;
        }
        if (pw.length() < 6) {
            UiUtils.toast("密码至少 6 位");
            return;
        }
        if (!pw.equals(confirm)) {
            UiUtils.toast("两次密码不一致");
            return;
        }

        submitting = true;
        b.btnRegister.setEnabled(false);
        try {
            JSONObject body = new JSONObject();
            body.put("ac_id", acId);
            body.put("display_name", name);
            body.put("email", email);
            body.put("email_code", code);
            body.put("password", pw);
            Calls.post("/api/app/register", body.toString(), json -> {
                submitting = false;
                b.btnRegister.setEnabled(true);
                if (json.optInt("code") == 1) {
                    Prefs.putString("last_account", acId);
                    UiUtils.toast("注册成功，请登录");
                    finish();
                } else {
                    UiUtils.toast(Json.message(json));
                }
            });
        } catch (Exception e) {
            submitting = false;
            b.btnRegister.setEnabled(true);
        }
    }

    private static String text(android.widget.EditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }

    private static String body(String k1, String v1, String k2, String v2) {
        try {
            JSONObject json = new JSONObject();
            json.put(k1, v1);
            json.put(k2, v2);
            return json.toString();
        } catch (Exception e) {
            return "{}";
        }
    }
}
