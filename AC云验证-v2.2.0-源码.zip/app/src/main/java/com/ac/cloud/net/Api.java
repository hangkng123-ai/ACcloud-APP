package com.ac.cloud.net;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;

import com.ac.cloud.service.ApiService;

import java.util.ArrayList;
import java.util.List;

import com.ac.cloud.IApiService;

/**
 * Thin AIDL proxy. Every network / crypto operation lives behind the
 * IApiService binder so the UI never touches HTTP directly.
 */
public final class Api {

    private static Context appContext;
    private static volatile IApiService service;
    private static final List<Runnable> pending = new ArrayList<>();
    private static boolean initialised;

    private Api() {
    }

    public static void init(Context ctx) {
        if (initialised) return;
        initialised = true;
        appContext = ctx.getApplicationContext();
        bind();
    }

    private static void bind() {
        Intent intent = new Intent(appContext, ApiService.class);
        appContext.bindService(intent, conn, Context.BIND_AUTO_CREATE);
    }

    private static final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            service = IApiService.Stub.asInterface(binder);
            try {
                binder.linkToDeath(() -> {
                    service = null;
                    bind();
                }, 0);
            } catch (RemoteException ignored) {
            }
            drain();
            new Thread(() -> {
                try {
                    service.warmup();
                } catch (Exception ignored) {
                }
            }, "ac-warmup").start();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            service = null;
        }
    };

    private static void drain() {
        List<Runnable> copy;
        synchronized (pending) {
            copy = new ArrayList<>(pending);
            pending.clear();
        }
        for (Runnable r : copy) r.run();
    }

    public static void ready(Runnable action) {
        if (service != null) {
            action.run();
            return;
        }
        synchronized (pending) {
            if (service != null) {
                action.run();
            } else {
                pending.add(action);
            }
        }
    }

    public static IApiService get() {
        return service;
    }
}
