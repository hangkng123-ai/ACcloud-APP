package com.ac.cloud.ui;

import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.ArrayAdapter;

import androidx.appcompat.app.AppCompatActivity;

import com.ac.cloud.core.Json;
import com.ac.cloud.core.NativeCore;
import com.ac.cloud.core.Prefs;
import com.ac.cloud.databinding.ActivityVerifyToolBinding;
import com.ac.cloud.net.Api;
import com.ac.cloud.net.Calls;
import com.ac.cloud.net.Io;
import com.ac.cloud.util.UiUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Fully native verification playground: AES-256-CBC encryption, MD5 signature
 * and response decryption are all executed inside the C++ JNI layer.
 */
public class VerifyToolActivity extends AppCompatActivity {

    private ActivityVerifyToolBinding b;
    private final List<String> ids = new ArrayList<>();
    private final List<String> labels = new ArrayList<>();
    private JSONArray instances = new JSONArray();
    private String selectedId = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiUtils.edgeToEdge(this);
        b = ActivityVerifyToolBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        UiUtils.applyInsets(b.getRoot());
        b.btnBack.setOnClickListener(v -> finish());
        b.tvNativeVersion.setText(NativeCore.version());
        b.etDevice.setText(deviceId());
        b.tilDevice.setEndIconOnClickListener(v -> b.etDevice.setText(deviceId()));
        b.btnVerify.setOnClickListener(v -> verify());
        b.dropdownInstance.setOnItemClickListener((parent, view, position, id) -> {
            if (position < ids.size()) selectedId = ids.get(position);
        });
        loadInstances();
    }

    private String deviceId() {
        String androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        if (androidId == null) androidId = "unknown";
        return NativeCore.fingerprint(androidId);
    }

    private void loadInstances() {
        Calls.get("/api/instances", json -> {
            instances = Json.array(json, "instances");
            ids.clear();
            labels.clear();
            for (int i = 0; i < instances.length(); i++) {
                JSONObject item = instances.optJSONObject(i);
                if (item == null) continue;
                ids.add(item.optString("instance_id"));
                labels.add(item.optString("name", "") + "  ·  " + item.optString("instance_id"));
            }
            b.dropdownInstance.setAdapter(new ArrayAdapter<>(this,
                    android.R.layout.simple_list_item_1, labels));
            if (!ids.isEmpty()) {
                selectedId = ids.get(0);
                b.dropdownInstance.setText(labels.get(0), false);
            } else {
                UiUtils.toast("请先创建应用实例");
            }
        });
    }

    private void verify() {
        String card = b.etCard.getText() == null ? "" : b.etCard.getText().toString().trim();
        String device = b.etDevice.getText() == null ? "" : b.etDevice.getText().toString().trim();
        if (card.isEmpty()) {
            UiUtils.toast("请输入卡密");
            return;
        }
        JSONObject instance = null;
        for (int i = 0; i < instances.length(); i++) {
            JSONObject item = instances.optJSONObject(i);
            if (item != null && selectedId.equals(item.optString("instance_id"))) {
                instance = item;
                break;
            }
        }
        if (instance == null) {
            UiUtils.toast("请选择应用实例");
            return;
        }
        JSONObject config = instance.optJSONObject("config");
        if (config == null) config = new JSONObject();
        String aes = config.optString("aes_key", "");
        String secret = config.optString("secret_key", "");
        String apiKey = Prefs.getString("api_key", "");
        if (aes.isEmpty() || secret.isEmpty() || apiKey.isEmpty()) {
            UiUtils.toast("实例密钥不完整，请在详情页刷新密钥");
            return;
        }

        b.btnVerify.setEnabled(false);
        long start = System.currentTimeMillis();
        final JSONObject target = instance;
        final JSONObject cfg = config;
        final String aesKey = aes;
        final String secretKey = secret;

        Api.ready(() -> Io.run(() -> {
            String resultText;
            try {
                JSONObject plain = new JSONObject();
                plain.put("card_password", card);
                plain.put("device_id", device);

                String[] encrypted = NativeCore.aesEncrypt(aesKey, plain.toString());
                String ts = String.valueOf(System.currentTimeMillis() / 1000);
                String sign = NativeCore.sign(aesKey, secretKey, apiKey, ts);

                JSONObject user = Json.parse(Prefs.getString("user_json", "{}"));
                JSONObject body = new JSONObject();
                body.put("_instance_id", target.optString("instance_id"));
                body.put("_uid", user.optString("user_id"));
                body.put("api_key", apiKey);
                body.put("sign", sign);
                body.put("timestamp", ts);
                body.put("data", encrypted[0]);
                body.put("iv", encrypted[1]);

                String raw = Api.get() == null ? "{}" : Api.get().post("/api/verify", body.toString());
                JSONObject resp = Json.parse(raw);
                if (resp.has("data") && resp.has("iv")) {
                    String decrypted = NativeCore.aesDecrypt(aesKey,
                            resp.optString("data"), resp.optString("iv"));
                    JSONObject dec = Json.parse(decrypted);
                    resultText = "签名 " + sign.substring(0, 12) + "…\n"
                            + "时间戳 " + ts + "\n\n" + pretty(dec);
                } else {
                    resultText = pretty(resp);
                }
            } catch (Exception e) {
                resultText = "验证失败：" + e.getClass().getSimpleName()
                        + (e.getMessage() == null ? "" : " · " + e.getMessage());
            }
            final String text = resultText;
            long cost = System.currentTimeMillis() - start;
            Io.main(() -> {
                b.btnVerify.setEnabled(true);
                b.tvTiming.setText(cost + " ms");
                b.tvResult.setText(text);
                b.tvResultTitle.setText("验证结果");
            });
        }));
    }

    private static String pretty(JSONObject json) {
        try {
            return json.toString(2);
        } catch (Exception e) {
            return json.toString();
        }
    }
}
