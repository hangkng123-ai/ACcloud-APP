package com.ac.cloud.ui;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ac.cloud.R;
import com.ac.cloud.core.Json;
import com.ac.cloud.databinding.ActivityUnlimitedEmailBinding;
import com.ac.cloud.databinding.DialogEmailCreateBinding;
import com.ac.cloud.databinding.DialogEmailForwardBinding;
import com.ac.cloud.net.Calls;
import com.ac.cloud.service.ApiService;
import com.ac.cloud.ui.adapters.EmailAdapter;
import com.ac.cloud.util.UiUtils;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class UnlimitedEmailActivity extends AppCompatActivity implements EmailAdapter.Listener {

    private ActivityUnlimitedEmailBinding b;
    private EmailAdapter adapter;
    private final List<String> domains = new ArrayList<>();
    private boolean bound;
    private String googleEmail = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiUtils.edgeToEdge(this);
        b = ActivityUnlimitedEmailBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        UiUtils.applyInsets(b.getRoot());

        b.header.tvTitle.setText("无限邮箱");
        b.header.tvSubtitle.setText("独立域名 · 自动转发");
        b.header.btnBack.setOnClickListener(v -> finish());
        b.header.btnAction.setVisibility(View.GONE);
        b.header.ivAction.setImageResource(R.drawable.ic_add);
        b.header.btnAction.setOnClickListener(v -> showCreateDialog());

        adapter = new EmailAdapter(this);
        b.recycler.setLayoutManager(new LinearLayoutManager(this));
        b.recycler.setAdapter(adapter);
        b.swipe.setOnRefreshListener(this::loadAll);

        b.btnSync.setOnClickListener(v -> syncRules());
        b.btnRefresh.setOnClickListener(v -> loadAll());
        b.btnBind.setOnClickListener(v -> openBind());
        b.btnRecheck.setOnClickListener(v -> loadAll());

        loadAll();
    }

    private void loadAll() {
        b.loading.setVisibility(View.VISIBLE);
        b.cardNotice.setVisibility(View.GONE);
        b.emptyView.setVisibility(View.GONE);
        b.header.btnAction.setVisibility(View.GONE);
        Calls.get("/api/google/status", json -> {
            b.loading.setVisibility(View.GONE);
            b.swipe.setRefreshing(false);
            if (json.optInt("code") != 1) {
                bound = false;
                googleEmail = "";
                renderBoundState();
                UiUtils.toast(Json.message(json));
                return;
            }
            bound = json.optBoolean("bound", false) || json.optInt("bound", 0) == 1;
            googleEmail = json.optString("google_email", "");
            renderBoundState();
            if (!bound) {
                adapter.submit(new JSONArray());
                b.recycler.setVisibility(View.GONE);
                b.emptyView.setVisibility(View.GONE);
                return;
            }
            loadDomains();
            loadEmails();
        });
    }

    private void renderBoundState() {
        b.cardNotice.setVisibility(bound ? View.GONE : View.VISIBLE);
        b.header.btnAction.setVisibility(bound ? View.VISIBLE : View.GONE);
        b.btnSync.setEnabled(bound);
        b.header.tvSubtitle.setText(bound
                ? (googleEmail.isEmpty() ? "Google 已绑定" : googleEmail)
                : "未绑定 Google");
    }

    private void loadDomains() {
        Calls.get("/api/unlimited_email/domains", json -> {
            if (json.optInt("code") != 1) return;
            JSONArray arr = Json.array(json, "domains");
            domains.clear();
            for (int i = 0; i < arr.length(); i++) {
                Object value = arr.opt(i);
                if (value instanceof String) {
                    String domain = ((String) value).trim();
                    if (!domain.isEmpty()) domains.add(domain);
                } else if (value instanceof JSONObject) {
                    JSONObject item = (JSONObject) value;
                    String domain = item.optString("domain", item.optString("name", ""));
                    if (!domain.isEmpty()) domains.add(domain);
                }
            }
        });
    }

    private void loadEmails() {
        Calls.get("/api/unlimited_email/list", json -> {
            b.swipe.setRefreshing(false);
            if (json.optInt("code") != 1) {
                UiUtils.toast(Json.message(json));
                return;
            }
            JSONArray emails = Json.array(json, "emails");
            adapter.submit(emails);
            boolean has = bound && emails.length() > 0;
            b.recycler.setVisibility(has ? View.VISIBLE : View.GONE);
            b.emptyView.setVisibility(bound && emails.length() == 0 ? View.VISIBLE : View.GONE);
            if (bound) {
                b.header.tvSubtitle.setText((googleEmail.isEmpty() ? "Google 已绑定" : googleEmail)
                        + " · " + emails.length() + " 个邮箱");
            }
        });
    }

    private void syncRules() {
        if (!bound) {
            UiUtils.toast("请先绑定 Google");
            return;
        }
        b.btnSync.setEnabled(false);
        Calls.post("/api/unlimited_email/sync", "{}", json -> {
            b.btnSync.setEnabled(true);
            if (json.optInt("code") != 1) {
                UiUtils.toast(Json.message(json));
                return;
            }
            String message = json.optString("message", "");
            UiUtils.toast(message.isEmpty() ? "规则已同步" : message);
            loadEmails();
        });
    }

    private void showCreateDialog() {
        if (!bound) {
            UiUtils.toast("请先绑定 Google");
            return;
        }
        if (domains.isEmpty()) {
            UiUtils.toast("暂无可用的邮箱域名，请稍后重试");
            return;
        }
        DialogEmailCreateBinding d = DialogEmailCreateBinding.inflate(getLayoutInflater());
        d.dropdownDomain.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, domains));
        d.dropdownDomain.setText(domains.get(0), false);

        AlertDialog dialog = new MaterialAlertDialogBuilder(this)
                .setTitle("新建无限邮箱")
                .setView(d.getRoot())
                .setNegativeButton("取消", null)
                .setPositiveButton("创建", null)
                .create();
        dialog.setOnShowListener(shown -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(v -> submitCreate(d, dialog)));
        dialog.show();
        UiUtils.applyGlassBlur(dialog);
    }

    private void submitCreate(DialogEmailCreateBinding d, AlertDialog dialog) {
        String prefix = text(d.etPrefix);
        String domain = d.dropdownDomain.getText() == null ? ""
                : d.dropdownDomain.getText().toString().trim();
        String forward = text(d.etForward);
        if (prefix.isEmpty()) {
            UiUtils.toast("请输入邮箱前缀");
            return;
        }
        if (domain.isEmpty()) {
            UiUtils.toast("请选择域名");
            return;
        }
        if (forward.isEmpty()) {
            UiUtils.toast("请输入转发邮箱");
            return;
        }
        try {
            JSONObject body = new JSONObject();
            body.put("prefix", prefix);
            body.put("domain", domain);
            body.put("forward_to", forward);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
            Calls.post("/api/unlimited_email/create", body.toString(), json -> {
                if (dialog.isShowing()) {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                }
                int code = json.optInt("code", -1);
                boolean needVerify = json.optBoolean("need_verify", false);
                if (code != 1 && !(code == 0 && needVerify)) {
                    UiUtils.toast(Json.message(json));
                    return;
                }
                dialog.dismiss();
                if (needVerify) {
                    showVerifyHint(forward);
                } else {
                    UiUtils.toast("邮箱已创建");
                }
                loadEmails();
            });
        } catch (Exception ignored) {
        }
    }

    private void showVerifyHint(String forward) {
        new MaterialAlertDialogBuilder(this)
                .setTitle("需要验证")
                .setMessage("请前往转发邮箱 " + forward + " 查收验证邮件并完成验证，完成后点击刷新。")
                .setPositiveButton("知道了", null)
                .show();
    }

    private void openBind() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse(ApiService.base() + "/google/login")));
        } catch (ActivityNotFoundException e) {
            UiUtils.toast("未找到可用的浏览器");
        }
    }

    @Override
    public void onCopy(JSONObject item) {
        String email = item.optString("email", "");
        if (!email.isEmpty()) UiUtils.copy("邮箱", email);
    }

    @Override
    public void onEditForward(JSONObject item) {
        DialogEmailForwardBinding d = DialogEmailForwardBinding.inflate(getLayoutInflater());
        d.etForward.setText(item.optString("forward_to", ""));
        AlertDialog dialog = new MaterialAlertDialogBuilder(this)
                .setTitle("修改转发邮箱")
                .setView(d.getRoot())
                .setNegativeButton("取消", null)
                .setPositiveButton("保存", null)
                .create();
        dialog.setOnShowListener(shown -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(v -> {
                    String forward = text(d.etForward);
                    if (forward.isEmpty()) {
                        UiUtils.toast("请输入转发邮箱");
                        return;
                    }
                    try {
                        JSONObject body = new JSONObject();
                        body.put("email_id", item.optString("email_id"));
                        body.put("forward_to", forward);
                        dialog.dismiss();
                        post("/api/unlimited_email/update_forward", body, "转发邮箱已更新");
                    } catch (Exception ignored) {
                    }
                }));
        dialog.show();
        UiUtils.applyGlassBlur(dialog);
    }

    @Override
    public void onToggle(JSONObject item) {
        boolean enabled = item.optBoolean("enabled", true);
        try {
            JSONObject body = new JSONObject();
            body.put("email_id", item.optString("email_id"));
            body.put("enabled", !enabled);
            post("/api/unlimited_email/toggle", body, enabled ? "邮箱已停用" : "邮箱已启用");
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onDelete(JSONObject item) {
        String email = item.optString("email", "");
        new MaterialAlertDialogBuilder(this)
                .setTitle("删除邮箱")
                .setMessage("确定删除 " + email + " ？删除后将停止接收与转发邮件。")
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", (dialog, which) -> {
                    try {
                        JSONObject body = new JSONObject();
                        body.put("email_id", item.optString("email_id"));
                        post("/api/unlimited_email/delete", body, "邮箱已删除");
                    } catch (Exception ignored) {
                    }
                })
                .show();
    }

    private void post(String path, JSONObject body, String successMessage) {
        Calls.post(path, body.toString(), json -> {
            if (json.optInt("code") != 1) {
                UiUtils.toast(Json.message(json));
                return;
            }
            UiUtils.toast(successMessage);
            loadEmails();
        });
    }

    private static String text(EditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }
}
