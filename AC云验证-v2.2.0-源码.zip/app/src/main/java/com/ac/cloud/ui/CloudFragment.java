package com.ac.cloud.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ac.cloud.R;
import com.ac.cloud.core.DataCache;
import com.ac.cloud.core.Json;
import com.ac.cloud.core.Prefs;
import com.ac.cloud.databinding.DialogCreateVariableBinding;
import com.ac.cloud.databinding.FragmentCloudBinding;
import com.ac.cloud.net.Calls;
import com.ac.cloud.ui.adapters.VariableAdapter;
import com.ac.cloud.util.UiUtils;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class CloudFragment extends Fragment implements VariableAdapter.Listener, CacheAware {

    private FragmentCloudBinding b;
    private VariableAdapter adapter;
    private final List<String> ids = new ArrayList<>();
    private final List<String> labels = new ArrayList<>();
    private String selectedId = "";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        b = FragmentCloudBinding.inflate(inflater, container, false);
        return b.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        adapter = new VariableAdapter(this);
        b.recycler.setLayoutManager(new LinearLayoutManager(requireContext()));
        b.recycler.setAdapter(adapter);
        b.swipe.setOnRefreshListener(this::loadVariables);
        b.btnCreateVar.setOnClickListener(v -> showCreateDialog());
        b.dropdownInstance.setOnItemClickListener((parent, view1, position, id) -> {
            if (position < ids.size()) {
                selectedId = ids.get(position);
                Prefs.putString("selected_instance", selectedId);
                loadVariables();
            }
        });
        UiUtils.bindMenu(view, this);
        if (DataCache.hasCore()) onCacheReady(); else loadInstances();
    }

    @Override
    public void onCacheReady() {
        if (!isAdded() || b == null) return;
        if (ids.isEmpty()) applyInstances(Json.array(DataCache.instances, "instances"));
    }

    private void loadInstances() {
        Calls.get("/api/instances", json -> {
            if (!isAdded()) return;
            DataCache.update("instances", json);
            applyInstances(Json.array(json, "instances"));
        });
    }

    private void applyInstances(JSONArray arr) {
            ids.clear();
            labels.clear();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject item = arr.optJSONObject(i);
                if (item == null) continue;
                ids.add(item.optString("instance_id"));
                labels.add(item.optString("name", "") + "  ·  " + item.optString("instance_id"));
            }
            b.dropdownInstance.setAdapter(new ArrayAdapter<>(requireContext(),
                    android.R.layout.simple_list_item_1, labels));

            String preferred = Prefs.getString("selected_instance", "");
            int index = ids.indexOf(preferred);
            if (index < 0 && !ids.isEmpty()) index = 0;

            if (ids.isEmpty()) {
                b.dropdownInstance.setText("", false);
                adapter.submit(new JSONArray());
                b.emptyView.setVisibility(View.VISIBLE);
                b.recycler.setVisibility(View.GONE);
                return;
            }
            selectedId = ids.get(index);
            Prefs.putString("selected_instance", selectedId);
            b.dropdownInstance.setText(labels.get(index), false);
            loadVariables();
    }

    private void loadVariables() {
        if (selectedId.isEmpty()) return;
        String path = "/api/cloud_control/variables?instance_id=" + selectedId;
        Calls.get(path, json -> {
            if (!isAdded()) return;
            b.swipe.setRefreshing(false);
            if (json.optInt("code") != 1) {
                UiUtils.toast(Json.message(json));
                return;
            }
            JSONArray arr = Json.array(json, "variables");
            adapter.submit(arr);
            b.emptyView.setVisibility(arr.length() == 0 ? View.VISIBLE : View.GONE);
            b.recycler.setVisibility(arr.length() == 0 ? View.GONE : View.VISIBLE);
        });
    }

    @Override
    public void onToggle(JSONObject variable, boolean value) {
        try {
            JSONObject body = new JSONObject();
            body.put("instance_id", selectedId);
            body.put("var_id", variable.optString("id"));
            body.put("value", value);
            Calls.post("/api/cloud_control/variable/update", body.toString(), json -> {
                if (!isAdded()) return;
                if (json.optInt("code") == 1) {
                    UiUtils.toast(value ? "已开启" : "已关闭");
                } else {
                    UiUtils.toast(Json.message(json));
                    loadVariables();
                }
            });
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onLongPress(JSONObject variable) {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("删除变量")
                .setMessage("确定删除 " + variable.optString("name") + " 吗？")
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", (d, w) -> {
                    try {
                        JSONObject body = new JSONObject();
                        body.put("instance_id", selectedId);
                        body.put("var_id", variable.optString("id"));
                        Calls.delete("/api/cloud_control/variable/delete", body.toString(), json -> {
                            if (!isAdded()) return;
                            if (json.optInt("code") == 1) {
                                UiUtils.toast("已删除");
                                loadVariables();
                            } else {
                                UiUtils.toast(Json.message(json));
                            }
                        });
                    } catch (Exception ignored) {
                    }
                }).show();
    }

    private void showCreateDialog() {
        if (selectedId.isEmpty()) {
            UiUtils.toast("请先创建应用实例");
            return;
        }
        DialogCreateVariableBinding dialog = DialogCreateVariableBinding.inflate(getLayoutInflater());
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("新建云控变量")
                .setView(dialog.getRoot())
                .setNegativeButton("取消", null)
                .setPositiveButton("创建", (d, w) -> {
                    String varId = dialog.etVarId.getText() == null ? ""
                            : dialog.etVarId.getText().toString().trim();
                    String name = dialog.etVarName.getText() == null ? ""
                            : dialog.etVarName.getText().toString().trim();
                    if (varId.isEmpty() || name.isEmpty()) {
                        UiUtils.toast("请填写完整");
                        return;
                    }
                    try {
                        JSONObject body = new JSONObject();
                        body.put("instance_id", selectedId);
                        body.put("var_id", varId);
                        body.put("name", name);
                        body.put("value", dialog.switchDefault.isChecked());
                        Calls.post("/api/cloud_control/variable/create", body.toString(), json -> {
                            if (!isAdded()) return;
                            if (json.optInt("code") == 1) {
                                UiUtils.toast("变量创建成功");
                                loadVariables();
                            } else {
                                UiUtils.toast(Json.message(json));
                            }
                        });
                    } catch (Exception ignored) {
                    }
                }).show();
    }
}
