package com.ac.cloud.ui.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ac.cloud.R;
import com.ac.cloud.databinding.ItemPeerBinding;

import org.json.JSONArray;
import org.json.JSONObject;

public class PeerAdapter extends RecyclerView.Adapter<PeerAdapter.VH> {

    public interface OnPeerDelete {
        void onPeerDelete(JSONObject peer);
    }

    private JSONArray items = new JSONArray();
    private final OnPeerDelete listener;

    public PeerAdapter(OnPeerDelete listener) {
        this.listener = listener;
    }

    public void submit(JSONArray array) {
        items = array == null ? new JSONArray() : array;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(ItemPeerBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        JSONObject item = items.optJSONObject(position);
        if (item == null) return;
        Context ctx = holder.b.getRoot().getContext();

        String uid = item.optString("uid", "");
        holder.b.tvUid.setText(uid.isEmpty() ? "未知 UID" : uid);

        String source = item.optString("source", "");
        if ("manual".equals(source)) {
            holder.b.tvSource.setText("手动添加");
            holder.b.tvSource.setBackgroundResource(R.drawable.bg_chip_warn);
            holder.b.tvSource.setTextColor(ctx.getColor(R.color.chip_warn_fg));
        } else if ("auto".equals(source) || source.isEmpty()) {
            holder.b.tvSource.setText("客户端上报");
            holder.b.tvSource.setBackgroundResource(R.drawable.bg_chip_info);
            holder.b.tvSource.setTextColor(ctx.getColor(R.color.chip_info_fg));
        } else {
            holder.b.tvSource.setText(source);
            holder.b.tvSource.setBackgroundResource(R.drawable.bg_chip_purple);
            holder.b.tvSource.setTextColor(ctx.getColor(R.color.chip_purple_fg));
        }

        String first = item.optString("first_seen", "");
        String last = item.optString("last_seen", "");
        holder.b.tvFirstSeen.setText("首次 " + (first.isEmpty() ? "--" : first));
        holder.b.tvLastSeen.setText("最近 " + (last.isEmpty() ? "--" : last));

        boolean canDelete = item.optBoolean("can_delete", false);
        holder.b.btnDelete.setVisibility(canDelete ? View.VISIBLE : View.GONE);
        holder.b.btnDelete.setOnClickListener(v -> {
            if (listener != null) listener.onPeerDelete(item);
        });
    }

    @Override
    public int getItemCount() {
        return items.length();
    }

    public static class VH extends RecyclerView.ViewHolder {
        final ItemPeerBinding b;

        VH(ItemPeerBinding binding) {
            super(binding.getRoot());
            b = binding;
        }
    }
}
