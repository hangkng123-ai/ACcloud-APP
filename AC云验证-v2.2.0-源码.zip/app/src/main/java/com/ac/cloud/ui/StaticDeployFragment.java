package com.ac.cloud.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ac.cloud.core.Json;
import com.ac.cloud.databinding.FragmentProjectsBinding;
import com.ac.cloud.net.Calls;
import com.ac.cloud.ui.adapters.ProjectAdapter;
import com.ac.cloud.util.UiUtils;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.json.JSONArray;
import org.json.JSONObject;

public class StaticDeployFragment extends Fragment implements ProjectAdapter.Listener {

    private FragmentProjectsBinding b;
    private ProjectAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        b = FragmentProjectsBinding.inflate(inflater, container, false);
        return b.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        adapter = new ProjectAdapter(false, this);
        b.recycler.setLayoutManager(new LinearLayoutManager(requireContext()));
        b.recycler.setAdapter(adapter);
        b.swipe.setOnRefreshListener(this::load);
        b.btnCreate.setOnClickListener(v -> createProject());
        b.tvEmptyTitle.setText("暂无静态站点");
        b.tvEmptyDesc.setText("上传 HTML / CSS / JS 即可上线");
        load();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!isHidden()) load();
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (!hidden) load();
    }

    private void load() {
        if (b == null) return;
        Calls.get("/api/static/projects", json -> {
            if (!isAdded()) return;
            b.swipe.setRefreshing(false);
            if (!Json.ok(json)) {
                UiUtils.toast(Json.message(json));
                return;
            }
            JSONArray arr = Json.array(json, "projects");
            adapter.submit(arr);
            boolean empty = arr.length() == 0;
            b.emptyView.setVisibility(empty ? View.VISIBLE : View.GONE);
            b.recycler.setVisibility(empty ? View.GONE : View.VISIBLE);
        });
    }

    private void createProject() {
        Context ctx = requireContext();
        EditText nameInput = DeploySupport.input(ctx, "如 my-site", "", false);
        EditText subInput = DeploySupport.input(ctx, "可留空自动分配", "", false);
        LinearLayout box = DeploySupport.form(ctx);
        DeploySupport.addField(ctx, box, "站点名称", nameInput);
        DeploySupport.addField(ctx, box, "子域名（可选）", subInput);

        AlertDialog dialog = new MaterialAlertDialogBuilder(ctx)
                .setTitle("新建静态站点")
                .setView(box)
                .setNegativeButton("取消", null)
                .setPositiveButton("创建并部署", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(v -> {
                    String name = nameInput.getText().toString().trim();
                    String sub = subInput.getText().toString().trim();
                    if (name.isEmpty()) {
                        UiUtils.toast("请填写站点名称");
                        return;
                    }
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setText("部署中…");
                    b.btnCreate.setEnabled(false);
                    b.btnCreate.setText("部署中…");
                    try {
                        JSONObject body = new JSONObject();
                        body.put("name", name);
                        body.put("subdomain", sub);
                        Calls.post("/api/static/create", body.toString(), json -> {
                            if (!isAdded()) return;
                            b.btnCreate.setEnabled(true);
                            b.btnCreate.setText("新建项目");
                            if (Json.ok(json)) {
                                dialog.dismiss();
                                UiUtils.toast("站点已创建，正在部署");
                                load();
                            } else {
                                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setText("创建并部署");
                                UiUtils.toast(Json.message(json));
                            }
                        });
                    } catch (Exception e) {
                        b.btnCreate.setEnabled(true);
                        b.btnCreate.setText("新建项目");
                        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setText("创建并部署");
                        UiUtils.toast("参数错误");
                    }
                }));
        dialog.show();
    }

    @Override
    public void onManage(JSONObject project) {
        Intent intent = new Intent(requireContext(), StaticProjectActivity.class);
        intent.putExtra("project_id", project.optString("project_id", ""));
        intent.putExtra("name", project.optString("name", ""));
        intent.putExtra("domain", project.optString("full_domain", ""));
        intent.putExtra("https_enabled", project.optBoolean("https_enabled", true));
        startActivity(intent);
    }

    @Override
    public void onLogs(JSONObject project) {
        UiUtils.toast("静态站点暂无运行日志");
    }

    @Override
    public void onMore(JSONObject project) {
        String pid = project.optString("project_id", "");
        String domain = project.optString("full_domain", "");
        boolean https = project.optBoolean("https_enabled", true);
        String[] items = new String[]{
                https ? "关闭 HTTPS" : "开启 HTTPS",
                "重命名",
                "复制域名",
                "删除站点"
        };
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle(project.optString("name", "站点"))
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        toggleHttps(pid, !https);
                    } else if (which == 1) {
                        rename(project);
                    } else if (which == 2) {
                        if (domain.isEmpty()) {
                            UiUtils.toast("暂无域名");
                        } else {
                            UiUtils.copy("域名", domain);
                        }
                    } else {
                        confirmDelete(project);
                    }
                })
                .show();
    }

    private void toggleHttps(String pid, boolean enabled) {
        try {
            JSONObject body = new JSONObject();
            body.put("project_id", pid);
            body.put("https_enabled", enabled);
            Calls.post("/api/user/static/toggle_https", body.toString(), json -> {
                if (!isAdded()) return;
                UiUtils.toast(Json.ok(json) ? (enabled ? "HTTPS 已开启" : "HTTPS 已关闭")
                        : Json.message(json));
                load();
            });
        } catch (Exception ignored) {
        }
    }

    private void rename(JSONObject project) {
        Context ctx = requireContext();
        EditText input = DeploySupport.input(ctx, "站点名称", project.optString("name", ""), false);
        LinearLayout box = DeploySupport.form(ctx);
        DeploySupport.addField(ctx, box, "新的站点名称", input);
        AlertDialog dialog = new MaterialAlertDialogBuilder(ctx)
                .setTitle("重命名站点")
                .setView(box)
                .setNegativeButton("取消", null)
                .setPositiveButton("保存", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(v -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) {
                        UiUtils.toast("请填写站点名称");
                        return;
                    }
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
                    try {
                        JSONObject body = new JSONObject();
                        body.put("project_id", project.optString("project_id", ""));
                        body.put("name", name);
                        Calls.post("/api/static/rename", body.toString(), json -> {
                            if (!isAdded()) return;
                            if (Json.ok(json)) {
                                dialog.dismiss();
                                UiUtils.toast("已重命名");
                                load();
                            } else {
                                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                                UiUtils.toast(Json.message(json));
                            }
                        });
                    } catch (Exception ignored2) {
                    }
                }));
        dialog.show();
    }

    private void confirmDelete(JSONObject project) {
        String pid = project.optString("project_id", "");
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("删除站点")
                .setMessage("确定删除「" + project.optString("name", "站点")
                        + "」吗？站点文件将被清除且无法恢复。")
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", (d, w) -> {
                    try {
                        JSONObject body = new JSONObject();
                        body.put("project_id", pid);
                        Calls.post("/api/static/project/delete", body.toString(), json -> {
                            if (!isAdded()) return;
                            UiUtils.toast(Json.ok(json) ? "站点已删除" : Json.message(json));
                            load();
                        });
                    } catch (Exception ignored) {
                    }
                })
                .show();
    }
}
