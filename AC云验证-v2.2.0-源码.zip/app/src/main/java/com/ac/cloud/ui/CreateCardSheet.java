package com.ac.cloud.ui;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.ac.cloud.R;
import com.ac.cloud.core.Json;
import com.ac.cloud.databinding.SheetCreateCardBinding;
import com.ac.cloud.net.Calls;
import com.ac.cloud.util.UiUtils;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class CreateCardSheet extends BottomSheetDialogFragment {

    private JSONArray instances = new JSONArray();
    private Runnable onCreated;
    private SheetCreateCardBinding b;
    private final List<String> ids = new ArrayList<>();
    private boolean device;

    /** Fragment 重建时必须存在无参构造。 */
    public CreateCardSheet() {
    }

    public CreateCardSheet(JSONArray instances, Runnable onCreated) {
        this.instances = instances == null ? new JSONArray() : instances;
        this.onCreated = onCreated;
        Bundle args = new Bundle();
        args.putString("instances_json", this.instances.toString());
        setArguments(args);
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        BottomSheetDialog dialog = new BottomSheetDialog(requireContext(), R.style.Theme_AC_BottomSheet);
        return dialog;
    }

    @Override
    public void onStart() {
        super.onStart();
        UiUtils.applyGlassBlur(getDialog());
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        b = SheetCreateCardBinding.inflate(inflater, container, false);
        return b.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        UiUtils.applyBottomInset(view);
        Bundle args = getArguments();
        if (args != null && args.getString("instances_json") != null) {
            try {
                instances = new JSONArray(args.getString("instances_json"));
            } catch (Exception ignored) {
            }
        }
        List<String> labels = new ArrayList<>();
        ids.clear();
        for (int i = 0; i < instances.length(); i++) {
            JSONObject item = instances.optJSONObject(i);
            String id = item.optString("instance_id");
            ids.add(id);
            labels.add(item.optString("name", id) + "  ·  " + id);
        }
        b.dropdownInstance.setAdapter(new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_list_item_1, labels));
        if (!labels.isEmpty()) b.dropdownInstance.setText(labels.get(0), false);

        b.chipType.setOnCheckedStateChangeListener((group, checkedIds) -> {
            device = checkedIds.contains(R.id.chipDevice);
            b.tilMaxDevices.setVisibility(device ? View.VISIBLE : View.GONE);
            b.rowActivation.setVisibility(device ? View.VISIBLE : View.GONE);
        });
        b.tilMaxDevices.setVisibility(View.GONE);
        b.rowActivation.setVisibility(View.GONE);

        b.btnGenerate.setOnClickListener(v -> generate());
    }

    private void generate() {
        int index = ids.indexOf(selectedId());
        if (index < 0 && !ids.isEmpty()) index = 0;
        String instanceId = index >= 0 ? ids.get(index) : "";
        if (instanceId.isEmpty()) {
            UiUtils.toast("请选择应用");
            return;
        }
        try {
            JSONObject body = new JSONObject();
            body.put("instance_id", instanceId);
            body.put("card_type", device ? "device" : "normal");
            body.put("valid_days", number(b.etDays, 30));
            body.put("quantity", number(b.etQuantity, 1));
            body.put("max_devices", number(b.etMaxDevices, 1));
            body.put("activation_mode", device && b.switchActivation.isChecked());
            body.put("prefix", text(b.etPrefix));

            String custom = text(b.etCustom);
            if (!custom.isEmpty()) {
                JSONArray arr = new JSONArray();
                for (String line : custom.split("\n")) {
                    String v = line.trim();
                    if (!v.isEmpty()) arr.put(v);
                }
                body.put("custom_cards", arr);
            }

            b.btnGenerate.setEnabled(false);
            Calls.post("/api/cards/create", body.toString(), json -> {
                b.btnGenerate.setEnabled(true);
                if (json.optInt("code") != 1) {
                    UiUtils.toast(Json.message(json));
                    return;
                }
                JSONArray created = Json.array(json, "cards");
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < created.length(); i++) {
                    if (i > 0) sb.append('\n');
                    sb.append(created.optString(i));
                }
                new MaterialAlertDialogBuilder(requireContext())
                        .setTitle("已生成 " + created.length() + " 张卡密")
                        .setMessage(sb.toString())
                        .setPositiveButton("复制全部", (d, w) -> UiUtils.copy("卡密", sb.toString()))
                        .setNegativeButton("完成", null)
                        .show();
                if (onCreated != null) onCreated.run();
                dismiss();
            });
        } catch (Exception e) {
            UiUtils.toast("参数错误");
        }
    }

    private String selectedId() {
        String text = b.dropdownInstance.getText() == null ? ""
                : b.dropdownInstance.getText().toString();
        int pos = text.lastIndexOf("·");
        if (pos >= 0) return text.substring(pos + 1).trim();
        return ids.isEmpty() ? "" : ids.get(0);
    }

    private static int number(android.widget.EditText et, int def) {
        try {
            String v = et.getText() == null ? "" : et.getText().toString().trim();
            return v.isEmpty() ? def : Integer.parseInt(v);
        } catch (Exception e) {
            return def;
        }
    }

    private static String text(android.widget.EditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }
}
