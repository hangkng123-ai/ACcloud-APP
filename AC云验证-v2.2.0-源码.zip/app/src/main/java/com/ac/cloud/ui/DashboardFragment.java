package com.ac.cloud.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.ac.cloud.R;
import com.ac.cloud.core.DataCache;
import com.ac.cloud.core.Json;
import com.ac.cloud.core.Prefs;
import com.ac.cloud.databinding.FragmentDashboardBinding;
import com.ac.cloud.databinding.ItemInstancePreviewBinding;
import com.ac.cloud.net.Api;
import com.ac.cloud.net.Io;
import com.ac.cloud.util.UiUtils;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.json.JSONArray;
import org.json.JSONObject;

public class DashboardFragment extends Fragment implements CacheAware {

    private FragmentDashboardBinding b;
    private JSONObject user = new JSONObject();
    private JSONArray instances = new JSONArray();
    private String announcement = "";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        b = FragmentDashboardBinding.inflate(inflater, container, false);
        return b.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        UiUtils.bindMenu(view, this);
        user = Json.parse(Prefs.getString("user_json", "{}"));
        bindUser();
        bindActions();
        loadNotice();
        if (DataCache.hasCore()) {
            onCacheReady();
        }
    }

    private void bindUser() {
        String name = user.optString("display_name", "AC");
        String uid = user.optString("user_id", "");
        b.tvHello.setText("你好，" + name);
        b.tvHeroName.setText(name);
        b.tvAvatar.setText(UiUtils.initial(name));
        b.tvHeroBadge.setText("已认证账户 · " + uid + " · 云端同步已开启");
    }

    private void bindActions() {
        b.barQuick.tvWindowTitle.setText("Quick Actions");
        b.barInstances.tvWindowTitle.setText("My Instances");

        b.qaCreate.setOnClickListener(v -> goTab(R.id.nav_instances));
        b.qaCards.setOnClickListener(v -> goTab(R.id.nav_cards));
        b.qaCloud.setOnClickListener(v -> goTab(R.id.nav_cloud));
        b.qaOnline.setOnClickListener(v -> openOnline());
        b.qaDeploy.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), DeployActivity.class);
            intent.putExtra("tab", 1);
            startActivity(intent);
        });
        b.qaEmail.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), UnlimitedEmailActivity.class)));
        b.qaUpdate.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), CloudUpdateActivity.class)));
        b.tvAllInstances.setOnClickListener(v -> goTab(R.id.nav_instances));
        b.tvMoreActions.setOnClickListener(v -> goTab(R.id.nav_profile));
        b.avatar.setOnClickListener(v -> goTab(R.id.nav_profile));
        b.cardAnnouncement.setOnClickListener(v -> showAnnouncement());
        b.btnNotifications.setOnClickListener(v -> openDocs());
        b.tvHeroStatus.setOnClickListener(v -> goTab(R.id.nav_instances));
    }

    @Override
    public void onCacheReady() {
        if (!isAdded() || b == null) return;
        user = DataCache.user != null && DataCache.user.optInt("code") == 1 ? DataCache.user
                : Json.parse(Prefs.getString("user_json", "{}"));
        bindUser();
        JSONArray inst = Json.array(DataCache.instances, "instances");
        JSONArray cards = Json.array(DataCache.cards, "cards");
        render(inst, cards);
        b.dotNotifications.setVisibility(
                com.ac.cloud.util.DocsBadge.hasNew(DataCache.documents) ? View.VISIBLE : View.GONE);
        Api.ready(() -> Io.run(() -> {
            loadLatency();
            loadOnlineCount(inst);
            loadExtraStats();
        }));
    }

    /** 对齐网页版：部署项目数 + 无限邮箱数 */
    private void loadExtraStats() {
        int deploy = 0;
        int emails = 0;
        try {
            JSONObject json = Json.parse(Api.get().get("/api/user/deploy/projects"));
            if (json.optInt("code") == 1) {
                deploy = json.optInt("count", Json.array(json, "projects").length());
            }
        } catch (Exception ignored) {
        }
        try {
            JSONObject json = Json.parse(Api.get().get("/api/unlimited_email/list"));
            if (json.optInt("code") == 1) {
                emails = Json.array(json, "emails").length();
            }
        } catch (Exception ignored) {
        }
        final int deployValue = deploy;
        final int emailValue = emails;
        Io.main(() -> {
            if (!isAdded() || b == null) return;
            b.tvStatDeploy.setText(String.valueOf(deployValue));
            b.tvStatEmail.setText(String.valueOf(emailValue));
        });
    }

    private void openDocs() {
        startActivity(new Intent(requireContext(), DocumentsActivity.class));
        com.ac.cloud.util.DocsBadge.markSeen(requireContext(), DataCache.documents);
        b.dotNotifications.setVisibility(View.GONE);
    }

    private void goTab(int id) {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).showTab(id);
        }
    }

    private void openOnline() {
        startActivity(new Intent(requireContext(), OnlineUsersActivity.class));
    }

    private void loadNotice() {
        Api.ready(() -> Io.run(() -> {
            String raw;
            try {
                raw = Api.get().get("/api/notice");
            } catch (Exception e) {
                return;
            }
            JSONObject json = Json.parse(raw);
            if (json.optInt("code") == 1 && json.optBoolean("enabled", true)) {
                String text = json.optString("text", "");
                if (!text.isEmpty()) {
                    Io.main(() -> {
                        if (!isAdded() || b == null) return;
                        announcement = text;
                        b.tvAnnTitle.setText("全站公告");
                        b.tvAnnContent.setText(text);
                    });
                }
            }
        }));
    }

    private void showAnnouncement() {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("最新公告")
                .setMessage(announcement.isEmpty()
                        ? "暂无公告，前往实例详情即可配置应用公告。" : announcement)
                .setPositiveButton("知道了", null)
                .show();
    }

    private void load() {
        Api.ready(() -> Io.run(() -> {
            String instRaw = "{}";
            String cardRaw = "{}";
            try {
                instRaw = Api.get().get("/api/instances");
                cardRaw = Api.get().get("/api/cards");
            } catch (Exception ignored) {
            }
            JSONObject instJson = Json.parse(instRaw);
            JSONObject cardJson = Json.parse(cardRaw);
            final JSONArray instArr = Json.array(instJson, "instances");
            final JSONArray cardArr = Json.array(cardJson, "cards");
            DataCache.update("instances", instJson);
            DataCache.update("cards", cardJson);
            Io.main(() -> render(instArr, cardArr));
            loadOnlineCount(instArr);
            loadLatency();
        }));
    }

    private void render(JSONArray instArr, JSONArray cardArr) {
        if (!isAdded()) return;
        instances = instArr;
        int running = 0;
        long apiTotal = 0;
        for (int i = 0; i < instArr.length(); i++) {
            JSONObject item = instArr.optJSONObject(i);
            if (item == null) continue;
            if ("running".equals(item.optString("status"))) running++;
            JSONObject stats = item.optJSONObject("api_stats");
            if (stats != null) apiTotal += stats.optInt("total", 0);
            JSONObject config = item.optJSONObject("config");
            if (config != null && announcement.isEmpty()) {
                String a = config.optString("announcement_zh", "");
                if (a.isEmpty()) a = config.optString("announcement", "");
                if (!a.isEmpty()) announcement = a;
            }
        }
        b.tvHeroInstances.setText(String.valueOf(instArr.length()));
        b.tvHeroRunning.setText(String.valueOf(running));
        b.tvHeroCards.setText(String.valueOf(cardArr.length()));
        b.tvStatInstances.setText(String.valueOf(instArr.length()));
        b.tvStatCards.setText(String.valueOf(cardArr.length()));
        b.tvStatApi.setText(UiUtils.formatNumber(apiTotal));
        b.tvAnnContent.setText(announcement.isEmpty()
                ? "前往实例详情即可配置应用公告，客户端将实时同步。" : announcement);
        b.tvAnnTitle.setText(instArr.length() > 0 ? "来自 " + instArr.optJSONObject(0).optString("name", "应用") : "暂无公告");

        b.listInstances.removeAllViews();
        int count = Math.min(instArr.length(), 3);
        for (int i = 0; i < count; i++) {
            JSONObject item = instArr.optJSONObject(i);
            if (item == null) continue;
            ItemInstancePreviewBinding row = ItemInstancePreviewBinding.inflate(
                    LayoutInflater.from(requireContext()), b.listInstances, false);
            row.tvName.setText(item.optString("name", ""));
            row.tvId.setText(item.optString("instance_id", ""));
            boolean on = "running".equals(item.optString("status"));
            row.dot.setBackgroundResource(on ? R.drawable.bg_dot_success : R.drawable.bg_dot_warn);
            row.getRoot().setOnClickListener(v -> goTab(R.id.nav_instances));
            b.listInstances.addView(row.getRoot());
        }
        if (count == 0) {
            android.widget.TextView empty = new android.widget.TextView(requireContext());
            empty.setText("还没有实例，点击「新建应用」开始。");
            empty.setTextColor(requireContext().getColor(R.color.on_surface_variant));
            empty.setTextSize(12);
            empty.setPadding(0, UiUtils.dp(requireContext(), 8), 0, 0);
            b.listInstances.addView(empty);
        }
    }

    private void loadLatency() {
        try {
            JSONObject json = Json.parse(Api.get().ping());
            final int latency = json.optInt("latency", 0);
            if (latency > 0) {
                Io.main(() -> {
                    if (isAdded()) {
                        b.tvLatency.setText(latency + " ms");
                        b.tvHeroStatus.setText("服务运行中");
                    }
                });
            }
        } catch (Exception ignored) {
        }
    }

    private void loadOnlineCount(JSONArray arr) {
        String apiKey = Prefs.getString("api_key", "");
        if (apiKey.isEmpty()) return;
        int total = 0;
        for (int i = 0; i < Math.min(arr.length(), 3); i++) {
            JSONObject item = arr.optJSONObject(i);
            if (item == null) continue;
            try {
                JSONObject body = new JSONObject();
                body.put("instance_id", item.optString("instance_id"));
                body.put("api_key", apiKey);
                JSONObject resp = Json.parse(Api.get().post("/api/online/status", body.toString()));
                if (resp.optInt("code") == 1) total += resp.optInt("online_count", 0);
            } catch (Exception ignored) {
            }
        }
        final int value = total;
        Io.main(() -> {
            if (isAdded()) b.tvStatOnline.setText(String.valueOf(value));
        });
    }

}
