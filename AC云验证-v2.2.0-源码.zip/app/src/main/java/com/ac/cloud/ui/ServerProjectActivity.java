package com.ac.cloud.ui;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.ac.cloud.R;
import com.ac.cloud.core.Json;
import com.ac.cloud.databinding.ActivityServerProjectBinding;
import com.ac.cloud.databinding.ItemDeployFileBinding;
import com.ac.cloud.net.Calls;
import com.ac.cloud.net.Io;
import com.ac.cloud.util.UiUtils;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URLConnection;
import java.util.List;
import java.util.Locale;

public class ServerProjectActivity extends AppCompatActivity {

    private ActivityServerProjectBinding b;
    private String projectId = "";
    private String projectName = "";
    private String projectDomain = "";
    private String projectStatus = "";
    private String mainFile = "";
    private boolean httpsEnabled = true;
    private boolean guardEnabled = true;

    private final ActivityResultLauncher<Intent> picker = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() != RESULT_OK || result.getData() == null) return;
                onPickedPaths(result.getData()
                        .getStringArrayListExtra(FileManagerActivity.RESULT_PATHS));
            });

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiUtils.edgeToEdge(this);
        b = ActivityServerProjectBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        UiUtils.applyInsets(b.getRoot());

        Intent intent = getIntent();
        projectId = intent.getStringExtra("project_id") == null ? "" : intent.getStringExtra("project_id");
        projectName = intent.getStringExtra("name") == null ? "" : intent.getStringExtra("name");
        projectDomain = intent.getStringExtra("domain") == null ? "" : intent.getStringExtra("domain");
        projectStatus = intent.getStringExtra("status") == null ? "approved" : intent.getStringExtra("status");
        httpsEnabled = intent.getBooleanExtra("https_enabled", true);
        guardEnabled = intent.getBooleanExtra("sensitive_guard", true);

        b.header.tvTitle.setText("服务器项目");
        b.header.tvSubtitle.setText("文件与运行管理");
        b.header.btnBack.setOnClickListener(v -> finish());
        b.header.btnAction.setVisibility(View.VISIBLE);
        b.header.ivAction.setImageResource(R.drawable.ic_refresh);
        b.header.btnAction.setOnClickListener(v -> loadFiles());

        b.tvName.setText(projectName.isEmpty() ? "服务器项目" : projectName);
        bindStatus();
        bindChips();
        updateDomain();

        b.btnUpload.setOnClickListener(v -> picker.launch(new Intent(this,
                FileManagerActivity.class).putExtra(FileManagerActivity.EXTRA_MULTI, true)));
        b.btnCreateFile.setOnClickListener(v -> createFile());
        b.btnMkdir.setOnClickListener(v -> createFolder());
        b.btnDeps.setOnClickListener(v -> showDeps());
        b.btnLogs.setOnClickListener(v -> showLogs());
        b.btnRestart.setOnClickListener(v -> restart());

        loadFiles();
    }

    private void bindStatus() {
        String label;
        int bg;
        int fg;
        if ("pending".equals(projectStatus)) {
            label = "待审批";
            bg = R.drawable.bg_chip_warn;
            fg = R.color.chip_warn_fg;
        } else if ("rejected".equals(projectStatus)) {
            label = "已拒绝";
            bg = R.drawable.bg_chip_danger;
            fg = R.color.chip_danger_fg;
        } else {
            label = "已批准";
            bg = R.drawable.bg_chip_success;
            fg = R.color.chip_success_fg;
            if (projectStatus.isEmpty()) label = "运行中";
        }
        b.tvStatus.setText(label);
        b.tvStatus.setBackgroundResource(bg);
        b.tvStatus.setTextColor(getColor(fg));
    }

    private void bindChips() {
        b.tvHttps.setText(httpsEnabled ? "HTTPS 开" : "HTTPS 关");
        b.tvHttps.setBackgroundResource(httpsEnabled
                ? R.drawable.bg_chip_success : R.drawable.bg_chip_warn);
        b.tvHttps.setTextColor(getColor(httpsEnabled
                ? R.color.chip_success_fg : R.color.chip_warn_fg));

        b.tvGuard.setText(guardEnabled ? "防护开" : "防护关");
        b.tvGuard.setBackgroundResource(guardEnabled
                ? R.drawable.bg_chip_info : R.drawable.bg_chip_warn);
        b.tvGuard.setTextColor(getColor(guardEnabled
                ? R.color.chip_info_fg : R.color.chip_warn_fg));
    }

    private void updateDomain() {
        String url = DeploySupport.domainUrl(projectDomain, httpsEnabled);
        b.tvDomain.setText(url.isEmpty() ? "等待分配域名" : url);
        b.btnOpenDomain.setVisibility(url.isEmpty() ? View.GONE : View.VISIBLE);
        b.tvDomain.setOnClickListener(v -> DeploySupport.open(this, url));
        b.btnOpenDomain.setOnClickListener(v -> DeploySupport.open(this, url));
        b.tvMain.setText("主程序：" + (mainFile.isEmpty() ? "未设置" : mainFile));
    }

    private void loadFiles() {
        b.tvFilesEmpty.setText("加载中…");
        b.tvFilesEmpty.setVisibility(View.VISIBLE);
        Calls.get("/api/deploy/files?project_id=" + DeploySupport.enc(projectId), json -> {
            if (isFinishing() || isDestroyed()) return;
            if (!Json.ok(json)) {
                b.tvFileCount.setText("0 项");
                b.containerFiles.removeAllViews();
                b.tvFilesEmpty.setText("加载失败：" + Json.message(json));
                b.tvFilesEmpty.setVisibility(View.VISIBLE);
                return;
            }
            String full = json.optString("full_domain", "");
            if (!full.isEmpty()) {
                projectDomain = full;
                updateDomain();
            }
            mainFile = json.optString("main_file", "");
            updateDomain();

            b.containerFiles.removeAllViews();
            JSONArray tree = Json.array(json, "tree");
            int count = renderTree(tree, "", 0);
            b.tvFileCount.setText(count + " 项");
            b.tvFilesEmpty.setText(count == 0 ? "暂无文件，上传或新建文件开始" : "");
            b.tvFilesEmpty.setVisibility(count == 0 ? View.VISIBLE : View.GONE);
        });
    }

    private int renderTree(JSONArray nodes, String parentPath, int depth) {
        if (nodes == null || depth > 12) return 0;
        int count = 0;
        for (int i = 0; i < nodes.length(); i++) {
            JSONObject node = nodes.optJSONObject(i);
            if (node == null) continue;
            String type = node.optString("type", "file");
            String name = node.optString("name", "");
            String path = node.optString("path", "");
            if (path.isEmpty()) {
                path = parentPath.isEmpty() ? name : parentPath + "/" + name;
            }
            if (name.isEmpty()) name = DeploySupport.fileName(path);
            boolean folder = "folder".equals(type) || "dir".equals(type) || "directory".equals(type);
            addFileRow(node, folder, name, path);
            count++;
            JSONArray children = node.optJSONArray("children");
            if (children != null) count += renderTree(children, path, depth + 1);
        }
        return count;
    }

    private void addFileRow(JSONObject node, boolean folder, String name, String path) {
        ItemDeployFileBinding row = ItemDeployFileBinding.inflate(getLayoutInflater(),
                b.containerFiles, false);
        row.ivIcon.setImageResource(folder ? R.drawable.ic_folder : R.drawable.ic_file);
        row.tvName.setText(name);
        row.tvPath.setText(path);

        String size = node.optString("size_str", "");
        if (size.isEmpty()) {
            long bytes = node.optLong("size", 0);
            if (bytes > 0) size = bytes + " B";
        }
        row.tvSize.setText(folder ? "文件夹" : size);
        row.btnMain.setText("设为主程序");

        if (folder) {
            row.rowActions.setVisibility(View.GONE);
        } else {
            row.rowActions.setVisibility(View.VISIBLE);
            boolean isPy = path.toLowerCase(Locale.ROOT).endsWith(".py");
            boolean isMain = path.equals(mainFile) || name.equals(mainFile);
            row.btnMain.setVisibility(isPy && !isMain ? View.VISIBLE : View.GONE);
            row.btnEdit.setOnClickListener(v -> editFile(path, name));
            row.btnMain.setOnClickListener(v -> setMain(path));
            row.btnDelete.setOnClickListener(v -> confirmDelete(path, name));
        }
        b.containerFiles.addView(row.getRoot());
    }

    private void editFile(String path, String name) {
        AlertDialog progress = DeploySupport.progress(this, "正在读取文件…");
        Calls.get("/api/deploy/file_content?project_id=" + DeploySupport.enc(projectId)
                + "&path=" + DeploySupport.enc(path), json -> {
            progress.dismiss();
            if (isFinishing() || isDestroyed()) return;
            if (!Json.ok(json) && !json.has("content")) {
                UiUtils.toast(Json.message(json));
                return;
            }
            String content = json.optString("content", json.optString("file_content", ""));
            EditText input = DeploySupport.input(this, "文件内容", content, true);
            input.setTypeface(Typeface.MONOSPACE);
            LinearLayout box = DeploySupport.form(this);
            box.addView(input, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, UiUtils.dp(this, 320)));
            new MaterialAlertDialogBuilder(this)
                    .setTitle(name)
                    .setView(box)
                    .setNegativeButton("取消", null)
                    .setPositiveButton("保存", (d, w) -> saveFile(path, input.getText().toString()))
                    .show();
        });
    }

    private void saveFile(String path, String content) {
        try {
            JSONObject body = new JSONObject();
            body.put("project_id", projectId);
            body.put("path", path);
            body.put("content", content);
            Calls.post("/api/deploy/save_file", body.toString(), json -> {
                if (isFinishing()) return;
                UiUtils.toast(Json.ok(json) ? "文件已保存" : Json.message(json));
                if (Json.ok(json)) loadFiles();
            });
        } catch (Exception ignored) {
        }
    }

    private void createFile() {
        EditText pathInput = DeploySupport.input(this, "可留空，如 src", "", false);
        EditText nameInput = DeploySupport.input(this, "如 main.py", "", false);
        EditText contentInput = DeploySupport.input(this, "文件内容", "", true);
        contentInput.setTypeface(Typeface.MONOSPACE);
        LinearLayout box = DeploySupport.form(this);
        DeploySupport.addField(this, box, "相对路径（可选）", pathInput);
        DeploySupport.addField(this, box, "文件名", nameInput);
        DeploySupport.addField(this, box, "文件内容", contentInput);

        AlertDialog dialog = new MaterialAlertDialogBuilder(this)
                .setTitle("新建文件")
                .setView(box)
                .setNegativeButton("取消", null)
                .setPositiveButton("创建", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(v -> {
                    String name = nameInput.getText().toString().trim();
                    if (name.isEmpty()) {
                        UiUtils.toast("请填写文件名");
                        return;
                    }
                    String dir = DeploySupport.cleanPath(pathInput.getText().toString());
                    String path = dir.isEmpty() ? name : dir + "/" + name;
                    if (name.contains("/")) {
                        path = DeploySupport.cleanPath(name);
                        name = DeploySupport.fileName(path);
                    }
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
                    try {
                        JSONObject body = new JSONObject();
                        body.put("project_id", projectId);
                        body.put("path", path);
                        body.put("content", contentInput.getText().toString());
                        Calls.post("/api/deploy/create_file", body.toString(), json -> {
                            if (isFinishing()) return;
                            if (Json.ok(json)) {
                                dialog.dismiss();
                                UiUtils.toast("文件已创建");
                                loadFiles();
                            } else {
                                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                                UiUtils.toast(Json.message(json));
                            }
                        });
                    } catch (Exception ignored2) {
                    }
                }));
        dialog.show();
    }

    private void createFolder() {
        EditText pathInput = DeploySupport.input(this, "可留空", "", false);
        EditText nameInput = DeploySupport.input(this, "如 assets", "", false);
        LinearLayout box = DeploySupport.form(this);
        DeploySupport.addField(this, box, "父目录（可选）", pathInput);
        DeploySupport.addField(this, box, "文件夹名称", nameInput);

        AlertDialog dialog = new MaterialAlertDialogBuilder(this)
                .setTitle("新建文件夹")
                .setView(box)
                .setNegativeButton("取消", null)
                .setPositiveButton("创建", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(v -> {
                    String name = nameInput.getText().toString().trim();
                    if (name.isEmpty()) {
                        UiUtils.toast("请填写文件夹名称");
                        return;
                    }
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
                    try {
                        JSONObject body = new JSONObject();
                        body.put("project_id", projectId);
                        body.put("dir_path", DeploySupport.cleanPath(pathInput.getText().toString()));
                        body.put("dir_name", name);
                        Calls.post("/api/deploy/mkdir", body.toString(), json -> {
                            if (isFinishing()) return;
                            if (Json.ok(json)) {
                                dialog.dismiss();
                                UiUtils.toast("文件夹已创建");
                                loadFiles();
                            } else {
                                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                                UiUtils.toast(Json.message(json));
                            }
                        });
                    } catch (Exception ignored2) {
                    }
                }));
        dialog.show();
    }

    private void setMain(String path) {
        try {
            JSONObject body = new JSONObject();
            body.put("project_id", projectId);
            body.put("path", path);
            Calls.post("/api/deploy/set_main", body.toString(), json -> {
                if (isFinishing()) return;
                UiUtils.toast(Json.ok(json) ? "主程序已设置" : Json.message(json));
                if (Json.ok(json)) loadFiles();
            });
        } catch (Exception ignored) {
        }
    }

    private void confirmDelete(String path, String name) {
        new MaterialAlertDialogBuilder(this)
                .setTitle("删除文件")
                .setMessage("确定删除「" + path + "」吗？")
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", (d, w) -> {
                    try {
                        JSONObject body = new JSONObject();
                        body.put("project_id", projectId);
                        body.put("path", path);
                        Calls.post("/api/deploy/file/delete", body.toString(), json -> {
                            if (isFinishing()) return;
                            UiUtils.toast(Json.ok(json) ? "已删除 " + name : Json.message(json));
                            if (Json.ok(json)) loadFiles();
                        });
                    } catch (Exception ignored) {
                    }
                })
                .show();
    }

    private void showDeps() {
        AlertDialog progress = DeploySupport.progress(this, "正在加载依赖…");
        Calls.get("/api/deploy/deps/list?project_id=" + DeploySupport.enc(projectId), json -> {
            progress.dismiss();
            if (isFinishing() || isDestroyed()) return;

            StringBuilder sb = new StringBuilder();
            JSONArray arr = json.optJSONArray("deps");
            if (arr == null) arr = json.optJSONArray("dependencies");
            if (arr == null) arr = json.optJSONArray("packages");
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    Object item = arr.opt(i);
                    if (item instanceof JSONObject) {
                        JSONObject dep = (JSONObject) item;
                        sb.append(dep.optString("name", dep.optString("package", dep.toString())));
                        String version = dep.optString("version", "");
                        if (!version.isEmpty()) sb.append("  ").append(version);
                    } else {
                        sb.append(item == null ? "" : item.toString());
                    }
                    sb.append('\n');
                }
            }
            if (sb.length() == 0) {
                String raw = json.optString("deps", "");
                if (raw.isEmpty()) raw = json.optString("installed", "");
                sb.append(raw.isEmpty()
                        ? (Json.ok(json) ? "暂无已安装依赖" : "加载失败：" + Json.message(json))
                        : raw);
            }

            TextView list = new TextView(this);
            list.setText(sb.toString().trim());
            list.setTextSize(11);
            list.setTypeface(Typeface.MONOSPACE);
            list.setTextIsSelectable(true);
            list.setTextColor(getColor(R.color.on_surface));
            int pad = UiUtils.dp(this, 12);
            list.setPadding(pad, pad, pad, pad);

            ScrollView scroll = new ScrollView(this);
            scroll.addView(list, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            FrameLayout frame = new FrameLayout(this);
            frame.addView(scroll, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            frame.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, UiUtils.dp(this, 220)));

            EditText pkg = DeploySupport.input(this, "如 requests", "", false);
            LinearLayout box = DeploySupport.form(this);
            TextView label = new TextView(this);
            label.setText("已安装依赖");
            label.setTextSize(12);
            label.setTextColor(getColor(R.color.on_surface_variant));
            label.setPadding(UiUtils.dp(this, 4), 0, UiUtils.dp(this, 4), UiUtils.dp(this, 4));
            box.addView(label);
            box.addView(frame);
            DeploySupport.addField(this, box, "安装新依赖", pkg);

            AlertDialog dialog = new MaterialAlertDialogBuilder(this)
                    .setTitle("依赖管理")
                    .setView(box)
                    .setNegativeButton("关闭", null)
                    .setPositiveButton("安装", null)
                    .create();
            dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                    .setOnClickListener(v -> {
                        String name = pkg.getText().toString().trim();
                        if (name.isEmpty()) {
                            UiUtils.toast("请输入包名");
                            return;
                        }
                        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
                        installDep(name, dialog);
                    }));
            dialog.show();
        });
    }

    private void installDep(String name, AlertDialog dialog) {
        try {
            JSONObject body = new JSONObject();
            body.put("package", name);
            body.put("project_id", projectId);
            Calls.post("/api/deploy/deps/install", body.toString(), json -> {
                if (isFinishing()) return;
                if (dialog.isShowing()) {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                }
                UiUtils.toast(Json.ok(json) ? "依赖安装成功" : Json.message(json));
                if (Json.ok(json)) {
                    dialog.dismiss();
                    showDeps();
                }
            });
        } catch (Exception ignored) {
        }
    }

    private void showLogs() {
        AlertDialog progress = DeploySupport.progress(this, "正在加载日志…");
        Calls.get("/api/deploy/logs?project_id=" + DeploySupport.enc(projectId), json -> {
            progress.dismiss();
            if (isFinishing() || isDestroyed()) return;
            showLogDialog(DeploySupport.logs(json));
        });
    }

    private void showLogDialog(String content) {
        TextView tv = new TextView(this);
        tv.setText(content == null || content.isEmpty() ? "暂无日志" : content);
        tv.setTextSize(11);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextIsSelectable(true);
        tv.setTextColor(getColor(R.color.on_surface));
        int pad = UiUtils.dp(this, 16);
        tv.setPadding(pad, pad, pad, pad);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(tv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        FrameLayout frame = new FrameLayout(this);
        frame.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        frame.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, UiUtils.dp(this, 380)));

        new MaterialAlertDialogBuilder(this)
                .setTitle("运行日志")
                .setView(frame)
                .setNegativeButton("关闭", null)
                .setPositiveButton("清空日志", (d, w) -> clearLogs())
                .show();
    }

    private void clearLogs() {
        try {
            JSONObject body = new JSONObject();
            body.put("project_id", projectId);
            Calls.post("/api/deploy/logs/clear", body.toString(), json -> {
                if (isFinishing()) return;
                UiUtils.toast(Json.ok(json) ? "日志已清空" : Json.message(json));
            });
        } catch (Exception ignored) {
        }
    }

    private void restart() {
        try {
            JSONObject body = new JSONObject();
            body.put("project_id", projectId);
            Calls.post("/api/deploy/restart", body.toString(), json -> {
                if (isFinishing()) return;
                UiUtils.toast(Json.ok(json) ? "重启指令已发送" : Json.message(json));
            });
        } catch (Exception ignored) {
        }
    }

    private void onPickedPaths(java.util.ArrayList<String> paths) {
        if (paths == null || paths.isEmpty()) return;
        List<Uri> uris = new java.util.ArrayList<>();
        for (String path : paths) uris.add(Uri.fromFile(new File(path)));
        onPicked(uris);
    }

    private void onPicked(List<Uri> uris) {
        if (uris == null || uris.isEmpty()) return;
        AlertDialog progress = DeploySupport.progress(this, "正在上传 0/" + uris.size());
        uploadNext(uris, 0, 0, progress);
    }

    private void uploadNext(List<Uri> uris, int index, int success, AlertDialog progress) {
        if (isFinishing() || isDestroyed()) {
            if (progress.isShowing()) progress.dismiss();
            return;
        }
        if (index >= uris.size()) {
            if (progress.isShowing()) progress.dismiss();
            UiUtils.toast("上传完成：成功 " + success + " / " + uris.size());
            loadFiles();
            return;
        }
        progress.setMessage("正在上传 " + (index + 1) + "/" + uris.size());
        Uri uri = uris.get(index);
        String displayName = displayName(uri);
        String mime = mimeOf(displayName);
        Io.run(() -> {
            final File cached;
            try {
                cached = copyToCache(uri, displayName);
            } catch (Exception e) {
                Io.main(() -> {
                    UiUtils.toast("读取失败：" + displayName);
                    uploadNext(uris, index + 1, success, progress);
                });
                return;
            }
            Io.main(() -> {
                JSONObject fields = new JSONObject();
                try {
                    fields.put("project_id", projectId);
                    fields.put("relative_path", "");
                } catch (Exception ignored) {
                }
                com.ac.cloud.service.ApiService.uploadProgress = (written, total) -> {
                    int pct = total <= 0 ? 0 : (int) (written * 100 / total);
                    Io.main(() -> progress.setMessage("正在上传 " + (index + 1) + "/" + uris.size()
                            + " · " + pct + "%"));
                };
                Calls.upload("/api/deploy/upload", fields.toString(), cached.getAbsolutePath(),
                        "file", displayName, mime, json -> {
                            com.ac.cloud.service.ApiService.uploadProgress = null;
                            cached.delete();
                            if (Json.ok(json)) {
                                uploadNext(uris, index + 1, success + 1, progress);
                            } else {
                                UiUtils.toast(displayName + "：" + Json.message(json));
                                uploadNext(uris, index + 1, success, progress);
                            }
                        });
            });
        });
    }

    private String displayName(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) {
                    String name = cursor.getString(index);
                    if (name != null && !name.isEmpty()) return name;
                }
            }
        } catch (Exception ignored) {
        }
        String segment = uri.getLastPathSegment();
        if (segment == null || segment.isEmpty()) {
            return "upload_" + System.currentTimeMillis();
        }
        return DeploySupport.fileName(segment);
    }

    private File copyToCache(Uri uri, String name) throws Exception {
        File out = new File(getCacheDir(), "deploy_up_" + System.nanoTime() + "_"
                + name.replaceAll("[^A-Za-z0-9._-]", "_"));
        try (InputStream in = "file".equals(uri.getScheme())
                ? new java.io.FileInputStream(new File(uri.getPath()))
                : getContentResolver().openInputStream(uri);
             FileOutputStream os = new FileOutputStream(out)) {
            if (in == null) throw new Exception("无法读取文件");
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) > 0) {
                os.write(buffer, 0, read);
            }
        }
        return out;
    }

    private static String mimeOf(String name) {
        String mime = URLConnection.guessContentTypeFromName(name == null ? "" : name);
        return mime == null ? "application/octet-stream" : mime;
    }
}
