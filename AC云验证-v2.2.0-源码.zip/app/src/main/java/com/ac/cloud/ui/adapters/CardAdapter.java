package com.ac.cloud.ui.adapters;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ac.cloud.R;
import com.ac.cloud.databinding.ItemCardBinding;
import com.ac.cloud.util.UiUtils;

import org.json.JSONArray;
import org.json.JSONObject;

public class CardAdapter extends RecyclerView.Adapter<CardAdapter.VH> {

    public interface Listener {
        void onCopy(JSONObject card);

        void onOpen(JSONObject card);
    }

    private JSONArray items = new JSONArray();
    private final Listener listener;

    public CardAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submit(JSONArray array) {
        items = array == null ? new JSONArray() : array;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(ItemCardBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        JSONObject item = items.optJSONObject(position);
        if (item == null) return;
        String cp = item.optString("card_password", "");
        holder.b.tvCardPassword.setText(cp);

        boolean device = "device".equals(item.optString("type"));
        holder.b.tvType.setText(device ? "设备卡" : "普通卡");
        holder.b.tvType.setBackgroundResource(device
                ? R.drawable.bg_chip_purple : R.drawable.bg_chip_info);
        holder.b.tvType.setTextColor(holder.b.getRoot().getContext().getColor(device
                ? R.color.chip_purple_fg : R.color.chip_info_fg));

        boolean used = item.optBoolean("used");
        holder.b.tvState.setText(used ? "已使用" : "未使用");
        holder.b.tvState.setBackgroundResource(used
                ? R.drawable.bg_chip_warn : R.drawable.bg_chip_success);
        holder.b.tvState.setTextColor(holder.b.getRoot().getContext().getColor(used
                ? R.color.chip_warn_fg : R.color.chip_success_fg));

        holder.b.tvInstance.setText(item.optString("instance_id", ""));
        int days = item.optInt("valid_days", 0);
        holder.b.tvValid.setText(days == 0 ? "永久有效" : days + " 天");

        JSONArray bind = item.optJSONArray("bind_devices");
        int bound = bind == null ? 0 : bind.length();
        int max = item.optInt("max_devices", 1);
        holder.b.tvDevices.setText(device ? bound + " / " + max + " 台设备" : "单设备");

        holder.b.btnCopy.setOnClickListener(v -> listener.onCopy(item));
        holder.b.btnMore.setOnClickListener(v -> listener.onOpen(item));
        holder.b.getRoot().setOnClickListener(v -> listener.onOpen(item));
    }

    @Override
    public int getItemCount() {
        return items.length();
    }

    static class VH extends RecyclerView.ViewHolder {
        final ItemCardBinding b;

        VH(ItemCardBinding binding) {
            super(binding.getRoot());
            b = binding;
        }
    }
}
