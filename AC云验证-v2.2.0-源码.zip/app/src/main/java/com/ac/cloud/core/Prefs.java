package com.ac.cloud.core;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {

    private static SharedPreferences sp;

    private Prefs() {
    }

    public static void init(Context ctx) {
        sp = ctx.getSharedPreferences("ac_cloud", Context.MODE_PRIVATE);
    }

    public static String getString(String key, String def) {
        return sp.getString(key, def);
    }

    public static void putString(String key, String value) {
        sp.edit().putString(key, value).apply();
    }

    public static boolean getBool(String key, boolean def) {
        return sp.getBoolean(key, def);
    }

    public static void putBool(String key, boolean value) {
        sp.edit().putBoolean(key, value).apply();
    }

    public static int getInt(String key, int def) {
        return sp.getInt(key, def);
    }

    public static void putInt(String key, int value) {
        sp.edit().putInt(key, value).apply();
    }

    public static void remove(String key) {
        sp.edit().remove(key).apply();
    }

    public static void clearSession() {
        sp.edit().remove("cookie").remove("user_json").remove("api_key").remove("logged_in").apply();
    }
}
