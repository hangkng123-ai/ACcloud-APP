package com.ac.cloud.core;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.ac.cloud.BuildConfig;
import com.ac.cloud.R;
import com.ac.cloud.databinding.DialogServerSelectBinding;

/**
 * 服务器节点管理：欧洲节点 / 主节点。
 * 节点基址保存在 Prefs，HTTP 与 C++ TCP 预热均使用当前节点。
 */
public final class Servers {

    public static final String KEY_EUROPE = "europe";
    public static final String KEY_MAIN = "main";

    public static final String EUROPE = "https://xn--dkwo7b.xn--ac-c72cw32v8pp.eu.org";
    public static final String MAIN = "https://xn--ac-c72cw32v8pp.eu.org";

    private Servers() {
    }

    public static String key() {
        String saved = Prefs.getString("server_key", "");
        if (KEY_EUROPE.equals(saved) || KEY_MAIN.equals(saved)) return saved;
        // 首次运行使用构建时注入的默认节点
        String def = BuildConfig.API_BASE == null ? "" : BuildConfig.API_BASE;
        return def.contains("dkwo7b") ? KEY_EUROPE : KEY_MAIN;
    }

    public static String base() {
        if (customBuild()) return BuildConfig.API_BASE;
        return KEY_MAIN.equals(key()) ? MAIN : EUROPE;
    }

    /** 本地联调 / 自建服务器基址直接生效，不走双节点。 */
    private static boolean customBuild() {
        String b = BuildConfig.API_BASE;
        return b != null && (b.startsWith("http://") || b.contains("10.0.2.2")
                || b.contains("192.168."));
    }

    public static String name() {
        return KEY_MAIN.equals(key()) ? "主服务器" : "欧洲服务器";
    }

    public static String host() {
        String b = base();
        int start = b.indexOf("://");
        return start < 0 ? b : b.substring(start + 3);
    }

    public static boolean chosen() {
        String saved = Prefs.getString("server_key", "");
        return KEY_EUROPE.equals(saved) || KEY_MAIN.equals(saved);
    }

    public static void set(String key) {
        Prefs.putString("server_key", key);
        // 切换节点后必须重新登录，避免跨节点会话串号
        Prefs.clearSession();
    }

    /** 应用启动时调用：未选择节点则强制弹窗，选择完成回调。 */
    public static void ensure(Activity activity, Runnable after) {
        if (customBuild() || chosen()) {
            if (after != null) after.run();
            return;
        }
        show(activity, true, after);
    }

    public static void show(Activity activity, boolean firstRun, Runnable after) {
        if (activity == null || activity.isFinishing()) return;
        Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        DialogServerSelectBinding binding = DialogServerSelectBinding.inflate(
                activity.getLayoutInflater());
        dialog.setContentView(binding.getRoot());
        dialog.setCancelable(!firstRun);

        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.dimAmount = 0.42f;
            window.setAttributes(lp);
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT);
            android.view.WindowManager.LayoutParams wlp = window.getAttributes();
            wlp.width = (int) (activity.getResources().getDisplayMetrics().widthPixels * 0.92f);
            window.setAttributes(wlp);
        }

        final String[] selected = {key()};
        Runnable render = () -> {
            boolean eu = KEY_EUROPE.equals(selected[0]);
            binding.checkEurope.setVisibility(eu ? View.VISIBLE : View.GONE);
            binding.checkMain.setVisibility(eu ? View.GONE : View.VISIBLE);
            binding.rowEurope.setAlpha(eu ? 1f : 0.88f);
            binding.rowMain.setAlpha(eu ? 0.88f : 1f);
        };
        binding.rowEurope.setOnClickListener(v -> {
            selected[0] = KEY_EUROPE;
            render.run();
        });
        binding.rowMain.setOnClickListener(v -> {
            selected[0] = KEY_MAIN;
            render.run();
        });
        binding.btnServerConfirm.setText(firstRun ? "进入应用" : "保存并切换");
        binding.btnServerConfirm.setOnClickListener(v -> {
            set(selected[0]);
            dialog.dismiss();
            if (after != null) new Handler(Looper.getMainLooper()).post(after);
        });
        render.run();
        dialog.show();
    }
}
