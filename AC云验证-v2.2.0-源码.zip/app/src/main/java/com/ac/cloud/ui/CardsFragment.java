package com.ac.cloud.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ac.cloud.R;
import com.ac.cloud.core.DataCache;
import com.ac.cloud.core.Json;
import com.ac.cloud.databinding.FragmentCardsBinding;
import com.ac.cloud.net.Calls;
import com.ac.cloud.ui.adapters.CardAdapter;
import com.ac.cloud.util.UiUtils;

import org.json.JSONArray;
import org.json.JSONObject;

public class CardsFragment extends Fragment implements CardAdapter.Listener, CacheAware {

    private FragmentCardsBinding b;
    private CardAdapter adapter;
    private JSONArray allCards = new JSONArray();
    private JSONArray instances = new JSONArray();
    private int filter = 0;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        b = FragmentCardsBinding.inflate(inflater, container, false);
        return b.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        adapter = new CardAdapter(this);
        b.recycler.setLayoutManager(new LinearLayoutManager(requireContext()));
        b.recycler.setAdapter(adapter);
        b.swipe.setOnRefreshListener(this::load);

        b.chipGroup.setOnCheckedStateChangeListener((group, checkedIds) -> {
            if (checkedIds.isEmpty()) return;
            int id = checkedIds.get(0);
            if (id == R.id.chipUnused) filter = 1;
            else if (id == R.id.chipUsed) filter = 2;
            else if (id == R.id.chipDevice) filter = 3;
            else filter = 0;
            applyFilter();
        });

        b.btnGenerate.setOnClickListener(v -> {
            if (instances.length() == 0) {
                UiUtils.toast("请先创建应用实例");
                return;
            }
            new CreateCardSheet(instances, this::load).show(getParentFragmentManager(), "create_card");
        });
        UiUtils.bindMenu(view, this);
        if (DataCache.hasCore()) onCacheReady(); else load();
    }

    private void load() {
        Calls.get("/api/cards", cardJson -> Calls.get("/api/instances", instJson -> {
            if (!isAdded()) return;
            b.swipe.setRefreshing(false);
            DataCache.update("cards", cardJson);
            DataCache.update("instances", instJson);
            allCards = Json.array(cardJson, "cards");
            instances = Json.array(instJson, "instances");
            b.tvSubtitle.setText(allCards.length() == 0
                    ? "生成并管理你的卡密" : "共 " + allCards.length() + " 张卡密");
            applyFilter();
        }));
    }

    private void applyFilter() {
        JSONArray filtered = new JSONArray();
        for (int i = 0; i < allCards.length(); i++) {
            JSONObject card = allCards.optJSONObject(i);
            if (card == null) continue;
            boolean used = card.optBoolean("used");
            boolean device = "device".equals(card.optString("type"));
            if (filter == 1 && used) continue;
            if (filter == 2 && !used) continue;
            if (filter == 3 && !device) continue;
            filtered.put(card);
        }
        adapter.submit(filtered);
        b.emptyView.setVisibility(filtered.length() == 0 ? View.VISIBLE : View.GONE);
        b.recycler.setVisibility(filtered.length() == 0 ? View.GONE : View.VISIBLE);
    }

    @Override
    public void onCopy(JSONObject card) {
        UiUtils.copy("卡密", card.optString("card_password"));
    }

    @Override
    public void onOpen(JSONObject card) {
        new CardDetailSheet(card, this::load).show(getParentFragmentManager(), "card_detail");
    }

    @Override
    public void onCacheReady() {
        if (!isAdded() || b == null) return;
        allCards = Json.array(DataCache.cards, "cards");
        instances = Json.array(DataCache.instances, "instances");
        b.tvSubtitle.setText(allCards.length() == 0
                ? "生成并管理你的卡密" : "共 " + allCards.length() + " 张卡密");
        applyFilter();
    }
}
