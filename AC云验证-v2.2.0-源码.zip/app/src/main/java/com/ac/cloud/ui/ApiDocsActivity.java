package com.ac.cloud.ui;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.ac.cloud.databinding.ActivityApiDocsBinding;
import com.ac.cloud.util.UiUtils;

/**
 * Fully native API reference. No WebView, no browser: every section is a
 * MaterialCardView rendered from the resources shipped with the app.
 */
public class ApiDocsActivity extends AppCompatActivity {

    private static final String SIGN_TEXT =
            "sign = md5(aes_key + secret_key + api_key + timestamp)\n\n"
                    + "· AES-256-CBC，密钥为 Base64 编码的 32 字节\n"
                    + "· 请求体 data / iv 均为 Base64 字符串\n"
                    + "· IV 每次加密随机生成 16 字节\n"
                    + "· 填充方式 PKCS7，timestamp 为秒级时间戳";

    private static final String VERIFY_PARAMS =
            "_instance_id   string   必填   实例 ID\n"
                    + "_uid           string   必填   用户 ID\n"
                    + "api_key        string   必填   API 对接码\n"
                    + "timestamp      long     必填   秒级时间戳\n"
                    + "sign           string   必填   MD5 签名\n"
                    + "data           string   必填   AES 密文（Base64）\n"
                    + "iv             string   必填   IV（Base64）\n\n"
                    + "data 明文：\n"
                    + "{\"card_password\":\"卡密\",\"device_id\":\"设备 ID\"}";

    private static final String VERIFY_RESULT =
            "{\n"
                    + "  \"data\": \"Base64 AES 密文\",\n"
                    + "  \"iv\": \"Base64 IV\",\n"
                    + "  \"timestamp\": 1704067200\n"
                    + "}\n\n解密后：\n"
                    + "{\n"
                    + "  \"code\": 1,\n"
                    + "  \"message\": \"验证成功\",\n"
                    + "  \"remaining_days\": 30,\n"
                    + "  \"device_count\": 1\n"
                    + "}";

    private static final String POLL_PARAMS =
            "_instance_id   string   必填   实例 ID\n"
                    + "_uid           string   必填   用户 ID\n"
                    + "api_key        string   必填   API 对接码\n"
                    + "timestamp      long     必填   秒级时间戳\n"
                    + "sign           string   必填   MD5 签名\n"
                    + "data           string   必填   AES 密文（Base64）\n"
                    + "iv             string   必填   IV（Base64）\n\n"
                    + "data 明文：{}\n"
                    + "（轮询请求可为空对象）";

    private static final String POLL_RESULT =
            "{\n"
                    + "  \"data\": \"Base64 AES 密文\",\n"
                    + "  \"iv\": \"Base64 IV\",\n"
                    + "  \"timestamp\": 1704067200\n"
                    + "}\n\n解密后：\n"
                    + "{\n"
                    + "  \"code\": 1,\n"
                    + "  \"message\": \"获取成功\",\n"
                    + "  \"variables\": [ ... ],\n"
                    + "  \"server_time\": 1704067200,\n"
                    + "  \"server_time_str\": \"2026-01-01 12:00:00\"\n"
                    + "}";

    private static final String ANNOUNCEMENT_PARAMS =
            "_instance_id   string   必填   实例 ID\n"
                    + "_uid           string   必填   用户 ID\n"
                    + "api_key        string   必填   API 对接码\n"
                    + "timestamp      long     必填   秒级时间戳\n"
                    + "sign           string   必填   MD5 签名\n"
                    + "data           string   必填   AES 密文（Base64）\n"
                    + "iv             string   必填   IV（Base64）\n\n"
                    + "data 明文：{\"lang\":\"zh\"}";

    private static final String ANNOUNCEMENT_RESULT =
            "{\n"
                    + "  \"data\": \"Base64 AES 密文\",\n"
                    + "  \"iv\": \"Base64 IV\",\n"
                    + "  \"timestamp\": 1704067200\n"
                    + "}\n\n解密后：\n"
                    + "{\n"
                    + "  \"code\": 1,\n"
                    + "  \"announcement\": \"公告内容\",\n"
                    + "  \"lang\": \"zh\"\n"
                    + "}";

    private static final String HEARTBEAT_PARAMS =
            "instance_id    string   必填   实例 ID\n"
                    + "card_password  string   必填   卡密\n"
                    + "device_id      string   选填   设备 ID（设备卡建议填写）\n"
                    + "api_key        string   必填   API 对接码\n"
                    + "extra_data     object   选填   自定义附加数据\n\n"
                    + "说明：此接口为明文 JSON，不需要签名。";

    private static final String HEARTBEAT_RESULT =
            "{\n"
                    + "  \"code\": 1,\n"
                    + "  \"message\": \"心跳成功\",\n"
                    + "  \"online_count\": 12,\n"
                    + "  \"offline_count\": 3,\n"
                    + "  \"total_users\": 15,\n"
                    + "  \"heartbeat_time\": \"2026-01-01 12:00:00\"\n"
                    + "}";

    private static final String STATUS_PARAMS =
            "instance_id   string   必填   实例 ID\n"
                    + "api_key       string   必填   API 对接码\n\n"
                    + "说明：明文 JSON，不需要签名与解密。";

    private static final String STATUS_RESULT =
            "{\n"
                    + "  \"code\": 1,\n"
                    + "  \"instance_id\": \"实例 ID\",\n"
                    + "  \"online_count\": 12,\n"
                    + "  \"offline_count\": 3,\n"
                    + "  \"total_users\": 15,\n"
                    + "  \"users\": [{\n"
                    + "    \"card_password\": \"卡密\",\n"
                    + "    \"device_id\": \"设备 ID\",\n"
                    + "    \"status\": \"online\",\n"
                    + "    \"last_heartbeat\": \"2026-01-01 12:00:00\",\n"
                    + "    \"duration_str\": \"2 小时 15 分\",\n"
                    + "    \"extra_data\": {}\n"
                    + "  }],\n"
                    + "  \"timestamp\": \"2026-01-01 12:00:00\"\n"
                    + "}";

    private ActivityApiDocsBinding b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiUtils.edgeToEdge(this);
        b = ActivityApiDocsBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        UiUtils.applyInsets(b.getRoot());

        b.header.tvTitle.setText("API 文档");
        b.header.tvSubtitle.setText("签名算法与核心接口 · 原生渲染");
        b.header.btnBack.setOnClickListener(v -> finish());

        b.tvSignCode.setText(SIGN_TEXT);
        b.tvParamsVerify.setText(VERIFY_PARAMS);
        b.tvResultVerify.setText(VERIFY_RESULT);
        b.tvParamsPoll.setText(POLL_PARAMS);
        b.tvResultPoll.setText(POLL_RESULT);
        b.tvParamsAnnouncement.setText(ANNOUNCEMENT_PARAMS);
        b.tvResultAnnouncement.setText(ANNOUNCEMENT_RESULT);
        b.tvParamsHeartbeat.setText(HEARTBEAT_PARAMS);
        b.tvResultHeartbeat.setText(HEARTBEAT_RESULT);
        b.tvParamsStatus.setText(STATUS_PARAMS);
        b.tvResultStatus.setText(STATUS_RESULT);

        b.btnCopySign.setOnClickListener(v -> UiUtils.copy("签名算法", SIGN_TEXT));
        b.btnCopyVerify.setOnClickListener(v ->
                copySample("/api/verify", VERIFY_PARAMS, VERIFY_RESULT));
        b.btnCopyPoll.setOnClickListener(v ->
                copySample("/api/cloud_control/poll", POLL_PARAMS, POLL_RESULT));
        b.btnCopyAnnouncement.setOnClickListener(v ->
                copySample("/api/get_announcement", ANNOUNCEMENT_PARAMS, ANNOUNCEMENT_RESULT));
        b.btnCopyHeartbeat.setOnClickListener(v ->
                copySample("/api/online/heartbeat", HEARTBEAT_PARAMS, HEARTBEAT_RESULT));
        b.btnCopyStatus.setOnClickListener(v ->
                copySample("/api/online/status", STATUS_PARAMS, STATUS_RESULT));
    }

    private void copySample(String path, String params, String result) {
        UiUtils.copy("接口示例", path + "\n\n" + params + "\n\n" + result);
    }
}
