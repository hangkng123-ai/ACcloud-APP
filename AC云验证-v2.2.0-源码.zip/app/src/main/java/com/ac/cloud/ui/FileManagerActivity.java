package com.ac.cloud.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ac.cloud.R;
import com.ac.cloud.ui.adapters.FileAdapter;
import com.ac.cloud.util.UiUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * 自写内置文件管理器：浏览本地目录、单选 / 多选文件，用于应用内上传。
 */
public class FileManagerActivity extends AppCompatActivity {

    public static final String EXTRA_MULTI = "multi";
    public static final String EXTRA_FOLDER = "folder";
    public static final String EXTRA_TITLE = "title";
    public static final String RESULT_PATHS = "paths";
    public static final String RESULT_RELATIVES = "relatives";

    private RecyclerView recycler;
    private TextView tvPath;
    private TextView tvSelected;
    private TextView tvEmpty;
    private FileAdapter adapter;
    private final List<File> items = new ArrayList<>();
    private boolean multi;
    private boolean folderMode;
    private File current;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiUtils.edgeToEdge(this);
        setContentView(R.layout.activity_file_manager);
        UiUtils.applyInsets(findViewById(R.id.rootFiles));

        multi = getIntent().getBooleanExtra(EXTRA_MULTI, false);
        folderMode = getIntent().getBooleanExtra(EXTRA_FOLDER, false);
        multi = multi && !folderMode;
        String title = getIntent().getStringExtra(EXTRA_TITLE);
        TextView tvTitle = findViewById(R.id.tvTitle);
        TextView tvSubtitle = findViewById(R.id.tvSubtitle);
        tvTitle.setText(title == null || title.isEmpty() ? "文件管理" : title);
        tvSubtitle.setText(folderMode ? "进入目标文件夹后点击下方按钮上传整个文件夹"
                : multi ? "多选模式 · 点击文件选择" : "选择要上传的文件");
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        if (folderMode) {
            TextView pick = findViewById(R.id.btnPickFolder);
            pick.setVisibility(View.VISIBLE);
            pick.setOnClickListener(v -> finishFolderSelection());
        }

        tvPath = findViewById(R.id.tvPath);
        tvSelected = findViewById(R.id.tvSelected);
        tvEmpty = findViewById(R.id.tvFileEmpty);
        recycler = findViewById(R.id.recyclerFiles);
        recycler.setLayoutManager(new LinearLayoutManager(this));

        findViewById(R.id.btnUp).setOnClickListener(v -> goUp());
        findViewById(R.id.chipRoot).setOnClickListener(v -> open(
                Environment.getExternalStorageDirectory()));
        findViewById(R.id.chipDownload).setOnClickListener(v -> open(
                new File(Environment.getExternalStorageDirectory(), "Download")));
        findViewById(R.id.chipPictures).setOnClickListener(v -> open(
                new File(Environment.getExternalStorageDirectory(), "Pictures")));
        findViewById(R.id.chipDocuments).setOnClickListener(v -> open(
                new File(Environment.getExternalStorageDirectory(), "Documents")));

        if (multi) {
            View action = findViewById(R.id.btnAction);
            action.setVisibility(View.VISIBLE);
            action.setOnClickListener(v -> finishSelection());
        }

        requestAccessIfNeeded();
        open(Environment.getExternalStorageDirectory());
    }

    private void requestAccessIfNeeded() {
        if (Build.VERSION.SDK_INT >= 30) {
            if (!Environment.isExternalStorageManager()) {
                UiUtils.toast("请授予「所有文件访问」权限以浏览文件");
                try {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                }
            }
        } else if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 42);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 42) refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (current != null) refresh();
    }

    private void open(File dir) {
        if (dir == null) return;
        if (!dir.exists()) {
            UiUtils.toast("目录不存在");
            return;
        }
        if (!dir.isDirectory()) return;
        current = dir;
        refresh();
    }

    private void goUp() {
        if (current == null) return;
        File parent = current.getParentFile();
        if (parent != null) {
            current = parent;
            refresh();
        }
    }

    private void refresh() {
        if (current == null) return;
        tvPath.setText(current.getAbsolutePath());
        File[] files = current.listFiles();
        items.clear();
        if (files != null) {
            for (File f : files) {
                if (f.getName().startsWith(".")) continue;
                items.add(f);
            }
        }
        Collections.sort(items, (a, b) -> {
            if (a.isDirectory() != b.isDirectory()) return a.isDirectory() ? -1 : 1;
            return a.getName().compareToIgnoreCase(b.getName());
        });
        adapter = new FileAdapter(items, multi, this::onFile);
        recycler.setAdapter(adapter);
        tvEmpty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
        tvSelected.setText(multi ? "已选 0" : "");
    }

    private void onFile(File file) {
        if (file.isDirectory()) {
            open(file);
            return;
        }
        if (!multi) {
            ArrayList<String> paths = new ArrayList<>();
            paths.add(file.getAbsolutePath());
            Intent data = new Intent();
            data.putStringArrayListExtra(RESULT_PATHS, paths);
            setResult(RESULT_OK, data);
            finish();
            return;
        }
        String path = file.getAbsolutePath();
        if (adapter.selected().contains(path)) {
            adapter.selected().remove(path);
        } else {
            adapter.selected().add(path);
        }
        adapter.notifyDataSetChanged();
        tvSelected.setText("已选 " + adapter.selectedCount());
    }

    private void finishSelection() {
        if (adapter == null || adapter.selectedCount() == 0) {
            UiUtils.toast("请先选择文件");
            return;
        }
        ArrayList<String> paths = new ArrayList<>(adapter.selected());
        Intent data = new Intent();
        data.putStringArrayListExtra(RESULT_PATHS, paths);
        setResult(RESULT_OK, data);
        finish();
    }

    /** 递归收集当前目录下所有文件，返回相对路径（含文件夹名）。 */
    private void finishFolderSelection() {
        if (current == null || !current.isDirectory()) {
            UiUtils.toast("请先进入一个文件夹");
            return;
        }
        String base = current.getAbsolutePath();
        String rootName = current.getName();
        ArrayList<String> paths = new ArrayList<>();
        ArrayList<String> relatives = new ArrayList<>();
        collect(current, base, rootName, paths, relatives);
        if (paths.isEmpty()) {
            UiUtils.toast("该文件夹为空");
            return;
        }
        Intent data = new Intent();
        data.putStringArrayListExtra(RESULT_PATHS, paths);
        data.putStringArrayListExtra(RESULT_RELATIVES, relatives);
        setResult(RESULT_OK, data);
        finish();
    }

    private void collect(File dir, String base, String rootName,
                         List<String> paths, List<String> relatives) {
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.isHidden()) continue;
            if (f.isDirectory()) {
                collect(f, base, rootName, paths, relatives);
            } else {
                String abs = f.getAbsolutePath();
                String rel = abs.startsWith(base) ? abs.substring(base.length()) : f.getName();
                if (rel.startsWith("/")) rel = rel.substring(1);
                paths.add(abs);
                relatives.add(rootName + "/" + rel);
            }
        }
    }
}
