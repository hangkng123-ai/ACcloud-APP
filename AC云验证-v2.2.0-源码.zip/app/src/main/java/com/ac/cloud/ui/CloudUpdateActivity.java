package com.ac.cloud.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.ac.cloud.R;
import com.ac.cloud.core.DataCache;
import com.ac.cloud.core.Json;
import com.ac.cloud.core.Prefs;
import com.ac.cloud.databinding.ActivityCloudUpdateBinding;
import com.ac.cloud.databinding.ItemUpdateFileBinding;
import com.ac.cloud.net.Calls;
import com.ac.cloud.net.Io;
import com.ac.cloud.util.DownloadUtil;
import com.ac.cloud.util.UiUtils;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class CloudUpdateActivity extends AppCompatActivity {

    private ActivityCloudUpdateBinding b;
    private final List<String> ids = new ArrayList<>();
    private final List<String> labels = new ArrayList<>();
    private String selectedId = "";
    private File pickedFile;

    private final ActivityResultLauncher<Intent> picker = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() != RESULT_OK || result.getData() == null) return;
                ArrayList<String> paths = result.getData()
                        .getStringArrayListExtra(FileManagerActivity.RESULT_PATHS);
                if (paths == null || paths.isEmpty()) return;
                pickedFile = new File(paths.get(0));
                b.tvPickFile.setText(pickedFile.getName() + " · "
                        + String.format(java.util.Locale.US, "%.2f MB",
                        pickedFile.length() / 1024f / 1024f));
            });

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiUtils.edgeToEdge(this);
        b = ActivityCloudUpdateBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        UiUtils.applyInsets(b.getRoot());

        b.header.tvTitle.setText("云更新");
        b.header.tvSubtitle.setText("上传热更新包 · 版本与下载管理");
        b.header.btnBack.setOnClickListener(v -> finish());
        b.header.btnAction.setVisibility(View.VISIBLE);
        b.header.ivAction.setImageResource(R.drawable.ic_refresh);
        b.header.btnAction.setOnClickListener(v -> loadFiles());

        b.dropdownInstance.setOnItemClickListener((parent, view, position, id) -> {
            if (position < ids.size()) {
                selectedId = ids.get(position);
                Prefs.putString("selected_instance", selectedId);
                loadFiles();
            }
        });
        b.btnPickFile.setOnClickListener(v -> picker.launch(new Intent(this,
                FileManagerActivity.class).putExtra(FileManagerActivity.EXTRA_TITLE, "选择更新包")));
        b.btnUpload.setOnClickListener(v -> upload());

        applyInstances(Json.array(DataCache.instances, "instances"));
        if (ids.isEmpty()) loadInstances();
    }

    private void loadInstances() {
        Calls.get("/api/instances", json -> {
            if (isFinishing() || isDestroyed()) return;
            DataCache.update("instances", json);
            applyInstances(Json.array(json, "instances"));
        });
    }

    private void applyInstances(JSONArray arr) {
        if (arr == null || arr.length() == 0) return;
        ids.clear();
        labels.clear();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject item = arr.optJSONObject(i);
            if (item == null) continue;
            ids.add(item.optString("instance_id"));
            labels.add(item.optString("name", "") + "  ·  " + item.optString("instance_id"));
        }
        b.dropdownInstance.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, labels));
        String preferred = Prefs.getString("selected_instance", "");
        int index = ids.indexOf(preferred);
        if (index < 0 && !ids.isEmpty()) index = 0;
        if (index < 0) return;
        selectedId = ids.get(index);
        b.dropdownInstance.setText(labels.get(index), false);
        loadFiles();
    }

    private void loadFiles() {
        if (selectedId.isEmpty()) {
            b.containerFiles.removeAllViews();
            b.tvHistoryEmpty.setText("请选择应用查看已上传文件");
            b.tvHistoryEmpty.setVisibility(View.VISIBLE);
            b.tvHistoryCount.setText("0 个版本");
            return;
        }
        b.tvHistoryEmpty.setText("加载中…");
        b.tvHistoryEmpty.setVisibility(View.VISIBLE);
        Calls.get("/api/update/files/" + DeploySupport.enc(selectedId), json -> {
            if (isFinishing() || isDestroyed()) return;
            b.containerFiles.removeAllViews();
            if (!Json.ok(json)) {
                b.tvHistoryCount.setText("0 个版本");
                b.tvHistoryEmpty.setText("加载失败：" + Json.message(json));
                b.tvHistoryEmpty.setVisibility(View.VISIBLE);
                return;
            }
            JSONArray files = Json.array(json, "files");
            if (files == null) files = new JSONArray();
            for (int i = 0; i < files.length(); i++) {
                JSONObject node = files.optJSONObject(i);
                if (node != null) addFileRow(node);
            }
            b.tvHistoryCount.setText(files.length() + " 个版本");
            b.tvHistoryEmpty.setText("还没有上传过更新包");
            b.tvHistoryEmpty.setVisibility(files.length() == 0 ? View.VISIBLE : View.GONE);
        });
    }

    private void addFileRow(JSONObject node) {
        ItemUpdateFileBinding row = ItemUpdateFileBinding.inflate(getLayoutInflater(),
                b.containerFiles, false);
        String version = node.optString("version", "");
        row.tvVersion.setText("v" + version);
        row.tvName.setText(node.optString("display_name",
                node.optString("file_name", "更新包")));
        String size = node.optString("size_mb", "");
        row.tvMeta.setText((size.isEmpty() ? "" : size + " MB")
                + (node.optString("update_desc", "").isEmpty() ? ""
                : " · " + node.optString("update_desc")));
        boolean current = node.optBoolean("is_current", false);
        row.tvCurrent.setVisibility(current ? View.VISIBLE : View.GONE);

        row.btnSetCurrent.setOnClickListener(v -> setCurrent(version));
        row.btnDownload.setOnClickListener(v -> download(version));
        row.btnDelete.setOnClickListener(v -> confirmDelete(version));
        b.containerFiles.addView(row.getRoot());
    }

    private void upload() {
        if (selectedId.isEmpty()) {
            UiUtils.toast("请选择应用");
            return;
        }
        String version = text(b.etVersion);
        if (version.isEmpty()) {
            UiUtils.toast("请输入版本号");
            return;
        }
        if (pickedFile == null || !pickedFile.exists()) {
            UiUtils.toast("请选择要上传的文件");
            return;
        }
        if (pickedFile.length() > 200L * 1024 * 1024) {
            UiUtils.toast("文件超过 200MB 限制");
            return;
        }
        String display = text(b.etDisplayName);
        String desc = text(b.etDesc);
        b.progress.setVisibility(View.VISIBLE);
        b.progress.setProgress(0);
        b.btnUpload.setEnabled(false);
        b.btnUpload.setText("上传中…");

        File cached;
        try {
            cached = copyToCache(pickedFile);
        } catch (Exception e) {
            resetUpload("读取文件失败");
            return;
        }
        JSONObject fields = new JSONObject();
        try {
            fields.put("instance_id", selectedId);
            fields.put("version", version);
            fields.put("display_name", display.isEmpty() ? pickedFile.getName() : display);
            fields.put("update_desc", desc);
        } catch (Exception ignored) {
        }
        com.ac.cloud.service.ApiService.uploadProgress = (written, total) -> {
            int pct = total <= 0 ? 0 : (int) (written * 100 / total);
            Io.main(() -> b.progress.setProgress(pct));
        };
        Calls.upload("/api/updates/upload", fields.toString(), cached.getAbsolutePath(),
                "file", pickedFile.getName(), "application/octet-stream", json -> {
                    com.ac.cloud.service.ApiService.uploadProgress = null;
                    cached.delete();
                    if (isFinishing()) return;
                    resetUpload(null);
                    if (Json.ok(json)) {
                        UiUtils.toast("上传完成");
                        b.etVersion.setText("");
                        b.etDisplayName.setText("");
                        b.etDesc.setText("");
                        pickedFile = null;
                        b.tvPickFile.setText("选择要上传的文件");
                        loadFiles();
                    } else {
                        UiUtils.toast(Json.message(json));
                    }
                });
    }

    private void resetUpload(String message) {
        b.progress.setVisibility(View.GONE);
        b.btnUpload.setEnabled(true);
        b.btnUpload.setText("上传更新");
        if (message != null) UiUtils.toast(message);
    }

    private void setCurrent(String version) {
        try {
            JSONObject body = new JSONObject();
            body.put("instance_id", selectedId);
            body.put("version", version);
            Calls.post("/api/update/set_current", body.toString(), json -> {
                if (isFinishing()) return;
                UiUtils.toast(Json.ok(json) ? "已设为当前版本" : Json.message(json));
                if (Json.ok(json)) loadFiles();
            });
        } catch (Exception ignored) {
        }
    }

    private void download(String version) {
        Calls.get("/api/update/download_url?instance_id="
                + DeploySupport.enc(selectedId) + "&version=" + DeploySupport.enc(version), json -> {
            if (isFinishing()) return;
            if (!Json.ok(json)) {
                UiUtils.toast(Json.message(json));
                return;
            }
            String url = json.optString("url", "");
            if (url.isEmpty()) {
                UiUtils.toast("获取下载链接失败");
                return;
            }
            DownloadUtil.download(this, url, "ac_update_" + version + ".bin");
        });
    }

    private void confirmDelete(String version) {
        new MaterialAlertDialogBuilder(this)
                .setTitle("删除版本")
                .setMessage("确定删除 v" + version + " 吗？")
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", (d, w) -> {
                    try {
                        JSONObject body = new JSONObject();
                        body.put("instance_id", selectedId);
                        body.put("version", version);
                        Calls.post("/api/update/delete_version", body.toString(), json -> {
                            if (isFinishing()) return;
                            UiUtils.toast(Json.ok(json) ? "已删除" : Json.message(json));
                            if (Json.ok(json)) loadFiles();
                        });
                    } catch (Exception ignored) {
                    }
                })
                .show();
    }

    private File copyToCache(File source) throws Exception {
        File out = new File(getCacheDir(), "update_" + System.nanoTime() + "_" + source.getName());
        try (InputStream in = new java.io.FileInputStream(source);
             FileOutputStream os = new FileOutputStream(out)) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) > 0) {
                os.write(buffer, 0, read);
            }
        }
        return out;
    }

    private String text(android.widget.EditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }
}
