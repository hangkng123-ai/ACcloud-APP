package com.ac.cloud.core;

/**
 * C++ core exposed through JNI (AES-256-CBC, signature & device fingerprint).
 */
public final class NativeCore {

    static {
        System.loadLibrary("accloud");
    }

    private NativeCore() {
    }

    public static native String md5(String text);

    public static native String sign(String aesKey, String secretKey, String apiKey, String timestamp);

    /**
     * @return [0] = base64 ciphertext, [1] = base64 IV
     */
    public static native String[] aesEncrypt(String keyBase64, String plain);

    public static native String aesDecrypt(String keyBase64, String dataBase64, String ivBase64);

    public static native String fingerprint(String androidId);

    /** C++ TCP 握手探测，返回毫秒，失败为 -1。 */
    public static native int tcpProbe(String host, int port);

    /** C++ TCP 连接预热（DNS + 握手下沉到 native），返回毫秒，失败为 -1。 */
    public static native int tcpWarm(String host, int port);

    public static native String version();
}
