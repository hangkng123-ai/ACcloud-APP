package com.ac.cloud.ui;

import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.ac.cloud.R;
import com.ac.cloud.core.Json;
import com.ac.cloud.databinding.ActivityCardDevicesBinding;
import com.ac.cloud.net.Calls;
import com.ac.cloud.util.UiUtils;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;

/**
 * Complete bound-device list for a device card, mirroring the web console.
 */
public class CardDevicesActivity extends AppCompatActivity {

    private ActivityCardDevicesBinding b;
    private String cp;
    private int bound;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiUtils.edgeToEdge(this);
        b = ActivityCardDevicesBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        UiUtils.applyInsets(b.getRoot());

        cp = getIntent().getStringExtra("card_password");
        b.header.tvTitle.setText("绑定设备");
        b.header.tvSubtitle.setText(cp == null ? "" : cp);
        b.header.btnBack.setOnClickListener(v -> finish());
        b.tvCard.setText(cp == null ? "" : cp);
        b.btnUnbindAll.setOnClickListener(v -> confirmUnbindAll());
        load();
    }

    private void load() {
        try {
            String encoded = URLEncoder.encode(cp == null ? "" : cp, "UTF-8");
            Calls.get("/api/cards/" + encoded + "/devices", json -> {
                if (json.optInt("code") != 1) {
                    UiUtils.toast(Json.message(json));
                    return;
                }
                JSONArray bind = Json.array(json, "bind_devices");
                JSONArray activated = Json.array(json, "activated_devices");
                bound = bind.length();
                int max = json.optInt("max_devices", 1);
                b.tvInfo.setText(bound + " / " + max + " 台设备 · 已使用 "
                        + json.optInt("used_count", bound) + " 次");
                render(bind, activated);
            });
        } catch (Exception ignored) {
        }
    }

    private void render(JSONArray bind, JSONArray activated) {
        b.containerDevices.removeAllViews();
        if (bind.length() == 0) {
            TextView empty = new TextView(this);
            empty.setText("暂无绑定设备");
            empty.setTextColor(getColor(R.color.on_surface_variant));
            empty.setTextSize(13);
            empty.setPadding(UiUtils.dp(this, 16), UiUtils.dp(this, 24),
                    UiUtils.dp(this, 16), UiUtils.dp(this, 24));
            b.containerDevices.addView(empty);
            b.btnUnbindAll.setEnabled(false);
            return;
        }
        b.btnUnbindAll.setEnabled(true);
        for (int i = 0; i < bind.length(); i++) {
            String device = bind.optString(i);
            boolean active = false;
            for (int j = 0; j < activated.length(); j++) {
                if (device.equals(activated.optString(j))) {
                    active = true;
                    break;
                }
            }
            addDeviceRow(i, device, active);
        }
    }

    private void addDeviceRow(int index, String device, boolean active) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(UiUtils.dp(this, 12), UiUtils.dp(this, 12),
                UiUtils.dp(this, 12), UiUtils.dp(this, 12));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView id = new TextView(this);
        id.setText(device);
        id.setTextSize(13);
        id.setTypeface(android.graphics.Typeface.create("monospace",
                android.graphics.Typeface.NORMAL));
        id.setTextColor(getColor(R.color.on_surface));
        col.addView(id);

        TextView meta = new TextView(this);
        meta.setText(active ? "已激活 · 设备卡" : "已绑定 · 未激活");
        meta.setTextSize(10);
        meta.setTextColor(getColor(active
                ? R.color.chip_success_fg : R.color.on_surface_variant));
        col.addView(meta);
        row.addView(col);

        TextView unbind = new TextView(this);
        unbind.setText("解绑");
        unbind.setTextSize(11);
        unbind.setTextColor(getColor(R.color.danger));
        unbind.setPadding(UiUtils.dp(this, 12), UiUtils.dp(this, 6),
                UiUtils.dp(this, 4), UiUtils.dp(this, 6));
        unbind.setOnClickListener(v -> unbind(device));
        row.addView(unbind);

        b.containerDevices.addView(row);
        android.view.View divider = new android.view.View(this);
        divider.setBackgroundResource(R.drawable.divider);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, UiUtils.dp(this, 1));
        p.leftMargin = UiUtils.dp(this, 12);
        divider.setLayoutParams(p);
        b.containerDevices.addView(divider);
    }

    private void unbind(String device) {
        try {
            JSONObject body = new JSONObject();
            body.put("card_password", cp);
            body.put("device_id", device);
            Calls.post("/api/cards/unbind_device", body.toString(), json -> {
                UiUtils.toast(Json.message(json));
                if (json.optInt("code") == 1) load();
            });
        } catch (Exception ignored) {
        }
    }

    private void confirmUnbindAll() {
        new MaterialAlertDialogBuilder(this)
                .setTitle("解绑全部设备")
                .setMessage("将清空这张卡密绑定的所有设备，确定继续？")
                .setNegativeButton("取消", null)
                .setPositiveButton("解绑全部", (d, w) -> {
                    try {
                        JSONObject body = new JSONObject();
                        body.put("card_password", cp);
                        body.put("unbind_all", true);
                        Calls.post("/api/cards/unbind_device", body.toString(), json -> {
                            UiUtils.toast(Json.message(json));
                            if (json.optInt("code") == 1) load();
                        });
                    } catch (Exception ignored) {
                    }
                }).show();
    }
}
