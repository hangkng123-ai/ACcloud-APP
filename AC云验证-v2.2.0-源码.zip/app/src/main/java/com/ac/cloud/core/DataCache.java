package com.ac.cloud.core;

import android.os.Handler;
import android.os.Looper;

import com.ac.cloud.net.Calls;

import org.json.JSONObject;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Single launch-time snapshot. All tabs render from this cache, so switching
 * pages never triggers another network round-trip.
 */
public final class DataCache {

    public static volatile JSONObject user = new JSONObject();
    public static volatile JSONObject instances = new JSONObject();
    public static volatile JSONObject cards = new JSONObject();
    public static volatile JSONObject announcement = new JSONObject();
    public static volatile JSONObject documents = new JSONObject();
    public static volatile long loadedAt = 0;

    private static final AtomicBoolean loading = new AtomicBoolean(false);

    private DataCache() {
    }

    public static boolean hasCore() {
        return loadedAt > 0;
    }

    public static boolean fresh() {
        return loadedAt > 0 && System.currentTimeMillis() - loadedAt < 120_000;
    }

    public static void preload(Runnable done) {
        if (!loading.compareAndSet(false, true)) {
            if (done != null) done.run();
            return;
        }
        final AtomicBoolean finished = new AtomicBoolean(false);
        final AtomicInteger left = new AtomicInteger(5);
        final Handler handler = new Handler(Looper.getMainLooper());
        final Runnable finish = () -> {
            if (finished.compareAndSet(false, true)) {
                loadedAt = System.currentTimeMillis();
                loading.set(false);
                if (done != null) done.run();
            }
        };
        final Runnable tick = () -> {
            if (left.decrementAndGet() <= 0) finish.run();
        };

        Calls.get("/api/user/info", j -> {
            user = j;
            if (j.optInt("code") == 1) {
                Prefs.putString("user_json", j.toString());
                Prefs.putString("api_key", j.optString("api_key"));
            }
            tick.run();
        });
        Calls.get("/api/instances", j -> {
            instances = j;
            tick.run();
        });
        Calls.get("/api/cards", j -> {
            cards = j;
            tick.run();
        });
        Calls.get("/api/get_announcement", j -> {
            announcement = j;
            tick.run();
        });
        Calls.get("/api/documents", j -> {
            documents = j;
            tick.run();
        });

        handler.postDelayed(finish, 8000);
    }

    public static void update(String kind, JSONObject value) {
        switch (kind) {
            case "instances":
                instances = value;
                break;
            case "cards":
                cards = value;
                break;
            case "documents":
                documents = value;
                break;
            case "announcement":
                announcement = value;
                break;
            default:
                break;
        }
        loadedAt = System.currentTimeMillis();
    }
}
