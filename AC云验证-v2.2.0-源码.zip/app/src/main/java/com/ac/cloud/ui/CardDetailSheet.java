package com.ac.cloud.ui;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.ac.cloud.R;
import com.ac.cloud.core.Json;
import com.ac.cloud.databinding.SheetCardDetailBinding;
import com.ac.cloud.net.Calls;
import com.ac.cloud.util.UiUtils;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.json.JSONArray;
import org.json.JSONObject;

public class CardDetailSheet extends BottomSheetDialogFragment {

    private JSONObject card = new JSONObject();
    private Runnable onChanged;
    private SheetCardDetailBinding b;
    private String cp;

    /** Fragment 重建时必须存在无参构造。 */
    public CardDetailSheet() {
    }

    public CardDetailSheet(JSONObject card, Runnable onChanged) {
        this.card = card == null ? new JSONObject() : card;
        this.onChanged = onChanged;
        Bundle args = new Bundle();
        args.putString("card_json", this.card.toString());
        setArguments(args);
    }

    private void restoreCard() {
        Bundle args = getArguments();
        if (args != null && args.getString("card_json") != null) {
            card = Json.parse(args.getString("card_json"));
        }
        if (card == null) card = new JSONObject();
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        BottomSheetDialog dialog = new BottomSheetDialog(requireContext(), R.style.Theme_AC_BottomSheet);
        return dialog;
    }

    @Override
    public void onStart() {
        super.onStart();
        UiUtils.applyGlassBlur(getDialog());
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        b = SheetCardDetailBinding.inflate(inflater, container, false);
        return b.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        UiUtils.applyBottomInset(view);
        restoreCard();
        cp = card.optString("card_password");
        boolean device = "device".equals(card.optString("type"));
        boolean used = card.optBoolean("used");
        int days = card.optInt("valid_days", 0);
        JSONArray bind = card.optJSONArray("bind_devices");
        int bound = bind == null ? 0 : bind.length();
        int max = card.optInt("max_devices", 1);

        b.tvCardPassword.setText(cp);
        b.tvType.setText(device ? "设备卡" : "普通卡");
        b.tvType.setBackgroundResource(device ? R.drawable.bg_chip_purple : R.drawable.bg_chip_info);
        b.tvType.setTextColor(requireContext().getColor(device
                ? R.color.chip_purple_fg : R.color.chip_info_fg));
        b.tvState.setText(used ? "已使用" : "未使用");
        b.tvState.setBackgroundResource(used ? R.drawable.bg_chip_warn : R.drawable.bg_chip_success);
        b.tvState.setTextColor(requireContext().getColor(used
                ? R.color.chip_warn_fg : R.color.chip_success_fg));
        b.btnCopy.setOnClickListener(v -> UiUtils.copy("卡密", cp));

        addRow("所属应用", card.optString("instance_id", "--"));
        addRow("有效期", days == 0 ? "永久有效" : days + " 天");
        addRow("创建时间", card.optString("create_time", "--"));
        addRow("使用状态", used ? "已使用" : "未使用");
        if (device) {
            addRow("绑定设备", bound + " / " + max + " 台");
            addRow("激活模式", card.optBoolean("activation_mode") ? "是（按设备激活）" : "否");
            b.tilMaxDevices.setVisibility(View.VISIBLE);
            b.btnSaveDevices.setVisibility(View.VISIBLE);
            b.btnUnbindAll.setVisibility(View.VISIBLE);
            b.btnDevices.setVisibility(View.VISIBLE);
            b.etMaxDevices.setText(String.valueOf(max));
            b.btnDevices.setOnClickListener(v -> {
                android.content.Intent intent = new android.content.Intent(
                        requireContext(), CardDevicesActivity.class);
                intent.putExtra("card_password", cp);
                startActivity(intent);
            });
        }

        b.btnExtend.setOnClickListener(v -> extend());
        b.btnSaveDevices.setOnClickListener(v -> saveDevices());
        b.btnUnbindAll.setOnClickListener(v -> confirmUnbind());
        b.btnDelete.setOnClickListener(v -> confirmDelete());
    }

    private void addRow(String label, String value) {
        LinearLayout row = new LinearLayout(requireContext());
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, UiUtils.dp(requireContext(), 7), 0, UiUtils.dp(requireContext(), 7));

        TextView left = new TextView(requireContext());
        left.setText(label);
        left.setTextSize(12);
        left.setTextColor(requireContext().getColor(R.color.on_surface_variant));
        left.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(left);

        TextView right = new TextView(requireContext());
        right.setText(value);
        right.setTextSize(12);
        right.setTextColor(requireContext().getColor(R.color.on_surface));
        right.setTypeface(android.graphics.Typeface.create("sans-serif-medium",
                android.graphics.Typeface.NORMAL));
        row.addView(right);

        b.containerDetails.addView(row);
    }

    private void extend() {
        int days;
        try {
            days = Integer.parseInt(b.etDays.getText() == null ? ""
                    : b.etDays.getText().toString().trim());
        } catch (Exception e) {
            UiUtils.toast("请输入天数");
            return;
        }
        if (days <= 0) {
            UiUtils.toast("天数需大于 0");
            return;
        }
        try {
            JSONObject body = new JSONObject();
            body.put("card_password", cp);
            body.put("add_days", days);
            Calls.post("/api/cards/extend", body.toString(), json -> handle(json, "已延长 " + days + " 天"));
        } catch (Exception ignored) {
        }
    }

    private void saveDevices() {
        int max;
        try {
            max = Integer.parseInt(b.etMaxDevices.getText() == null ? ""
                    : b.etMaxDevices.getText().toString().trim());
        } catch (Exception e) {
            UiUtils.toast("请输入设备数量");
            return;
        }
        try {
            JSONObject body = new JSONObject();
            body.put("card_password", cp);
            body.put("max_devices", max);
            Calls.post("/api/cards/update_max_devices", body.toString(),
                    json -> handle(json, "设备数量已更新"));
        } catch (Exception ignored) {
        }
    }

    private void confirmUnbind() {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("解绑全部设备")
                .setMessage("将清空该卡密绑定的所有设备，确定继续？")
                .setNegativeButton("取消", null)
                .setPositiveButton("解绑", (d, w) -> {
                    try {
                        JSONObject body = new JSONObject();
                        body.put("card_password", cp);
                        body.put("unbind_all", true);
                        Calls.post("/api/cards/unbind_device", body.toString(), json -> {
                            if (!isAdded()) return;
                            if (json.optInt("code") == 1) {
                                UiUtils.toast("已清空所有设备");
                                if (onChanged != null) onChanged.run();
                                dismiss();
                            } else {
                                UiUtils.toast(Json.message(json));
                            }
                        });
                    } catch (Exception ignored) {
                    }
                }).show();
    }

    private void confirmDelete() {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("删除卡密")
                .setMessage("确定删除卡密 " + cp + " 吗？此操作不可撤销。")
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", (d, w) -> {
                    try {
                        JSONObject body = new JSONObject();
                        JSONArray arr = new JSONArray();
                        arr.put(cp);
                        body.put("card_passwords", arr);
                        Calls.post("/api/cards/delete", body.toString(), json -> {
                            if (!isAdded()) return;
                            if (json.optInt("code") == 1) {
                                UiUtils.toast("卡密已删除");
                                if (onChanged != null) onChanged.run();
                                dismiss();
                            } else {
                                UiUtils.toast(Json.message(json));
                            }
                        });
                    } catch (Exception ignored) {
                    }
                }).show();
    }

    private void handle(JSONObject json, String success) {
        if (!isAdded()) return;
        if (json.optInt("code") == 1) {
            UiUtils.toast(success);
            if (onChanged != null) onChanged.run();
            dismiss();
        } else {
            UiUtils.toast(Json.message(json));
        }
    }
}
