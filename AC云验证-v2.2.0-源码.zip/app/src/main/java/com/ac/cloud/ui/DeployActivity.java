package com.ac.cloud.ui;

import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.ac.cloud.R;
import com.ac.cloud.util.UiUtils;
import com.google.android.material.tabs.TabLayout;

public class DeployActivity extends AppCompatActivity {

    private TabLayout tabLayout;
    private ServerDeployFragment serverFragment;
    private StaticDeployFragment staticFragment;
    private int current = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiUtils.edgeToEdge(this);
        setContentView(R.layout.activity_deploy);
        UiUtils.applyInsets(findViewById(R.id.rootDeploy));

        TextView title = findViewById(R.id.tvTitle);
        TextView subtitle = findViewById(R.id.tvSubtitle);
        title.setText("部署中心");
        subtitle.setText("服务器 / 网站部署 · 全原生");
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        tabLayout = findViewById(R.id.tabLayout);

        if (savedInstanceState != null) {
            Fragment restored = getSupportFragmentManager().findFragmentByTag("deploy_0");
            if (restored instanceof ServerDeployFragment) serverFragment = (ServerDeployFragment) restored;
            Fragment web = getSupportFragmentManager().findFragmentByTag("deploy_1");
            if (web instanceof StaticDeployFragment) staticFragment = (StaticDeployFragment) web;
            current = savedInstanceState.getInt("deploy_tab", 0);
        } else {
            current = getIntent().getIntExtra("tab", 0) == 1 ? 1 : 0;
        }
        if (serverFragment == null) serverFragment = new ServerDeployFragment();
        if (staticFragment == null) staticFragment = new StaticDeployFragment();

        tabLayout.addTab(tabLayout.newTab().setText("服务器部署"));
        tabLayout.addTab(tabLayout.newTab().setText("网站部署"));
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                select(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });

        select(current);
        tabLayout.post(() -> {
            TabLayout.Tab tab = tabLayout.getTabAt(current);
            if (tab != null) tab.select();
        });
    }

    private void select(int index) {
        Fragment show = index == 0 ? serverFragment : staticFragment;
        Fragment hide = index == 0 ? staticFragment : serverFragment;
        FragmentTransaction tx = getSupportFragmentManager().beginTransaction();
        if (!show.isAdded()) {
            tx.add(R.id.container, show, "deploy_" + index);
        } else {
            tx.show(show);
        }
        if (hide.isAdded()) tx.hide(hide);
        tx.commitAllowingStateLoss();
        current = index;
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putInt("deploy_tab", current);
        super.onSaveInstanceState(outState);
    }
}
