package com.ac.cloud.ui;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ac.cloud.R;
import com.ac.cloud.core.Json;
import com.ac.cloud.databinding.FragmentProjectsBinding;
import com.ac.cloud.net.Calls;
import com.ac.cloud.ui.adapters.ProjectAdapter;
import com.ac.cloud.util.UiUtils;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.json.JSONArray;
import org.json.JSONObject;

public class ServerDeployFragment extends Fragment implements ProjectAdapter.Listener {

    private FragmentProjectsBinding b;
    private ProjectAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        b = FragmentProjectsBinding.inflate(inflater, container, false);
        return b.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        adapter = new ProjectAdapter(true, this);
        b.recycler.setLayoutManager(new LinearLayoutManager(requireContext()));
        b.recycler.setAdapter(adapter);
        b.swipe.setOnRefreshListener(this::load);
        b.btnCreate.setOnClickListener(v -> createProject());
        b.tvEmptyTitle.setText("暂无服务器项目");
        b.tvEmptyDesc.setText("新建项目后上传 Python 文件即可部署");
        load();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!isHidden()) load();
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (!hidden) load();
    }

    private void load() {
        if (b == null) return;
        Calls.get("/api/user/deploy/projects", json -> {
            if (!isAdded()) return;
            b.swipe.setRefreshing(false);
            if (!Json.ok(json)) {
                UiUtils.toast(Json.message(json));
                return;
            }
            JSONArray arr = Json.array(json, "projects");
            adapter.submit(arr);
            boolean empty = arr.length() == 0;
            b.emptyView.setVisibility(empty ? View.VISIBLE : View.GONE);
            b.recycler.setVisibility(empty ? View.GONE : View.VISIBLE);
        });
    }

    private void createProject() {
        Context ctx = requireContext();
        EditText nameInput = DeploySupport.input(ctx, "如 my-bot", "", false);
        EditText subInput = DeploySupport.input(ctx, "可留空自动分配", "", false);
        LinearLayout box = DeploySupport.form(ctx);
        DeploySupport.addField(ctx, box, "项目名称", nameInput);
        DeploySupport.addField(ctx, box, "子域名（可选）", subInput);

        AlertDialog dialog = new MaterialAlertDialogBuilder(ctx)
                .setTitle("新建服务器项目")
                .setView(box)
                .setNegativeButton("取消", null)
                .setPositiveButton("创建", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(v -> {
                    String name = nameInput.getText().toString().trim();
                    String sub = subInput.getText().toString().trim();
                    if (name.isEmpty()) {
                        UiUtils.toast("请填写项目名称");
                        return;
                    }
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
                    try {
                        JSONObject body = new JSONObject();
                        body.put("name", name);
                        body.put("subdomain", sub);
                        Calls.post("/api/deploy/create", body.toString(), json -> {
                            if (!isAdded()) return;
                            if (Json.ok(json)) {
                                dialog.dismiss();
                                UiUtils.toast("项目已创建");
                                load();
                            } else {
                                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                                UiUtils.toast(Json.message(json));
                            }
                        });
                    } catch (Exception e) {
                        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                        UiUtils.toast("参数错误");
                    }
                }));
        dialog.show();
    }

    @Override
    public void onManage(JSONObject project) {
        Intent intent = new Intent(requireContext(), ServerProjectActivity.class);
        intent.putExtra("project_id", project.optString("project_id", ""));
        intent.putExtra("name", project.optString("name", ""));
        intent.putExtra("domain", project.optString("full_domain", ""));
        intent.putExtra("status", project.optString("status", ""));
        intent.putExtra("https_enabled", project.optBoolean("https_enabled", true));
        intent.putExtra("sensitive_guard", project.optBoolean("sensitive_guard", true));
        startActivity(intent);
    }

    @Override
    public void onLogs(JSONObject project) {
        String pid = project.optString("project_id", "");
        AlertDialog progress = DeploySupport.progress(requireContext(), "正在加载日志…");
        Calls.get("/api/deploy/logs?project_id=" + DeploySupport.enc(pid), json -> {
            progress.dismiss();
            if (!isAdded()) return;
            showLogDialog(project.optString("name", "项目") + " · 运行日志",
                    DeploySupport.logs(json), pid);
        });
    }

    private void showLogDialog(String title, String content, String pid) {
        Context ctx = requireContext();
        TextView tv = new TextView(ctx);
        tv.setText(content == null || content.isEmpty() ? "暂无日志" : content);
        tv.setTextSize(11);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextIsSelectable(true);
        tv.setTextColor(ctx.getColor(R.color.on_surface));
        int pad = UiUtils.dp(ctx, 16);
        tv.setPadding(pad, pad, pad, pad);
        ScrollView scroll = new ScrollView(ctx);
        scroll.addView(tv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        FrameLayout frame = new FrameLayout(ctx);
        frame.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        frame.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, UiUtils.dp(ctx, 380)));

        new MaterialAlertDialogBuilder(ctx)
                .setTitle(title)
                .setView(frame)
                .setNegativeButton("关闭", null)
                .setPositiveButton("清空日志", (d, w) -> clearLogs(pid))
                .show();
    }

    private void clearLogs(String pid) {
        try {
            JSONObject body = new JSONObject();
            body.put("project_id", pid);
            Calls.post("/api/deploy/logs/clear", body.toString(), json -> {
                if (!isAdded()) return;
                UiUtils.toast(Json.ok(json) ? "日志已清空" : Json.message(json));
            });
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onMore(JSONObject project) {
        String pid = project.optString("project_id", "");
        String domain = project.optString("full_domain", "");
        boolean https = project.optBoolean("https_enabled", true);
        boolean guard = project.optBoolean("sensitive_guard", true);
        String[] items = new String[]{
                https ? "关闭 HTTPS" : "开启 HTTPS",
                guard ? "关闭敏感防护" : "开启敏感防护",
                "复制域名",
                "删除项目"
        };
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle(project.optString("name", "项目"))
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        toggleHttps(pid, !https);
                    } else if (which == 1) {
                        toggleGuard(pid, !guard);
                    } else if (which == 2) {
                        if (domain.isEmpty()) {
                            UiUtils.toast("暂无域名");
                        } else {
                            UiUtils.copy("域名", domain);
                        }
                    } else {
                        confirmDelete(project);
                    }
                })
                .show();
    }

    private void toggleHttps(String pid, boolean enabled) {
        try {
            JSONObject body = new JSONObject();
            body.put("project_id", pid);
            body.put("https_enabled", enabled);
            Calls.post("/api/user/deploy/toggle_https", body.toString(), json -> {
                if (!isAdded()) return;
                UiUtils.toast(Json.ok(json) ? (enabled ? "HTTPS 已开启" : "HTTPS 已关闭")
                        : Json.message(json));
                load();
            });
        } catch (Exception ignored) {
        }
    }

    private void toggleGuard(String pid, boolean enabled) {
        try {
            JSONObject body = new JSONObject();
            body.put("project_id", pid);
            body.put("sensitive_guard", enabled);
            Calls.post("/api/user/deploy/toggle_sensitive_guard", body.toString(), json -> {
                if (!isAdded()) return;
                UiUtils.toast(Json.ok(json) ? (enabled ? "敏感防护已开启" : "敏感防护已关闭")
                        : Json.message(json));
                load();
            });
        } catch (Exception ignored) {
        }
    }

    private void confirmDelete(JSONObject project) {
        String pid = project.optString("project_id", "");
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("删除项目")
                .setMessage("确定删除「" + project.optString("name", "项目")
                        + "」吗？项目文件将被清除且无法恢复。")
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", (d, w) -> {
                    try {
                        JSONObject body = new JSONObject();
                        body.put("project_id", pid);
                        Calls.post("/api/deploy/project/delete", body.toString(), json -> {
                            if (!isAdded()) return;
                            UiUtils.toast(Json.ok(json) ? "项目已删除" : Json.message(json));
                            load();
                        });
                    } catch (Exception ignored) {
                    }
                })
                .show();
    }
}
