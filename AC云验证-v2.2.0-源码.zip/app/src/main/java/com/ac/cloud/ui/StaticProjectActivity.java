package com.ac.cloud.ui;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.ac.cloud.R;
import com.ac.cloud.core.Json;
import com.ac.cloud.databinding.ActivityStaticProjectBinding;
import com.ac.cloud.databinding.ItemDeployFileBinding;
import com.ac.cloud.net.Calls;
import com.ac.cloud.net.Io;
import com.ac.cloud.util.UiUtils;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TreeMap;

public class StaticProjectActivity extends AppCompatActivity {

    private ActivityStaticProjectBinding b;
    private String projectId = "";
    private String projectName = "";
    private String projectDomain = "";
    private String mainFile = "";
    private boolean httpsEnabled = true;
    private String currentFolder = "";
    private JSONArray allFiles = new JSONArray();

    private final ActivityResultLauncher<Intent> picker = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() != RESULT_OK || result.getData() == null) return;
                onPickedPaths(result.getData()
                        .getStringArrayListExtra(FileManagerActivity.RESULT_PATHS),
                        result.getData()
                                .getStringArrayListExtra(FileManagerActivity.RESULT_RELATIVES));
            });

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiUtils.edgeToEdge(this);
        b = ActivityStaticProjectBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        UiUtils.applyInsets(b.getRoot());

        Intent intent = getIntent();
        projectId = intent.getStringExtra("project_id") == null ? "" : intent.getStringExtra("project_id");
        projectName = intent.getStringExtra("name") == null ? "" : intent.getStringExtra("name");
        projectDomain = intent.getStringExtra("domain") == null ? "" : intent.getStringExtra("domain");
        httpsEnabled = intent.getBooleanExtra("https_enabled", true);

        b.header.tvTitle.setText("静态站点");
        b.header.tvSubtitle.setText("文件与访问管理");
        b.header.btnBack.setOnClickListener(v -> finish());
        b.header.btnAction.setVisibility(View.VISIBLE);
        b.header.ivAction.setImageResource(R.drawable.ic_refresh);
        b.header.btnAction.setOnClickListener(v -> loadFiles());

        b.tvName.setText(projectName.isEmpty() ? "静态站点" : projectName);
        bindChips();
        updateDomain();

        b.btnUpload.setOnClickListener(v -> picker.launch(new Intent(this,
                FileManagerActivity.class).putExtra(FileManagerActivity.EXTRA_MULTI, true)));
        b.btnUploadFolder.setOnClickListener(v -> picker.launch(new Intent(this,
                FileManagerActivity.class).putExtra(FileManagerActivity.EXTRA_FOLDER, true)));
        b.btnOpenSite.setOnClickListener(v -> DeploySupport.open(this, siteUrl()));
        b.btnCopyDomain.setOnClickListener(v -> {
            if (projectDomain.isEmpty()) {
                UiUtils.toast("暂无域名");
            } else {
                UiUtils.copy("域名", projectDomain);
            }
        });
        b.btnNewFolder.setOnClickListener(v -> createFolder());
        b.tvBreadcrumb.setOnClickListener(v -> navigateTo(parentOf(currentFolder)));

        loadFiles();
    }

    private void bindChips() {
        b.tvHttps.setText(httpsEnabled ? "HTTPS 开" : "HTTPS 关");
        b.tvHttps.setBackgroundResource(httpsEnabled
                ? R.drawable.bg_chip_success : R.drawable.bg_chip_warn);
        b.tvHttps.setTextColor(getColor(httpsEnabled
                ? R.color.chip_success_fg : R.color.chip_warn_fg));
    }

    private String siteUrl() {
        return DeploySupport.domainUrl(projectDomain, httpsEnabled);
    }

    private void updateDomain() {
        String url = siteUrl();
        b.tvDomain.setText(url.isEmpty() ? "等待分配域名" : url);
        b.btnOpenDomain.setVisibility(url.isEmpty() ? View.GONE : View.VISIBLE);
        b.tvDomain.setOnClickListener(v -> DeploySupport.open(this, url));
        b.btnOpenDomain.setOnClickListener(v -> DeploySupport.open(this, url));
        b.tvMain.setText("主入口：" + (mainFile.isEmpty() ? "未设置" : mainFile));
    }

    private void loadFiles() {
        b.tvFilesEmpty.setText("加载中…");
        b.tvFilesEmpty.setVisibility(View.VISIBLE);
        Calls.get("/api/static/files?project_id=" + DeploySupport.enc(projectId), json -> {
            if (isFinishing() || isDestroyed()) return;
            if (!Json.ok(json)) {
                b.tvFileCount.setText("0 项");
                b.containerFiles.removeAllViews();
                b.tvFilesEmpty.setText("加载失败：" + Json.message(json));
                b.tvFilesEmpty.setVisibility(View.VISIBLE);
                return;
            }
            String full = json.optString("full_domain", "");
            if (!full.isEmpty()) projectDomain = full;
            mainFile = json.optString("main_file", "");
            updateDomain();

            allFiles = Json.array(json, "files");
            if (allFiles == null) allFiles = new JSONArray();
            renderFolder();
        });
    }

    /** 按网页版逻辑从扁平文件路径派生文件夹与文件列表。 */
    private void renderFolder() {
        b.containerFiles.removeAllViews();
        b.tvBreadcrumb.setText(currentFolder.isEmpty() ? "/ 根目录" : "/ " + currentFolder);

        String prefix = currentFolder.isEmpty() ? "" : currentFolder + "/";
        TreeMap<String, long[]> folders = new TreeMap<>();
        List<JSONObject> files = new ArrayList<>();

        for (int i = 0; i < allFiles.length(); i++) {
            JSONObject node = allFiles.optJSONObject(i);
            if (node == null) continue;
            String path = node.optString("path", "");
            if (path.isEmpty()) continue;
            if (path.endsWith("/.folder") || path.equals(".folder")) continue;
            if (!prefix.isEmpty()) {
                if (!path.startsWith(prefix)) continue;
                String rest = path.substring(prefix.length());
                if (rest.isEmpty()) continue;
                if (rest.contains("/")) {
                    String folderName = rest.substring(0, rest.indexOf('/'));
                    long[] info = folders.get(folderName);
                    if (info == null) info = new long[]{0, 0};
                    info[0] += 1;
                    info[1] += node.optLong("size", 0);
                    folders.put(folderName, info);
                } else {
                    files.add(node);
                }
            } else {
                if (path.contains("/")) {
                    String folderName = path.substring(0, path.indexOf('/'));
                    long[] info = folders.get(folderName);
                    if (info == null) info = new long[]{0, 0};
                    info[0] += 1;
                    info[1] += node.optLong("size", 0);
                    folders.put(folderName, info);
                } else {
                    files.add(node);
                }
            }
        }

        for (String folderName : folders.keySet()) {
            long[] info = folders.get(folderName);
            addFolderRow(folderName, (int) info[0], info[1]);
        }
        for (JSONObject node : files) {
            addFileRow(node);
        }

        int count = folders.size() + files.size();
        b.tvFileCount.setText(count + " 项");
        b.tvFilesEmpty.setText(count == 0
                ? (currentFolder.isEmpty() ? "还没有文件，点击「上传文件」开始" : "当前文件夹为空")
                : "");
        b.tvFilesEmpty.setVisibility(count == 0 ? View.VISIBLE : View.GONE);
    }

    private void navigateTo(String folder) {
        currentFolder = folder == null ? "" : DeploySupport.cleanPath(folder);
        renderFolder();
    }

    private String parentOf(String folder) {
        if (folder == null || folder.isEmpty()) return "";
        int index = folder.lastIndexOf('/');
        return index < 0 ? "" : folder.substring(0, index);
    }

    private void addFolderRow(String name, int count, long size) {
        String folderPath = currentFolder.isEmpty() ? name : currentFolder + "/" + name;
        ItemDeployFileBinding row = ItemDeployFileBinding.inflate(getLayoutInflater(),
                b.containerFiles, false);
        row.ivIcon.setImageResource(R.drawable.ic_folder);
        row.tvName.setText(name + "  (" + count + " 项)");
        row.tvPath.setText(folderPath);
        row.tvSize.setText(sizeStr(size));
        row.rowActions.setVisibility(View.VISIBLE);
        row.btnEdit.setVisibility(View.GONE);
        row.btnMain.setVisibility(View.GONE);
        row.btnDelete.setOnClickListener(v -> confirmDeleteFolder(folderPath));
        row.getRoot().setOnClickListener(v -> navigateTo(folderPath));
        b.containerFiles.addView(row.getRoot());
    }

    private static String sizeStr(long size) {
        if (size >= 1024L * 1024) {
            return String.format(Locale.US, "%.2f MB", size / 1024f / 1024f);
        }
        return String.format(Locale.US, "%.2f KB", size / 1024f);
    }

    private void addFileRow(JSONObject node) {
        String path = node.optString("path", "");
        String name = DeploySupport.fileName(path);
        ItemDeployFileBinding row = ItemDeployFileBinding.inflate(getLayoutInflater(),
                b.containerFiles, false);
        row.ivIcon.setImageResource(R.drawable.ic_file);
        row.tvName.setText(name.isEmpty() ? path : name);
        row.tvPath.setText(path);
        row.tvSize.setText(node.optString("size_str", ""));
        row.rowActions.setVisibility(View.VISIBLE);
        row.btnEdit.setVisibility(View.VISIBLE);
        row.btnEdit.setText("预览");
        row.btnMain.setText("设为主入口");

        String lower = path.toLowerCase(Locale.ROOT);
        boolean html = lower.endsWith(".html") || lower.endsWith(".htm");
        boolean isMain = path.equals(mainFile) || name.equals(mainFile);
        row.btnMain.setVisibility(html && !isMain ? View.VISIBLE : View.GONE);
        row.btnMain.setOnClickListener(v -> setMain(path));
        row.btnEdit.setOnClickListener(v -> DeploySupport.open(this, previewUrl(path)));
        row.btnDelete.setOnClickListener(v -> confirmDelete(path, name));
        b.containerFiles.addView(row.getRoot());
    }

    private String previewUrl(String path) {
        String base = siteUrl();
        if (base.isEmpty()) return "";
        return (base.endsWith("/") ? base : base + "/") + path;
    }

    private void setMain(String path) {
        try {
            JSONObject body = new JSONObject();
            body.put("project_id", projectId);
            body.put("path", path);
            Calls.post("/api/static/set_main", body.toString(), json -> {
                if (isFinishing()) return;
                UiUtils.toast(Json.ok(json) ? "主入口已设置" : Json.message(json));
                if (Json.ok(json)) loadFiles();
            });
        } catch (Exception ignored) {
        }
    }

    private void createFolder() {
        EditText input = DeploySupport.input(this, "文件夹名称", "", false);
        LinearLayout box = DeploySupport.form(this);
        DeploySupport.addField(this, box, "新建文件夹", input);
        AlertDialog dialog = new MaterialAlertDialogBuilder(this)
                .setTitle("新建文件夹")
                .setView(box)
                .setNegativeButton("取消", null)
                .setPositiveButton("创建", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(v -> {
                    String name = DeploySupport.cleanPath(input.getText().toString());
                    if (name.isEmpty()) {
                        UiUtils.toast("请输入文件夹名称");
                        return;
                    }
                    String target = currentFolder.isEmpty() ? name : currentFolder + "/" + name;
                    File empty = new File(getCacheDir(), ".folder");
                    try {
                        if (!empty.exists()) empty.createNewFile();
                        JSONObject fields = new JSONObject();
                        fields.put("project_id", projectId);
                        fields.put("relative_path", target);
                        Calls.upload("/api/static/upload", fields.toString(),
                                empty.getAbsolutePath(), "file", ".folder",
                                "application/octet-stream", json -> {
                                    if (isFinishing()) return;
                                    if (Json.ok(json)) {
                                        dialog.dismiss();
                                        UiUtils.toast("文件夹已创建");
                                        loadFiles();
                                    } else {
                                        UiUtils.toast(Json.message(json));
                                    }
                                });
                    } catch (Exception e) {
                        UiUtils.toast("创建失败");
                    }
                }));
        dialog.show();
    }

    private void confirmDelete(String path, String name) {
        new MaterialAlertDialogBuilder(this)
                .setTitle("删除文件")
                .setMessage("确定删除「" + path + "」吗？")
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", (d, w) -> deletePath(path, name))
                .show();
    }

    private void confirmDeleteFolder(String folderPath) {
        new MaterialAlertDialogBuilder(this)
                .setTitle("删除文件夹")
                .setMessage("确定删除「" + folderPath + "」及其下所有文件吗？")
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", (d, w) -> {
                    List<String> targets = new ArrayList<>();
                    for (int i = 0; i < allFiles.length(); i++) {
                        JSONObject node = allFiles.optJSONObject(i);
                        if (node == null) continue;
                        String path = node.optString("path", "");
                        if (path.equals(folderPath) || path.startsWith(folderPath + "/")) {
                            targets.add(path);
                        }
                    }
                    if (targets.isEmpty()) {
                        UiUtils.toast("文件夹为空");
                        return;
                    }
                    deleteAll(targets, 0);
                })
                .show();
    }

    private void deleteAll(List<String> paths, int index) {
        if (index >= paths.size()) {
            UiUtils.toast("已删除 " + paths.size() + " 个文件");
            loadFiles();
            return;
        }
        deletePath(paths.get(index), paths.get(index), () -> deleteAll(paths, index + 1), false);
    }

    private void deletePath(String path, String name) {
        deletePath(path, name, null, true);
    }

    private void deletePath(String path, String name, Runnable then, boolean toastEach) {
        try {
            JSONObject body = new JSONObject();
            body.put("project_id", projectId);
            body.put("path", path);
            Calls.post("/api/static/file/delete", body.toString(), json -> {
                if (isFinishing()) return;
                if (then != null) {
                    then.run();
                } else {
                    UiUtils.toast(Json.ok(json) ? "已删除 " + name : Json.message(json));
                    if (Json.ok(json)) loadFiles();
                }
            });
        } catch (Exception ignored) {
        }
    }

    private void onPickedPaths(java.util.ArrayList<String> paths,
                              java.util.ArrayList<String> relatives) {
        if (paths == null || paths.isEmpty()) return;
        List<Uri> uris = new ArrayList<>();
        for (String path : paths) uris.add(Uri.fromFile(new File(path)));
        onPicked(uris, relatives);
    }

    private void onPicked(List<Uri> uris, List<String> relatives) {
        if (uris == null || uris.isEmpty()) return;
        AlertDialog progress = DeploySupport.progress(this, "正在上传 0/" + uris.size());
        uploadNext(uris, relatives, 0, 0, progress);
    }

    /** 由文件夹上传的相对路径推导服务器端目标目录。 */
    private String folderOf(String relative, int index) {
        if (relative == null || relative.isEmpty()) return currentFolder;
        int slash = relative.lastIndexOf('/');
        String dir = slash < 0 ? "" : relative.substring(0, slash);
        if (currentFolder.isEmpty()) return dir;
        return dir.isEmpty() ? currentFolder : currentFolder + "/" + dir;
    }

    private void uploadNext(List<Uri> uris, List<String> relatives, int index, int success,
                            AlertDialog progress) {
        if (isFinishing() || isDestroyed()) {
            if (progress.isShowing()) progress.dismiss();
            return;
        }
        if (index >= uris.size()) {
            if (progress.isShowing()) progress.dismiss();
            UiUtils.toast("上传完成：成功 " + success + " / " + uris.size());
            loadFiles();
            return;
        }
        progress.setMessage("正在上传 " + (index + 1) + "/" + uris.size());
        Uri uri = uris.get(index);
        String rel = relatives == null || index >= relatives.size() ? "" : relatives.get(index);
        String displayName = displayName(uri);
        String mime = mimeOf(displayName);
        Io.run(() -> {
            final File cached;
            try {
                cached = copyToCache(uri, displayName);
            } catch (Exception e) {
                Io.main(() -> {
                    UiUtils.toast("读取失败：" + displayName);
                    uploadNext(uris, relatives, index + 1, success, progress);
                });
                return;
            }
            Io.main(() -> {
                JSONObject fields = new JSONObject();
                try {
                    fields.put("project_id", projectId);
                    fields.put("relative_path", folderOf(rel, index));
                } catch (Exception ignored) {
                }
                com.ac.cloud.service.ApiService.uploadProgress = (written, total) -> {
                    int pct = total <= 0 ? 0 : (int) (written * 100 / total);
                    Io.main(() -> progress.setMessage("正在上传 " + (index + 1) + "/" + uris.size()
                            + " · " + pct + "%"));
                };
                Calls.upload("/api/static/upload", fields.toString(), cached.getAbsolutePath(),
                        "file", displayName, mime, json -> {
                            com.ac.cloud.service.ApiService.uploadProgress = null;
                            cached.delete();
                            if (Json.ok(json)) {
                                uploadNext(uris, relatives, index + 1, success + 1, progress);
                            } else {
                                UiUtils.toast(displayName + "：" + Json.message(json));
                                uploadNext(uris, relatives, index + 1, success, progress);
                            }
                        });
            });
        });
    }

    private String displayName(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) {
                    String name = cursor.getString(index);
                    if (name != null && !name.isEmpty()) return name;
                }
            }
        } catch (Exception ignored) {
        }
        String segment = uri.getLastPathSegment();
        if (segment == null || segment.isEmpty()) {
            return "upload_" + System.currentTimeMillis();
        }
        return DeploySupport.fileName(segment);
    }

    private File copyToCache(Uri uri, String name) throws Exception {
        File out = new File(getCacheDir(), "static_up_" + System.nanoTime() + "_"
                + name.replaceAll("[^A-Za-z0-9._-]", "_"));
        try (InputStream in = "file".equals(uri.getScheme())
                ? new java.io.FileInputStream(new File(uri.getPath()))
                : getContentResolver().openInputStream(uri);
             FileOutputStream os = new FileOutputStream(out)) {
            if (in == null) throw new Exception("无法读取文件");
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) > 0) {
                os.write(buffer, 0, read);
            }
        }
        return out;
    }

    private static String mimeOf(String name) {
        String mime = URLConnection.guessContentTypeFromName(name == null ? "" : name);
        return mime == null ? "application/octet-stream" : mime;
    }
}
