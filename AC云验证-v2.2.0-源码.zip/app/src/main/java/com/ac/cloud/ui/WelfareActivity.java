package com.ac.cloud.ui;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.ac.cloud.R;
import com.ac.cloud.core.Json;
import com.ac.cloud.net.Calls;
import com.ac.cloud.util.UiUtils;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.json.JSONArray;
import org.json.JSONObject;

public class WelfareActivity extends AppCompatActivity {

    private LinearLayout container;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiUtils.edgeToEdge(this);
        setContentView(R.layout.activity_welfare);
        UiUtils.applyInsets(findViewById(R.id.rootWelfare));

        TextView title = findViewById(R.id.tvTitle);
        TextView subtitle = findViewById(R.id.tvSubtitle);
        title.setText("福利中心");
        subtitle.setText("全站福利 · 限时领取");
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        container = findViewById(R.id.containerWelfare);
        load();
    }

    private void load() {
        container.removeAllViews();
        Calls.get("/api/welfare", json -> {
            if (isFinishing()) return;
            if (json.optInt("code") != 1) {
                UiUtils.toast(Json.message(json));
                return;
            }
            JSONArray items = json.optJSONArray("items");
            if (items == null || items.length() == 0) {
                TextView empty = new TextView(this);
                empty.setText("暂时没有可领取的福利，敬请期待");
                empty.setTextColor(getColor(R.color.on_surface_variant));
                empty.setTextSize(13);
                empty.setGravity(Gravity.CENTER);
                empty.setPadding(0, UiUtils.dp(this, 60), 0, 0);
                container.addView(empty);
                return;
            }
            for (int i = 0; i < items.length(); i++) {
                JSONObject item = items.optJSONObject(i);
                if (item != null) container.addView(buildRow(item));
            }
        });
    }

    private View buildRow(JSONObject item) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_input);
        int pad = UiUtils.dp(this, 16);
        card.setPadding(pad, pad, pad, pad);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.bottomMargin = UiUtils.dp(this, 12);
        card.setLayoutParams(params);

        TextView title = new TextView(this);
        title.setText(item.optString("title", "福利"));
        title.setTextColor(getColor(R.color.on_surface));
        title.setTextSize(15);
        title.setTypeface(android.graphics.Typeface.create("sans-serif-medium",
                android.graphics.Typeface.NORMAL));
        card.addView(title);

        String desc = item.optString("desc", "");
        if (!desc.isEmpty()) {
            TextView sub = new TextView(this);
            sub.setText(desc);
            sub.setTextColor(getColor(R.color.on_surface_variant));
            sub.setTextSize(11);
            sub.setPadding(0, UiUtils.dp(this, 4), 0, 0);
            card.addView(sub);
        }

        com.google.android.material.button.MaterialButton button =
                new com.google.android.material.button.MaterialButton(this, null,
                        com.google.android.material.R.attr.materialButtonOutlinedStyle);
        boolean claimed = item.optBoolean("claimed");
        button.setText(claimed ? "已领取" : "立即领取");
        button.setEnabled(!claimed);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, UiUtils.dp(this, 40));
        bp.topMargin = UiUtils.dp(this, 10);
        button.setLayoutParams(bp);
        button.setOnClickListener(v -> claim(item.optString("id"), button));
        card.addView(button);
        return card;
    }

    private void claim(String id, View button) {
        try {
            JSONObject body = new JSONObject();
            body.put("id", id);
            button.setEnabled(false);
            Calls.post("/api/welfare/claim", body.toString(), json -> {
                if (isFinishing()) return;
                if (json.optInt("code") == 1) {
                    String reward = json.optString("reward", "");
                    new MaterialAlertDialogBuilder(this)
                            .setTitle("领取成功")
                            .setMessage(reward.isEmpty() ? "福利已到账" : reward)
                            .setPositiveButton("复制", (d, w) -> UiUtils.copy("福利", reward))
                            .setNegativeButton("完成", null)
                            .show();
                    load();
                } else {
                    button.setEnabled(true);
                    UiUtils.toast(Json.message(json));
                }
            });
        } catch (Exception e) {
            button.setEnabled(true);
            UiUtils.toast("领取失败");
        }
    }
}
