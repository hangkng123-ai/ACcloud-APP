package com.ac.cloud.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ac.cloud.R;
import com.ac.cloud.core.Json;
import com.ac.cloud.core.Prefs;
import com.ac.cloud.databinding.FragmentInstancesBinding;
import com.ac.cloud.net.Calls;
import com.ac.cloud.ui.adapters.InstanceAdapter;
import com.ac.cloud.util.UiUtils;

import com.ac.cloud.core.DataCache;

import org.json.JSONArray;
import org.json.JSONObject;

public class InstancesFragment extends Fragment implements InstanceAdapter.Listener, CacheAware {

    private FragmentInstancesBinding b;
    private InstanceAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        b = FragmentInstancesBinding.inflate(inflater, container, false);
        return b.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        adapter = new InstanceAdapter(this);
        b.recycler.setLayoutManager(new LinearLayoutManager(requireContext()));
        b.recycler.setAdapter(adapter);
        b.swipe.setOnRefreshListener(this::load);
        b.btnCreate.setOnClickListener(v -> openCreate());
        UiUtils.bindMenu(view, this);
        if (DataCache.hasCore()) onCacheReady(); else load();
    }

    private void load() {
        Calls.get("/api/instances", json -> {
            if (!isAdded()) return;
            b.swipe.setRefreshing(false);
            if (json.optInt("code") != 1) {
                UiUtils.toast(Json.message(json));
                return;
            }
            DataCache.update("instances", json);
            apply(Json.array(json, "instances"));
        });
    }

    private void apply(JSONArray arr) {
        adapter.submit(arr);
        int count = adapter.getItemCount();
        b.tvSubtitle.setText(count == 0 ? "创建你的第一个验证实例"
                : "共 " + count + " 个实例 · 云端实时同步");
        b.emptyView.setVisibility(count == 0 ? View.VISIBLE : View.GONE);
        b.recycler.setVisibility(count == 0 ? View.GONE : View.VISIBLE);
    }

    @Override
    public void onCacheReady() {
        if (!isAdded() || b == null) return;
        apply(Json.array(DataCache.instances, "instances"));
    }

    private void openCreate() {
        CreateInstanceSheet sheet = new CreateInstanceSheet(this::load);
        sheet.show(getParentFragmentManager(), "create_instance");
    }

    @Override
    public void onOpen(JSONObject instance) {
        InstanceDetailSheet sheet = new InstanceDetailSheet(instance, this::load);
        sheet.show(getParentFragmentManager(), "instance_detail");
    }

    @Override
    public void onCloud(JSONObject instance) {
        Prefs.putString("selected_instance", instance.optString("instance_id"));
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).showTab(R.id.nav_cloud);
        }
    }

    @Override
    public void onToggle(JSONObject instance, boolean running) {
        String path = "/api/instances/" + instance.optString("instance_id") + "/toggle";
        Calls.post(path, "{}", json -> {
            if (!isAdded()) return;
            if (json.optInt("code") != 1) {
                UiUtils.toast(Json.message(json));
            }
            load();
        });
    }

    @Override
    public void onDelete(JSONObject instance) {
        String iid = instance.optString("instance_id");
        new com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
                .setTitle("删除应用")
                .setMessage("将删除实例 " + iid + "，密钥保留 7 天可恢复。确定继续？")
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", (d, w) -> {
                    try {
                        JSONObject body = new JSONObject();
                        body.put("keep_keys", true);
                        Calls.delete("/api/instances/" + iid, body.toString(), json -> {
                            if (!isAdded()) return;
                            if (json.optInt("code") == 1) {
                                UiUtils.toast("应用已删除");
                            } else {
                                UiUtils.toast(Json.message(json));
                            }
                            load();
                        });
                    } catch (Exception e) {
                        UiUtils.toast("删除失败");
                    }
                })
                .show();
    }

}
