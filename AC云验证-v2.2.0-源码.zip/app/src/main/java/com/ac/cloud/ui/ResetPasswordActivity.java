package com.ac.cloud.ui;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import com.ac.cloud.core.Json;
import com.ac.cloud.databinding.ActivityResetPasswordBinding;
import com.ac.cloud.net.Calls;
import com.ac.cloud.util.UiUtils;

import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ResetPasswordActivity extends AppCompatActivity {

    private ActivityResetPasswordBinding b;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int countdown;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiUtils.edgeToEdge(this);
        b = ActivityResetPasswordBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        UiUtils.applyInsets(b.getRoot());

        b.header.tvTitle.setText("重置密码");
        b.header.tvSubtitle.setText("邮箱验证，应用内完成");
        b.header.btnBack.setOnClickListener(v -> finish());
        b.btnSendCode.setOnClickListener(v -> sendCode());
        b.btnReset.setOnClickListener(v -> reset());
    }

    private void sendCode() {
        String email = text(b.etEmail);
        if (email.isEmpty() || !email.contains("@")) {
            UiUtils.toast("请输入正确的邮箱");
            return;
        }
        b.btnSendCode.setEnabled(false);
        try {
            JSONObject body = new JSONObject();
            body.put("email", email);
            body.put("scene", "reset");
            Calls.post("/api/email/send_code", body.toString(), json -> {
                if (json.optInt("code") == 1) {
                    UiUtils.toast("验证码已发送");
                    startCountdown();
                } else {
                    UiUtils.toast(Json.message(json));
                    b.btnSendCode.setEnabled(true);
                }
            });
        } catch (Exception ignored) {
        }
    }

    private void startCountdown() {
        countdown = 60;
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (countdown <= 0) {
                    b.btnSendCode.setEnabled(true);
                    b.btnSendCode.setText("获取验证码");
                    return;
                }
                b.btnSendCode.setText(countdown + " s");
                countdown--;
                handler.postDelayed(this, 1000);
            }
        });
    }

    private void reset() {
        String email = text(b.etEmail);
        String code = text(b.etCode);
        String pw = text(b.etPassword);
        String confirm = text(b.etConfirm);
        if (email.isEmpty() || code.isEmpty() || pw.isEmpty()) {
            UiUtils.toast("请填写完整");
            return;
        }
        if (pw.length() < 6) {
            UiUtils.toast("密码至少 6 位");
            return;
        }
        if (!pw.equals(confirm)) {
            UiUtils.toast("两次密码不一致");
            return;
        }
        b.btnReset.setEnabled(false);
        String form = "email=" + enc(email) + "&email_code=" + enc(code)
                + "&new_password=" + enc(pw) + "&confirm_password=" + enc(confirm);
        Calls.formRaw("/reset_password", form, body -> {
            b.btnReset.setEnabled(true);
            if (body == null) body = "";
            if (body.contains("msg-success") || body.contains("密码重置成功")) {
                UiUtils.toast("密码重置成功，请使用新密码登录");
                finish();
            } else {
                String msg = "重置失败";
                Matcher m = Pattern.compile("<div class=\"msg msg-error\">.*?</span>\\s*([^<]+)",
                        Pattern.DOTALL).matcher(body);
                if (m.find()) msg = m.group(1).trim();
                UiUtils.toast(msg);
            }
        });
    }

    private static String text(android.widget.EditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }

    private static String enc(String value) {
        try {
            return URLEncoder.encode(value, "UTF-8");
        } catch (Exception e) {
            return value;
        }
    }
}
