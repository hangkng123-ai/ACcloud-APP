package com.ac.cloud.core;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/**
 * Shizuku 系统级能力入口：授权后可调用系统命令做网络优化 / 连接诊断。
 * 未安装或未授权时全部方法安全降级，不影响主流程。
 */
public final class ShizukuManager {

    public static final int REQUEST_CODE = 0x5A12;

    private ShizukuManager() {
    }

    public static boolean available() {
        try {
            return rikka.shizuku.Shizuku.pingBinder();
        } catch (Throwable t) {
            return false;
        }
    }

    public static boolean granted() {
        if (!available()) return false;
        try {
            return rikka.shizuku.Shizuku.checkSelfPermission()
                    == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    public static void request(Activity activity) {
        if (!available()) return;
        try {
            if (Build.VERSION.SDK_INT >= 23 && !granted()) {
                rikka.shizuku.Shizuku.requestPermission(REQUEST_CODE);
            }
        } catch (Throwable ignored) {
        }
    }

    /** 在后台线程执行系统命令并返回合并后的输出。 */
    public static String exec(String command) {
        if (!granted()) return "尚未获得 Shizuku 授权";
        try {
            moe.shizuku.server.IShizukuService service =
                    moe.shizuku.server.IShizukuService.Stub.asInterface(
                            rikka.shizuku.Shizuku.getBinder());
            if (service == null) return "Shizuku 服务不可用";
            moe.shizuku.server.IRemoteProcess process = service.newProcess(
                    new String[]{"sh", "-c", command}, null, null);
            StringBuilder out = new StringBuilder();
            read(new java.io.FileInputStream(
                    process.getInputStream().getFileDescriptor()), out);
            read(new java.io.FileInputStream(
                    process.getErrorStream().getFileDescriptor()), out);
            process.waitFor();
            return out.length() == 0 ? "命令已执行" : out.toString().trim();
        } catch (Throwable t) {
            return "执行失败：" + t.getMessage();
        }
    }

    private static void read(java.io.InputStream stream, StringBuilder out) throws Exception {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (out.length() > 0) out.append('\n');
                out.append(line);
            }
        }
    }

    /** 常用网络优化指令集合（Shizuku/shell 权限可执行的部分）。 */
    public static String optimizeNetwork() {
        return exec("settings put global wifi_scan_always_enabled 0; "
                + "settings put global captive_portal_mode 0; "
                + "settings put global private_dns_mode off; "
                + "sysctl -w net.ipv4.tcp_tw_reuse=1 2>/dev/null; "
                + "sysctl -w net.ipv4.tcp_fin_timeout=30 2>/dev/null; "
                + "sysctl -w net.ipv4.tcp_keepalive_time=120 2>/dev/null; "
                + "cmd netpolicy set restrict-background false 2>/dev/null; "
                + "echo 网络优化完成");
    }

    /** 通过 Shizuku 直接建立到目标服务器的 TCP 连接并保持短时活跃，提升首包稳定性。 */
    public static String stabilizeTcp(String host, int port) {
        return exec("echo -n '' > /dev/tcp/" + host + "/" + port
                + " 2>/dev/null && echo TCP连接稳定 || ping -c 3 -W 2 " + host);
    }
}
