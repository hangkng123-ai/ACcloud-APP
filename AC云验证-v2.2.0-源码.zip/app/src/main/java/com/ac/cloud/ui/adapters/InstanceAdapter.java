package com.ac.cloud.ui.adapters;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ac.cloud.R;
import com.ac.cloud.databinding.ItemInstanceBinding;

import org.json.JSONArray;
import org.json.JSONObject;

public class InstanceAdapter extends RecyclerView.Adapter<InstanceAdapter.VH> {

    public interface Listener {
        void onOpen(JSONObject instance);

        void onCloud(JSONObject instance);

        void onToggle(JSONObject instance, boolean running);

        void onDelete(JSONObject instance);
    }

    private JSONArray items = new JSONArray();
    private final Listener listener;

    public InstanceAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submit(JSONArray array) {
        items = array == null ? new JSONArray() : array;
        notifyDataSetChanged();
    }

    public JSONArray items() {
        return items;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(ItemInstanceBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        JSONObject item = items.optJSONObject(position);
        if (item == null) return;
        JSONObject config = item.optJSONObject("config");
        if (config == null) config = new JSONObject();

        holder.b.tvName.setText(item.optString("name", "未命名应用"));
        holder.b.tvId.setText(item.optString("instance_id", ""));
        boolean running = "running".equals(item.optString("status"));
        holder.b.tvStatus.setText(running ? "运行中" : "已停止");
        holder.b.tvStatus.setBackgroundResource(running
                ? R.drawable.bg_chip_success : R.drawable.bg_chip_warn);
        holder.b.tvStatus.setTextColor(holder.b.getRoot().getContext().getColor(running
                ? R.color.chip_success_fg : R.color.chip_warn_fg));

        String announcement = config.optString("announcement_zh", "");
        if (announcement.isEmpty()) announcement = config.optString("announcement", "");
        holder.b.tvAnnouncement.setVisibility(announcement.isEmpty()
                ? android.view.View.GONE : android.view.View.VISIBLE);
        holder.b.tvAnnouncement.setText(announcement);

        String created = item.optString("create_time", "--");
        holder.b.tvMeta.setText("创建于 " + created);

        JSONObject stats = item.optJSONObject("api_stats");
        int total = stats == null ? 0 : stats.optInt("total", 0);
        int success = stats == null ? 0 : stats.optInt("success", total - stats.optInt("failed", 0));
        int failed = stats == null ? 0 : stats.optInt("failed", 0);
        holder.b.tvMeta.setText("API: 总" + total + " · 成功" + success + " · 失败" + failed);
        holder.b.tvMeta.setTextColor(holder.b.getRoot().getContext().getColor(
                failed > 0 ? R.color.chip_warn_fg : R.color.on_surface_variant));

        holder.b.btnToggle.setText(running ? "停止" : "启动");
        holder.b.btnToggle.setBackgroundResource(running
                ? R.drawable.bg_button_orange : R.drawable.bg_button_green);
        holder.b.btnToggle.setOnClickListener(v -> listener.onToggle(item, !running));

        holder.b.getRoot().setOnClickListener(v -> listener.onOpen(item));
        holder.b.btnAnnounce.setOnClickListener(v -> listener.onOpen(item));
        holder.b.btnKey.setOnClickListener(v -> listener.onOpen(item));
        holder.b.btnDelete.setOnClickListener(v -> listener.onDelete(item));
    }

    @Override
    public int getItemCount() {
        return items.length();
    }

    static class VH extends RecyclerView.ViewHolder {
        final ItemInstanceBinding b;

        VH(ItemInstanceBinding binding) {
            super(binding.getRoot());
            b = binding;
        }
    }
}
