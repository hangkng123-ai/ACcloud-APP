package com.ac.cloud.ui;

/** Implemented by tabs that can render a preloaded snapshot. */
public interface CacheAware {
    void onCacheReady();
}
