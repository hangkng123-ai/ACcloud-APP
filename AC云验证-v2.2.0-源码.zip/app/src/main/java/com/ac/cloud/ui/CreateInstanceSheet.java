package com.ac.cloud.ui;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.ac.cloud.R;
import com.ac.cloud.core.Json;
import com.ac.cloud.databinding.SheetCreateInstanceBinding;
import com.ac.cloud.net.Calls;
import com.ac.cloud.util.UiUtils;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.json.JSONObject;

public class CreateInstanceSheet extends BottomSheetDialogFragment {

    private Runnable onCreated;
    private SheetCreateInstanceBinding b;

    /** Fragment 重建时必须存在无参构造。 */
    public CreateInstanceSheet() {
    }

    public CreateInstanceSheet(Runnable onCreated) {
        this.onCreated = onCreated;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        BottomSheetDialog dialog = new BottomSheetDialog(requireContext(), R.style.Theme_AC_BottomSheet);
        return dialog;
    }

    @Override
    public void onStart() {
        super.onStart();
        // 窗口 DecorView 创建后才能安全设置背景模糊
        UiUtils.applyGlassBlur(getDialog());
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        b = SheetCreateInstanceBinding.inflate(inflater, container, false);
        return b.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        UiUtils.applyBottomInset(view);
        b.btnCreate.setOnClickListener(v -> create());
    }

    private void create() {
        String name = b.etName.getText() == null ? "" : b.etName.getText().toString().trim();
        String id = b.etId.getText() == null ? "" : b.etId.getText().toString().trim();
        String secret = b.etSecret.getText() == null ? "" : b.etSecret.getText().toString().trim();
        String apiKey = b.etApiKey.getText() == null ? "" : b.etApiKey.getText().toString().trim();
        if (name.isEmpty() || id.isEmpty()) {
            UiUtils.toast("请填写应用名称与 ID");
            return;
        }
        try {
            JSONObject body = new JSONObject();
            body.put("name", name);
            body.put("instance_id", id);
            if (!secret.isEmpty()) body.put("custom_secret_key", secret);
            if (!apiKey.isEmpty()) body.put("custom_api_key", apiKey);
            b.btnCreate.setEnabled(false);
            Calls.post("/api/instances/create", body.toString(), json -> {
                b.btnCreate.setEnabled(true);
                if (json.optInt("code") != 1) {
                    UiUtils.toast(Json.message(json));
                    return;
                }
                showGeneratedKeys(json);
                if (onCreated != null) onCreated.run();
                dismiss();
            });
        } catch (Exception e) {
            UiUtils.toast("参数错误");
        }
    }

    private void showGeneratedKeys(JSONObject json) {
        String aes = json.optString("aes_key", "");
        String secret = json.optString("secret_key", "");
        String message = "应用创建成功。请妥善保存以下密钥：\n\nAES 密钥（Base64）\n" + aes
                + "\n\n签名密钥\n" + secret;
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("创建成功")
                .setMessage(message)
                .setPositiveButton("复制密钥", (d, w) ->
                        UiUtils.copy("密钥", "AES: " + aes + "\nSECRET: " + secret))
                .setNegativeButton("完成", null)
                .show();
    }
}
