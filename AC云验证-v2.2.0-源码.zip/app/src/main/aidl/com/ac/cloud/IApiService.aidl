// AC Cloud AIDL - IPC contract between UI layer and network service
package com.ac.cloud;

interface IApiService {
    String login(String account, String password);
    String register(String acId, String displayName, String email, String emailCode, String password);
    String sendEmailCode(String email, String scene);
    String get(String path);
    String post(String path, String jsonBody);
    String delete(String path, String jsonBody);
    String postForm(String path, String formBody);
    boolean isLoggedIn();
    String getSessionCookie();
    String getUserJson();
    String getApiKey();
    String ping();
    String warmup();
    String appTokenLogin(String token);
    String appGoogleUrl();
    String upload(String path, String fieldsJson, String filePath, String fileField,
                  String fileName, String mimeType);
    void logout();
}
