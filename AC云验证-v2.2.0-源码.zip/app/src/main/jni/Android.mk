LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := accloud
LOCAL_SRC_FILES := native-lib.cpp
LOCAL_LDLIBS := -llog
LOCAL_CPPFLAGS := -std=c++17 -O2 -fvisibility=hidden -Wall
include $(BUILD_SHARED_LIBRARY)
