#include <jni.h>
#include <android/log.h>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
#include <random>
#include <chrono>
#include <cerrno>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fcntl.h>
#include <poll.h>

#define LOG_TAG "ACNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

namespace {

// ----------------------------------------------------------------------------
// Base64
// ----------------------------------------------------------------------------
const char B64C[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

std::string b64encode(const uint8_t *data, size_t len) {
    std::string out;
    out.reserve(((len + 2) / 3) * 4);
    for (size_t i = 0; i < len; i += 3) {
        uint32_t n = ((uint32_t) data[i]) << 16;
        if (i + 1 < len) n |= ((uint32_t) data[i + 1]) << 8;
        if (i + 2 < len) n |= data[i + 2];
        out += B64C[(n >> 18) & 63];
        out += B64C[(n >> 12) & 63];
        out += (i + 1 < len) ? B64C[(n >> 6) & 63] : '=';
        out += (i + 2 < len) ? B64C[n & 63] : '=';
    }
    return out;
}

std::vector<uint8_t> b64decode(const std::string &s) {
    int table[256];
    std::memset(table, -1, sizeof(table));
    for (int i = 0; i < 64; i++) table[(uint8_t) B64C[i]] = i;
    std::vector<uint8_t> out;
    uint32_t buffer = 0;
    int bits = 0;
    for (char c : s) {
        if (c == '=') break;
        int v = table[(uint8_t) c];
        if (v < 0) continue;
        buffer = (buffer << 6) | (uint32_t) v;
        bits += 6;
        if (bits >= 8) {
            bits -= 8;
            out.push_back((uint8_t) ((buffer >> bits) & 0xFF));
        }
    }
    return out;
}

// ----------------------------------------------------------------------------
// AES-256 (CBC + PKCS7)
// ----------------------------------------------------------------------------
const uint8_t SBOX[256] = {
        0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
        0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
        0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
        0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
        0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
        0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
        0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
        0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
        0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
        0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
        0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
        0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
        0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
        0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
        0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
        0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16
};

uint8_t RSBOX[256];
uint8_t RCON[15];

void init_tables() {
    static bool done = false;
    if (done) return;
    done = true;
    for (int i = 0; i < 256; i++) RSBOX[SBOX[i]] = (uint8_t) i;
    uint8_t r = 1;
    for (int i = 0; i < 15; i++) {
        RCON[i] = r;
        r = (uint8_t) ((r << 1) ^ ((r & 0x80) ? 0x1B : 0x00));
    }
}

inline uint8_t xtime(uint8_t x) {
    return (uint8_t) ((x << 1) ^ (((x >> 7) & 1) * 0x1B));
}

inline uint8_t gmul(uint8_t a, uint8_t b) {
    uint8_t p = 0;
    for (int i = 0; i < 8; i++) {
        if (b & 1) p ^= a;
        uint8_t hi = a & 0x80;
        a <<= 1;
        if (hi) a ^= 0x1B;
        b >>= 1;
    }
    return p;
}

const int NB = 4;
const int NK = 8;   // AES-256
const int NR = 14;

struct AesCtx {
    uint8_t rk[240];
};

void key_expansion(const uint8_t *key, AesCtx &ctx) {
    init_tables();
    std::memcpy(ctx.rk, key, 32);
    int total = NB * (NR + 1);
    for (int i = NK; i < total; i++) {
        uint8_t temp[4];
        std::memcpy(temp, ctx.rk + (i - 1) * 4, 4);
        if (i % NK == 0) {
            uint8_t t = temp[0];
            temp[0] = (uint8_t) (SBOX[temp[1]] ^ RCON[i / NK - 1]);
            temp[1] = SBOX[temp[2]];
            temp[2] = SBOX[temp[3]];
            temp[3] = SBOX[t];
        } else if (i % NK == 4) {
            for (int j = 0; j < 4; j++) temp[j] = SBOX[temp[j]];
        }
        for (int j = 0; j < 4; j++)
            ctx.rk[i * 4 + j] = ctx.rk[(i - NK) * 4 + j] ^ temp[j];
    }
}

void add_round_key(uint8_t *state, const uint8_t *rk) {
    for (int i = 0; i < 16; i++) state[i] ^= rk[i];
}

void sub_bytes(uint8_t *s) {
    for (int i = 0; i < 16; i++) s[i] = SBOX[s[i]];
}

void inv_sub_bytes(uint8_t *s) {
    for (int i = 0; i < 16; i++) s[i] = RSBOX[s[i]];
}

void shift_rows(uint8_t *s) {
    uint8_t t;
    // row 1
    t = s[1]; s[1] = s[5]; s[5] = s[9]; s[9] = s[13]; s[13] = t;
    // row 2
    t = s[2]; s[2] = s[10]; s[10] = t;
    t = s[6]; s[6] = s[14]; s[14] = t;
    // row 3
    t = s[15]; s[15] = s[11]; s[11] = s[7]; s[7] = s[3]; s[3] = t;
}

void inv_shift_rows(uint8_t *s) {
    uint8_t t;
    t = s[13]; s[13] = s[9]; s[9] = s[5]; s[5] = s[1]; s[1] = t;
    t = s[2]; s[2] = s[10]; s[10] = t;
    t = s[6]; s[6] = s[14]; s[14] = t;
    t = s[3]; s[3] = s[7]; s[7] = s[11]; s[11] = s[15]; s[15] = t;
}

void mix_columns(uint8_t *s) {
    for (int c = 0; c < 4; c++) {
        uint8_t *col = s + c * 4;
        uint8_t a = col[0], b = col[1], c2 = col[2], d = col[3];
        col[0] = xtime(a) ^ xtime(b) ^ b ^ c2 ^ d;
        col[1] = a ^ xtime(b) ^ xtime(c2) ^ c2 ^ d;
        col[2] = a ^ b ^ xtime(c2) ^ xtime(d) ^ d;
        col[3] = xtime(a) ^ a ^ b ^ c2 ^ xtime(d);
    }
}

void inv_mix_columns(uint8_t *s) {
    for (int c = 0; c < 4; c++) {
        uint8_t *col = s + c * 4;
        uint8_t a = col[0], b = col[1], c2 = col[2], d = col[3];
        col[0] = gmul(a, 14) ^ gmul(b, 11) ^ gmul(c2, 13) ^ gmul(d, 9);
        col[1] = gmul(a, 9) ^ gmul(b, 14) ^ gmul(c2, 11) ^ gmul(d, 13);
        col[2] = gmul(a, 13) ^ gmul(b, 9) ^ gmul(c2, 14) ^ gmul(d, 11);
        col[3] = gmul(a, 11) ^ gmul(b, 13) ^ gmul(c2, 9) ^ gmul(d, 14);
    }
}

void aes_encrypt_block(uint8_t *state, const AesCtx &ctx) {
    add_round_key(state, ctx.rk);
    for (int round = 1; round < NR; round++) {
        sub_bytes(state);
        shift_rows(state);
        mix_columns(state);
        add_round_key(state, ctx.rk + round * 16);
    }
    sub_bytes(state);
    shift_rows(state);
    add_round_key(state, ctx.rk + NR * 16);
}

void aes_decrypt_block(uint8_t *state, const AesCtx &ctx) {
    add_round_key(state, ctx.rk + NR * 16);
    for (int round = NR - 1; round > 0; round--) {
        inv_shift_rows(state);
        inv_sub_bytes(state);
        add_round_key(state, ctx.rk + round * 16);
        inv_mix_columns(state);
    }
    inv_shift_rows(state);
    inv_sub_bytes(state);
    add_round_key(state, ctx.rk);
}

std::string aes_cbc_encrypt_b64(const std::string &keyB64, const std::string &plain) {
    std::vector<uint8_t> key = b64decode(keyB64);
    if (key.size() != 32) return "";
    AesCtx ctx;
    key_expansion(key.data(), ctx);

    uint8_t iv[16];
    std::random_device rd;
    for (int i = 0; i < 16; i++) iv[i] = (uint8_t) (rd() & 0xFF);

    std::vector<uint8_t> data(plain.begin(), plain.end());
    size_t pad = 16 - (data.size() % 16);
    data.insert(data.end(), pad, (uint8_t) pad);

    std::vector<uint8_t> out(data.size());
    uint8_t prev[16];
    std::memcpy(prev, iv, 16);
    for (size_t off = 0; off < data.size(); off += 16) {
        uint8_t block[16];
        for (int i = 0; i < 16; i++) block[i] = data[off + i] ^ prev[i];
        aes_encrypt_block(block, ctx);
        std::memcpy(out.data() + off, block, 16);
        std::memcpy(prev, block, 16);
    }
    return b64encode(out.data(), out.size()) + "|" + b64encode(iv, 16);
}

std::string aes_cbc_decrypt_b64(const std::string &keyB64, const std::string &ctB64,
                                const std::string &ivB64) {
    std::vector<uint8_t> key = b64decode(keyB64);
    std::vector<uint8_t> ct = b64decode(ctB64);
    std::vector<uint8_t> iv = b64decode(ivB64);
    if (key.size() != 32 || iv.size() != 16 || ct.empty() || ct.size() % 16 != 0) return "";
    AesCtx ctx;
    key_expansion(key.data(), ctx);

    std::vector<uint8_t> out(ct.size());
    uint8_t prev[16];
    std::memcpy(prev, iv.data(), 16);
    for (size_t off = 0; off < ct.size(); off += 16) {
        uint8_t block[16];
        std::memcpy(block, ct.data() + off, 16);
        uint8_t saved[16];
        std::memcpy(saved, block, 16);
        aes_decrypt_block(block, ctx);
        for (int i = 0; i < 16; i++) out[off + i] = block[i] ^ prev[i];
        std::memcpy(prev, saved, 16);
    }
    int pad = out.back();
    if (pad <= 0 || pad > 16 || (size_t) pad > out.size()) return "";
    out.resize(out.size() - pad);
    return std::string(out.begin(), out.end());
}

// ----------------------------------------------------------------------------
// MD5
// ----------------------------------------------------------------------------
const uint32_t MD5_K[64] = {
        0xd76aa478, 0xe8c7b756, 0x242070db, 0xc1bdceee, 0xf57c0faf, 0x4787c62a, 0xa8304613, 0xfd469501,
        0x698098d8, 0x8b44f7af, 0xffff5bb1, 0x895cd7be, 0x6b901122, 0xfd987193, 0xa679438e, 0x49b40821,
        0xf61e2562, 0xc040b340, 0x265e5a51, 0xe9b6c7aa, 0xd62f105d, 0x02441453, 0xd8a1e681, 0xe7d3fbc8,
        0x21e1cde6, 0xc33707d6, 0xf4d50d87, 0x455a14ed, 0xa9e3e905, 0xfcefa3f8, 0x676f02d9, 0x8d2a4c8a,
        0xfffa3942, 0x8771f681, 0x6d9d6122, 0xfde5380c, 0xa4beea44, 0x4bdecfa9, 0xf6bb4b60, 0xbebfbc70,
        0x289b7ec6, 0xeaa127fa, 0xd4ef3085, 0x04881d05, 0xd9d4d039, 0xe6db99e5, 0x1fa27cf8, 0xc4ac5665,
        0xf4292244, 0x432aff97, 0xab9423a7, 0xfc93a039, 0x655b59c3, 0x8f0ccc92, 0xffeff47d, 0x85845dd1,
        0x6fa87e4f, 0xfe2ce6e0, 0xa3014314, 0x4e0811a1, 0xf7537e82, 0xbd3af235, 0x2ad7d2bb, 0xeb86d391
};
const int MD5_S[64] = {
        7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22,
        5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20,
        4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23,
        6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21
};

inline uint32_t rotl(uint32_t x, int c) {
    return (x << c) | (x >> (32 - c));
}

std::string md5_hex(const std::string &input) {
    uint32_t h0 = 0x67452301, h1 = 0xefcdab89, h2 = 0x98badcfe, h3 = 0x10325476;
    std::vector<uint8_t> msg(input.begin(), input.end());
    uint64_t bitLen = (uint64_t) msg.size() * 8;
    size_t originalLen = msg.size();
    // The AC Cloud backend uses a custom padding layout (one extra block in
    // most cases). Replicate it byte-for-byte so signatures match the server.
    size_t total = ((originalLen + 8 + 63) / 64 + 1) * 64;
    msg.push_back(0x80);
    while (msg.size() < total - 8) msg.push_back(0);
    msg.resize(total - 8);
    for (int i = 0; i < 8; i++) msg.push_back((uint8_t) ((bitLen >> (i * 8)) & 0xFF));

    for (size_t off = 0; off < msg.size(); off += 64) {
        uint32_t m[16];
        for (int i = 0; i < 16; i++) {
            m[i] = (uint32_t) msg[off + i * 4] |
                   ((uint32_t) msg[off + i * 4 + 1] << 8) |
                   ((uint32_t) msg[off + i * 4 + 2] << 16) |
                   ((uint32_t) msg[off + i * 4 + 3] << 24);
        }
        uint32_t a = h0, b = h1, c = h2, d = h3;
        for (int i = 0; i < 64; i++) {
            uint32_t f;
            int g;
            if (i < 16) { f = (b & c) | (~b & d); g = i; }
            else if (i < 32) { f = (d & b) | (~d & c); g = (5 * i + 1) % 16; }
            else if (i < 48) { f = b ^ c ^ d; g = (3 * i + 5) % 16; }
            else { f = c ^ (b | ~d); g = (7 * i) % 16; }
            uint32_t tmp = d;
            d = c;
            c = b;
            b = b + rotl(a + f + MD5_K[i] + m[g], MD5_S[i]);
            a = tmp;
        }
        h0 += a; h1 += b; h2 += c; h3 += d;
    }
    char out[33];
    std::snprintf(out, sizeof(out), "%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
                  h0 & 0xFF, (h0 >> 8) & 0xFF, (h0 >> 16) & 0xFF, (h0 >> 24) & 0xFF,
                  h1 & 0xFF, (h1 >> 8) & 0xFF, (h1 >> 16) & 0xFF, (h1 >> 24) & 0xFF,
                  h2 & 0xFF, (h2 >> 8) & 0xFF, (h2 >> 16) & 0xFF, (h2 >> 24) & 0xFF,
                  h3 & 0xFF, (h3 >> 8) & 0xFF, (h3 >> 16) & 0xFF, (h3 >> 24) & 0xFF);
    return std::string(out);
}

std::string jstr(JNIEnv *env, jstring s) {
    if (!s) return "";
    const char *c = env->GetStringUTFChars(s, nullptr);
    std::string out(c ? c : "");
    if (c) env->ReleaseStringUTFChars(s, c);
    return out;
}

jstring toJ(JNIEnv *env, const std::string &s) {
    return env->NewStringUTF(s.c_str());
}

// ----------------------------------------------------------------------------
// C++ 网络连接核心：DNS 解析 + TCP 握手预热 / 探测
// ----------------------------------------------------------------------------
int tcp_probe(const std::string &host, int port, int timeoutMs) {
    if (host.empty() || port <= 0) return -1;
    addrinfo hints{};
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    addrinfo *res = nullptr;
    if (getaddrinfo(host.c_str(), std::to_string(port).c_str(), &hints, &res) != 0 || !res) return -1;

    int best = -1;
    for (addrinfo *it = res; it != nullptr; it = it->ai_next) {
        int fd = socket(it->ai_family, it->ai_socktype, it->ai_protocol);
        if (fd < 0) continue;
        int flags = fcntl(fd, F_GETFL, 0);
        fcntl(fd, F_SETFL, flags | O_NONBLOCK);
        auto start = std::chrono::steady_clock::now();
        int rc = connect(fd, it->ai_addr, it->ai_addrlen);
        if (rc < 0 && errno == EINPROGRESS) {
            pollfd pfd{fd, POLLOUT, 0};
            rc = poll(&pfd, 1, timeoutMs);
            if (rc > 0) {
                int err = 0;
                socklen_t len = sizeof(err);
                getsockopt(fd, SOL_SOCKET, SO_ERROR, &err, &len);
                rc = err == 0 ? 0 : -1;
            } else {
                rc = -1;
            }
        }
        if (rc == 0) {
            auto end = std::chrono::steady_clock::now();
            int ms = (int) std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
            best = best < 0 ? ms : (ms < best ? ms : best);
        }
        close(fd);
        if (best >= 0) break;
    }
    freeaddrinfo(res);
    return best;
}

}  // namespace

extern "C" {

JNIEXPORT jstring JNICALL
Java_com_ac_cloud_core_NativeCore_md5(JNIEnv *env, jclass, jstring text) {
    return toJ(env, md5_hex(jstr(env, text)));
}

JNIEXPORT jstring JNICALL
Java_com_ac_cloud_core_NativeCore_sign(JNIEnv *env, jclass, jstring aes, jstring secret,
                                       jstring apiKey, jstring timestamp) {
    std::string raw = jstr(env, aes) + jstr(env, secret) + jstr(env, apiKey) + jstr(env, timestamp);
    return toJ(env, md5_hex(raw));
}

JNIEXPORT jobjectArray JNICALL
Java_com_ac_cloud_core_NativeCore_aesEncrypt(JNIEnv *env, jclass, jstring keyB64, jstring plain) {
    std::string packed = aes_cbc_encrypt_b64(jstr(env, keyB64), jstr(env, plain));
    std::string data, iv;
    size_t pos = packed.find('|');
    if (pos != std::string::npos) {
        data = packed.substr(0, pos);
        iv = packed.substr(pos + 1);
    }
    jclass strCls = env->FindClass("java/lang/String");
    jobjectArray arr = env->NewObjectArray(2, strCls, nullptr);
    env->SetObjectArrayElement(arr, 0, toJ(env, data));
    env->SetObjectArrayElement(arr, 1, toJ(env, iv));
    return arr;
}

JNIEXPORT jstring JNICALL
Java_com_ac_cloud_core_NativeCore_aesDecrypt(JNIEnv *env, jclass, jstring keyB64, jstring dataB64,
                                             jstring ivB64) {
    return toJ(env, aes_cbc_decrypt_b64(jstr(env, keyB64), jstr(env, dataB64), jstr(env, ivB64)));
}

JNIEXPORT jstring JNICALL
Java_com_ac_cloud_core_NativeCore_fingerprint(JNIEnv *env, jclass, jstring androidId) {
    std::string raw = "ac-cloud|" + jstr(env, androidId) + "|native-v2";
    std::string digest = md5_hex(raw);
    return toJ(env, digest.substr(0, 16));
}

JNIEXPORT jstring JNICALL
Java_com_ac_cloud_core_NativeCore_version(JNIEnv *env, jclass) {
    return toJ(env, "AC-Native 2.0 · NDK r29 · AES-256/MD5");
}

JNIEXPORT jint JNICALL
Java_com_ac_cloud_core_NativeCore_tcpProbe(JNIEnv *env, jclass, jstring host, jint port) {
    return tcp_probe(jstr(env, host), (int) port, 3000);
}

JNIEXPORT jint JNICALL
Java_com_ac_cloud_core_NativeCore_tcpWarm(JNIEnv *env, jclass, jstring host, jint port) {
    return tcp_probe(jstr(env, host), (int) port, 1500);
}

}
